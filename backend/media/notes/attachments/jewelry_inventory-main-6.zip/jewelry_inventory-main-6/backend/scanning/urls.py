from django.urls import path
from . import views

app_name = "scanning"

urlpatterns = [
    path("batch/", views.batch_scan_page, name="batch_scan_page"),
    path("api/batch/", views.batch_scan_api, name="batch_scan_api"),
    path(
        "api/lookup-variant/", views.lookup_variant_api, name="lookup_variant_api"
    ),  # ← NEW
]
