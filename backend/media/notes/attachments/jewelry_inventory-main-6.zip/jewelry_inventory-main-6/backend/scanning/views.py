from django.contrib.auth.decorators import login_required
from django.shortcuts import render

from rest_framework import status
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response

from catalog.models import ProductVariant


@api_view(["GET"])
@permission_classes([IsAuthenticated])
def lookup_variant_api(request):
    """
    Lookup product info for a scanned code (barcode or SKU).

    Usage (GET):
        /scanning/api/lookup-variant/?code=XYZ

    Returns JSON:
        {
          "found": true,
          "variant": {...},
          "product": {...}
        }
    """
    code = (request.query_params.get("code") or "").strip()
    if not code:
        return Response(
            {"detail": "Missing 'code' query parameter."},
            status=status.HTTP_400_BAD_REQUEST,
        )

    # Prefer barcode match, then fall back to SKU.
    variant = (
        ProductVariant.objects.select_related(
            "product",
            "product__collection",
            "product__default_supplier",
        )
        .filter(barcode=code)
        .first()
    )
    if not variant:
        variant = (
            ProductVariant.objects.select_related(
                "product",
                "product__collection",
                "product__default_supplier",
            )
            .filter(sku=code)
            .first()
        )

    if not variant:
        return Response({"found": False}, status=status.HTTP_404_NOT_FOUND)

    product = getattr(variant, "product", None)
    collection = getattr(product, "collection", None)
    supplier = getattr(product, "default_supplier", None)

    variant_payload = {
        "id": variant.id,
        "sku": variant.sku,
        "barcode": variant.barcode,
        "barcode_image_url": (
            variant.barcode_image.url
            if getattr(variant, "barcode_image", None)
            else None
        ),
        "size": variant.size,
        "color": variant.color,
        "chain_length_cm": variant.chain_length_cm,
        "stock_quantity": variant.stock_quantity,
        "low_stock_threshold": variant.low_stock_threshold,
        "backorder_allowed": variant.backorder_allowed,
        "lead_time_days": variant.lead_time_days,
        "is_discontinued": variant.is_discontinued,
        "cost": variant.cost,
        "price": variant.price,
    }

    product_payload = {
        "id": product.id if product else None,
        "name": product.name if product else "",
        "description": product.description if product else "",
        "collection_id": collection.id if collection else None,
        "collection_name": collection.name if collection else "",
        "metal": product.metal if product else "",
        "gold_purity": product.gold_purity if product else "",
        "weight_grams": product.weight_grams if product else None,
        "base_cost": product.base_cost if product else None,
        "base_price": product.base_price if product else None,
        "currency": product.currency if product else "USD",
        "supplier_id": supplier.id if supplier else None,
        "supplier_name": supplier.name if supplier else "",
    }

    return Response(
        {
            "found": True,
            "variant": variant_payload,
            "product": product_payload,
        }
    )


@login_required
def batch_scan_page(request):
    """
    Render the batch scanning page.

    This page is intended for power-usage with a barcode scanner.
    It uses the JSON batch API below to increment stock in bulk.
    """
    return render(request, "scanning/batch_scan.html")


@api_view(["POST"])
@permission_classes([IsAuthenticated])
def batch_scan_api(request):
    """
    Process a batch of scanned codes and quantities.

    The API supports two input shapes:

    1) Legacy object shape (backwards compatible with your existing page):
        {
            "CODE123": 3,
            "MR-012-6.5": 1
        }

    2) Newer explicit list shape:
        {
            "items": [
                {"code": "CODE123", "qty": 3},
                {"code": "MR-012-6.5", "qty": 1}
            ]
        }

    For each code:
      1) Try to match ProductVariant by barcode
      2) Fallback to matching by SKU
      3) Increment stock_quantity by scanned quantity
    """
    data = request.data or {}

    # Normalise into a {code: qty} mapping.
    codes_to_qty = {}

    if isinstance(data, dict) and "items" in data and isinstance(data["items"], list):
        # Newer list format
        for item in data["items"]:
            if not isinstance(item, dict):
                continue
            code = str(item.get("code", "")).strip()
            if not code:
                continue
            try:
                qty = int(item.get("qty", 1))
            except (TypeError, ValueError):
                qty = 1
            if qty == 0:
                continue
            codes_to_qty[code] = codes_to_qty.get(code, 0) + qty
    else:
        # Legacy flat object format
        for raw_code, raw_qty in data.items():
            code = str(raw_code).strip()
            if not code:
                continue
            try:
                qty = int(raw_qty)
            except (TypeError, ValueError):
                qty = 1
            if qty == 0:
                continue
            codes_to_qty[code] = codes_to_qty.get(code, 0) + qty

    if not codes_to_qty:
        return Response(
            {"detail": "No valid scan items found."},
            status=status.HTTP_400_BAD_REQUEST,
        )

    results = []

    # Perform all lookups & updates.
    for code, qty in codes_to_qty.items():
        variant = (
            ProductVariant.objects.select_related("product")
            .filter(barcode=code)
            .first()
        )
        if not variant:
            variant = (
                ProductVariant.objects.select_related("product")
                .filter(sku=code)
                .first()
            )

        if not variant:
            results.append({"code": code, "error": "Variant not found"})
            continue

        current_stock = variant.stock_quantity or 0
        variant.stock_quantity = current_stock + qty
        variant.save(update_fields=["stock_quantity"])

        results.append(
            {
                "code": code,
                "variant_id": variant.id,
                "sku": variant.sku,
                "new_stock_quantity": variant.stock_quantity,
            }
        )

    return Response({"results": results})
