from core.utils import get_app_settings
import pytest
from appsettings.models import AppSettings


@pytest.mark.django_db
def test_appsettings_save_forces_singleton_pk():
    # Even if we try to create another instance with a different pk,
    # the model.save() should force pk=1.
    s = AppSettings()
    s.pk = 999
    s.save()
    assert s.pk == 1

    # And load() should return that same row
    assert get_app_settings().pk == 1
