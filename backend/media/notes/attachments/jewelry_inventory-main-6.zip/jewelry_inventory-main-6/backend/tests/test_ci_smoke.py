import pytest
from django.urls import resolve
from django.conf import settings


@pytest.mark.django_db
def test_django_loaded_and_admin_url_resolves():
    # Basic sanity: settings are loaded and ADMIN is in INSTALLED_APPS
    assert "django.contrib.admin" in settings.INSTALLED_APPS

    # Admin login URL should resolve without error
    match = resolve("/admin/login/")
    assert match.view_name in ("admin:login", "login")


def test_root_url_config_importable():
    # Ensure ROOT_URLCONF points to a valid module
    __import__(settings.ROOT_URLCONF)
