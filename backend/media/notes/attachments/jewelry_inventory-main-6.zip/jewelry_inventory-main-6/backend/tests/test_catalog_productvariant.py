import pytest

from catalog.models import Product, ProductVariant


@pytest.mark.django_db
def test_product_variant_save_auto_generates_sku_and_barcode():
    product = Product.objects.create(name="Liora Necklace")
    variant = ProductVariant.objects.create(product=product, size="16", color="Yellow")

    # The save() override should have populated SKU, barcode, and image
    assert variant.sku, "SKU should be auto-generated on save"
    assert variant.barcode, "Barcode/QR value should be auto-generated"
    assert variant.barcode_image, "Barcode/QR image field should be populated"


@pytest.mark.django_db
def test_product_variant_string_representation():
    product = Product.objects.create(name="Roselia Ring")
    variant = ProductVariant.objects.create(product=product, size="6", color="Rose")

    s = str(variant)
    # basic smoke check – at least ensure __str__ doesn't crash
    # and that it includes the product name or SKU.
    assert "Roselia" in s or variant.sku in s
