import pytest
from decimal import Decimal
from datetime import datetime, timezone

from taxes.models import TaxRule
from taxes.services import find_applicable_tax_rule, calculate_order_tax
from sales.models import Order


class DummyOrder:
    """Lightweight stand-in for an Order for rule-matching tests."""

    def __init__(self, billing_country=None, billing_state=None):
        # These attributes are what taxes.services expects
        self.billing_country = billing_country
        # taxes.services.find_applicable_tax_rule checks `billing_state`,
        # so we only define it when we want that branch to be used.
        if billing_state is not None:
            self.billing_state = billing_state


@pytest.mark.django_db
def test_find_applicable_tax_rule_specific_then_country():
    # Default rule (fallback / catch-all)
    default_rule = TaxRule.objects.create(
        name="Default Tax",
        country="",
        state="",
        rate=Decimal("0.05"),
        is_default=True,
        active=True,
    )

    # Country-level rule (US)
    us_rule = TaxRule.objects.create(
        name="US Generic",
        country="US",
        state="",
        rate=Decimal("0.07"),
        is_default=False,
        active=True,
    )

    # State-level rule (US + NY)
    ny_rule = TaxRule.objects.create(
        name="NY State Tax",
        country="US",
        state="NY",
        rate=Decimal("0.08875"),
        is_default=False,
        active=True,
    )

    # 1) Most specific: US + NY should match ny_rule
    order_ny = DummyOrder(billing_country="US", billing_state="NY")
    rule_ny = find_applicable_tax_rule(order_ny)
    assert rule_ny == ny_rule

    # 2) Country only: US with no `billing_state` attribute should match us_rule
    #    Here we deliberately do NOT set billing_state on the DummyOrder.
    order_us = DummyOrder(billing_country="US")
    rule_us = find_applicable_tax_rule(order_us)
    assert rule_us == us_rule

    # 3) No country/state at all: queryset is unfiltered, so the first active
    #    rule is returned (which is default_rule, created first).
    order_none = DummyOrder()
    rule_none = find_applicable_tax_rule(order_none)
    assert rule_none == default_rule


@pytest.mark.django_db
def test_calculate_order_tax_applies_rate_and_shipping():
    # Minimal valid Order instance:
    # - order_number required (unique)
    # - order_date required (NOT NULL)
    # - billing_country optional in the model, but set to 'US' for realism
    order = Order.objects.create(
        order_number="TEST-ORDER-1",
        order_date=datetime.now(timezone.utc),
        billing_country="US",
        subtotal_amount=Decimal("100.00"),
        shipping_amount=Decimal("10.00"),
        discount_amount=Decimal("5.00"),
    )

    # Explicitly call the tax service (Order.save() already calls update_tax,
    # but we invoke calculate_order_tax directly here to test the service).
    calculate_order_tax(order)
    order.refresh_from_db()

    # Taxable base = subtotal + shipping = 110 → tax = 11
    assert order.tax_amount == Decimal("11.00")

    # Total = subtotal + shipping + tax - discount
    #        100 + 10 + 11 - 5 = 116
    assert order.total_amount == Decimal("116.00")
