import pytest
from django.urls import reverse
from rest_framework.test import APIClient
from django.contrib.auth import get_user_model

from integrations.models import StoreIntegration


@pytest.mark.django_db
def test_store_integration_sync_endpoint_calls_correct_service(monkeypatch):
    User = get_user_model()
    admin = User.objects.create_superuser("admin", "admin@example.com", "pass")

    integ = StoreIntegration.objects.create(
        platform=StoreIntegration.WOO,
        name="Test Woo Store",
        base_url="https://example.com",
        api_key="key",
        api_secret="secret",
        is_active=True,
    )

    calls = {}

    def fake_sync_woocommerce_orders(integration, since=None):
        # record args for assertion
        calls["integration"] = integration
        calls["since"] = since
        return 3

    monkeypatch.setattr(
        "integrations.api_views.sync_woocommerce_orders",
        fake_sync_woocommerce_orders,
    )

    client = APIClient()
    client.force_authenticate(user=admin)

    url = reverse("store-integration-sync", kwargs={"pk": integ.pk})
    response = client.post(url)

    assert response.status_code == 200
    data = response.json()
    assert data["orders_synced"] == 3
    assert calls["integration"] == integ
    assert calls["since"] == integ.last_synced_at
