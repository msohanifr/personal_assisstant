import pytest

from catalog.models import Product, ProductVariant
from catalog.utils import generate_barcode_for_variant


@pytest.mark.django_db
def test_build_sku_for_variant_basic_uniqueness():
    product = Product.objects.create(name="Roselia Ring")

    # Two "identical" variants – the SKU builder must still make them unique
    v1 = ProductVariant.objects.create(product=product, size="6", color="Yellow")
    v2 = ProductVariant.objects.create(product=product, size="6", color="Yellow")

    # Both variants should have non-empty SKUs
    assert v1.sku
    assert v2.sku

    # And SKUs must be different
    assert v1.sku != v2.sku

    # Usually v2 will have a -2 suffix, but we only assert that
    # they share the same base prefix to avoid overfitting the test.
    base1 = v1.sku.split("-")[0]
    base2 = v2.sku.split("-")[0]
    assert base1 == base2


@pytest.mark.django_db
def test_generate_barcode_for_variant_creates_image(tmp_path, settings):
    # Use a temporary MEDIA_ROOT so we don't pollute your real media dir
    settings.MEDIA_ROOT = tmp_path

    product = Product.objects.create(name="Pegasus Pendant")
    variant = ProductVariant.objects.create(product=product, size="M")

    # The model's save() override should already have called the generator
    assert variant.barcode, "Barcode string should be set on save"
    assert variant.barcode_image, "Barcode/QR image should be generated on save"

    old_barcode = variant.barcode

    # Calling the generator again should be safe/idempotent
    changed = generate_barcode_for_variant(variant)
    variant.save()

    assert isinstance(changed, bool)
    assert variant.barcode  # still non-empty
    assert variant.barcode_image  # still points to an image

    # The file should actually exist on disk
    from pathlib import Path

    img_path = Path(settings.MEDIA_ROOT) / variant.barcode_image.name
    assert img_path.exists()

    # And the logical barcode value should not disappear
    assert variant.barcode == old_barcode
