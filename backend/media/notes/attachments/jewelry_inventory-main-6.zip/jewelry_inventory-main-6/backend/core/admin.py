from django.contrib import admin

# Register your models here.
from . import models


@admin.register(models.Location)
class LocationAdmin(admin.ModelAdmin):
    list_display = ("name", "code", "is_active")
    search_fields = ("name", "code")


@admin.register(models.Customer)
class CustomerAdmin(admin.ModelAdmin):
    list_display = (
        "first_name",
        "last_name",
        "email",
        "billing_country",
        "billing_region",
    )
    search_fields = ("first_name", "last_name", "email")
