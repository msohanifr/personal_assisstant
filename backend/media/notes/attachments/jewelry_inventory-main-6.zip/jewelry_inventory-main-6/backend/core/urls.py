from django.contrib import admin
from django.urls import include, path
from rest_framework.routers import DefaultRouter

from config.settings import (
    ADMIN_INDEX_TITLE,
    ADMIN_SITE_HEADER,
    ADMIN_SITE_TITLE,
)
from expenses import views as expense_views
from sales import views as sales_views

from . import views

# Admin branding
admin.site.site_header = ADMIN_SITE_HEADER
admin.site.site_title = ADMIN_SITE_TITLE
admin.site.index_title = ADMIN_INDEX_TITLE

# DRF router for viewsets
router = DefaultRouter()
router.register(r"locations", views.LocationViewSet, basename="location")
router.register(r"customers", views.CustomerViewSet, basename="customer")

urlpatterns = [
    # CATALOG API
    path("api/catalog/", include("catalog.urls")),

    # TAX / SALES SUMMARY API
    path(
        "api/taxes/summary/",
        sales_views.tax_summary_api,
        name="taxes_summary_api",
    ),

    # EXPENSES API
    path(
        "api/expenses/summary/",
        expense_views.expense_summary_api,
        name="expenses_summary_api",
    ),
    path(
        "api/expenses/create/",
        expense_views.expense_create_api,
        name="expenses_create_api",
    ),
    path(
        "api/expenses/<int:pk>/",
        expense_views.expense_update_api,
        name="expenses_update_api",
    ),
    path(
        "api/expenses/<int:pk>/upload_receipt/",
        expense_views.expense_upload_receipt_api,
        name="expenses_upload_receipt_api",
    ),
    path(
        "api/expenses/export/",
        expense_views.expense_export_csv,
        name="expenses_export_api",
    ),

    # SCAN API (used by Scan page)
    path("api/scan/lookup/", views.scan_lookup_api, name="scan_lookup_api"),

    # AUTH API – now delegated to the accounts app
    path("api/auth/", include("accounts.urls")),

    # DASHBOARD SUMMARY API
    path(
        "api/dashboard/summary/",
        views.dashboard_summary,
        name="dashboard_summary_api",
    ),

    # VIEWSETS / OTHER API ROUTES
    path("api/", include(router.urls)),
    # Suppliers (vendors) API for contacts
    path("api/", include("suppliers.urls")),
    path("api/", include("api.urls")),
]