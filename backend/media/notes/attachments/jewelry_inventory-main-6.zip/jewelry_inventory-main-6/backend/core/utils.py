import io

from django.core.files.base import ContentFile
import re

from types import SimpleNamespace
from django.db import OperationalError, ProgrammingError

import qrcode
from qrcode.constants import ERROR_CORRECT_L

from string import digits, ascii_uppercase

ALPHABET = digits + ascii_uppercase


def encode_base36(num: int) -> str:
    if num == 0:
        return "0"
    out = []
    while num:
        num, rem = divmod(num, 36)
        out.append(ALPHABET[rem])
    return "".join(reversed(out))


# core/utils.py


def get_app_settings():
    """
    Lazy + safe loader for AppSettings.

    - Imports AppSettings only when called.
    - Catches DB errors so Django can import modules during CI, migrations,
      and system checks even if the database host isn't reachable yet.
    """
    from appsettings.models import AppSettings

    try:
        return AppSettings.load()
    except (OperationalError, ProgrammingError):
        # DB not ready (migrations, CI, or no DB yet) – return safe defaults
        return SimpleNamespace(
            barcode_module_width=0.18,
            barcode_module_height=6.0,
            barcode_show_text=False,
            barcode_quiet_zone=1.0,
            barcode_dpi=300,
        )
    except Exception:
        # Any other unexpected error – fail safe in CI / checks
        return SimpleNamespace(
            barcode_module_width=0.18,
            barcode_module_height=6.0,
            barcode_show_text=False,
            barcode_quiet_zone=1.0,
            barcode_dpi=300,
        )


def generate_barcode_for_variant(variant) -> bool:
    """
    Ensure the variant has a minimal barcode value and QR image.

    Returns True if it changed the instance (barcode or image set),
    False if nothing needed to be done.

    NOTE:
    - We keep the function name and fields (barcode, barcode_image)
      so we don't need DB migrations or call-site changes.
    - The image stored in barcode_image is now a QR code PNG.
    """
    changed = False

    # 1) Ensure we have a value to encode.
    #    For now we keep using the SKU as the encoded string.
    #    If you want *smaller* QR codes, you can switch to a shorter
    #    internal code here instead of SKU.
    if not variant.barcode:
        # Ensure we have a PK first
        if not variant.pk:
            variant.save()  # initial save to get ID
        variant.barcode = encode_base36(variant.pk)  # e.g. '2N9C'
        changed = True

    # 2) If an image already exists and you don't want to overwrite,
    #    keep this early return. If you want to regenerate with new
    #    settings, comment this out.
    if variant.barcode_image:
        return changed

    # 3) Build a very small QR code (version 1, low error correction).
    data = variant.barcode

    qr = qrcode.QRCode(
        version=1,  # smallest QR (21x21 modules)
        error_correction=ERROR_CORRECT_L,  # low error correction = smallest size
        box_size=4,  # size of each square in pixels
        border=1,  # 1 module border – minimum while still scannable
    )
    qr.add_data(data)
    qr.make(fit=False)  # don't auto-upgrade to larger versions

    img = qr.make_image(fill_color="black", back_color="white")

    # 4) Save PNG into the ImageField
    buffer = io.BytesIO()
    img.save(buffer, format="PNG")

    file_name = f"{variant.sku}_qr.png"
    variant.barcode_image.save(file_name, ContentFile(buffer.getvalue()), save=False)
    changed = True

    return changed


def _normalize_sku_fragment(value: str, max_len: int | None = None) -> str:
    """
    Turn arbitrary text into a safe SKU fragment:
    - uppercase
    - no spaces
    - only A–Z and 0–9
    """
    if not value:
        return ""
    value = value.strip().upper().replace(" ", "")
    value = re.sub(r"[^A-Z0-9]", "", value)
    if max_len:
        value = value[:max_len]
    return value


def build_sku_for_variant(variant) -> str:
    """
    Build a SKU for a ProductVariant using product + variant info.

    Pattern (example):
      BRAND-COLL-PROD-PURITY-SIZE-COLOR-LEN

    e.g.:
      MRS-PEGA-PEGAS-24K-6-GLD-16CM
    """
    from catalog.models import ProductVariant  # local import to avoid circulars

    product = variant.product

    parts: list[str] = []

    # Brand prefix – feel free to change "MRS" to whatever you like.
    parts.append("MRS")

    # Collection fragment (first 4 chars of collection name)
    if getattr(product, "collection", None):
        parts.append(_normalize_sku_fragment(product.collection.name, max_len=4))

    # Product base: use sku_base if set, else product name
    if getattr(product, "sku_base", None):
        parts.append(_normalize_sku_fragment(product.sku_base, max_len=8))
    else:
        parts.append(_normalize_sku_fragment(product.name, max_len=8))

    # Metal / purity
    metal = getattr(product, "metal", "") or ""
    gold_purity = (getattr(product, "gold_purity", "") or "").lower()

    if metal == "gold" and gold_purity:
        # e.g. "18k" → "18K"
        parts.append(_normalize_sku_fragment(gold_purity, max_len=3))
    elif metal:
        parts.append(_normalize_sku_fragment(metal, max_len=3))

    # Size
    if variant.size:
        parts.append(_normalize_sku_fragment(variant.size, max_len=4))

    # Color (e.g. YLW / WHT / ROS)
    if variant.color:
        parts.append(_normalize_sku_fragment(variant.color, max_len=3))

    # Chain length (e.g. 16CM)
    if variant.chain_length_cm:
        try:
            length_int = int(variant.chain_length_cm)
            parts.append(f"{length_int}CM")
        except (TypeError, ValueError):
            pass

    # Join all non-empty fragments
    base_sku = "-".join([p for p in parts if p])

    # Ensure uniqueness by appending -2, -3, ... if needed
    sku = base_sku
    counter = 1
    while ProductVariant.objects.filter(sku=sku).exclude(pk=variant.pk).exists():
        counter += 1
        sku = f"{base_sku}-{counter}"

    return sku
