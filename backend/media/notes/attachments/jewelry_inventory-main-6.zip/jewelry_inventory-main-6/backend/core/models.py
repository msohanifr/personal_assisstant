from django.db import models

# Create your models here.


# core/models.py
from django.db import models


class TimeStampedModel(models.Model):
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        abstract = True


class Location(TimeStampedModel):
    """Studio, shop, safebox, desk, etc."""

    class LocationType(models.TextChoices):
        STUDIO = "site", "Site / Studio"
        SHOP = "shop", "Shop / Storefront"
        STORAGE = "storage", "Storage"
        SAFEBOX = "safebox", "Safebox"
        DESK = "desk", "Desk"
        OTHER = "other", "Other"

    name = models.CharField(max_length=100)
    code = models.CharField(max_length=20, unique=True)

    # High-level classification
    location_type = models.CharField(
        max_length=20,
        choices=LocationType.choices,
        default=LocationType.STUDIO,
    )

    # Optional parent (e.g. safebox inside studio)
    parent = models.ForeignKey(
        "self",
        null=True,
        blank=True,
        related_name="children",
        on_delete=models.SET_NULL,
        help_text="Optional parent location (e.g. safebox inside a studio).",
    )

    # Normalized address parts
    street = models.CharField(max_length=200, blank=True)
    street_number = models.CharField(max_length=50, blank=True)
    address_line2 = models.CharField(max_length=200, blank=True)
    city = models.CharField(max_length=100, blank=True)
    region = models.CharField(max_length=100, blank=True, help_text="State / province")
    postcode = models.CharField(max_length=20, blank=True)
    country = models.CharField(
        max_length=2, blank=True, help_text="ISO country code, e.g. US, CA"
    )

    # Legacy single address text if you were already using it
    address = models.TextField(blank=True)

    notes = models.TextField(blank=True)

    image = models.ImageField(
        upload_to="location_photos/", blank=True, null=True
    )

    is_active = models.BooleanField(default=True)

    def __str__(self):
        return f"{self.code} – {self.name}"


class Customer(TimeStampedModel):
    """Basic customer record for tax + reporting."""

    first_name = models.CharField(max_length=100, blank=True)
    last_name = models.CharField(max_length=100, blank=True)
    email = models.EmailField(blank=True)
    phone = models.CharField(max_length=50, blank=True)

    billing_country = models.CharField(
        max_length=2, blank=True, help_text="ISO country code, e.g. US, CA"
    )
    billing_region = models.CharField(
        max_length=100, blank=True, help_text="State / province"
    )
    billing_city = models.CharField(max_length=100, blank=True)
    billing_postcode = models.CharField(max_length=20, blank=True)

    def __str__(self):
        name = f"{self.first_name} {self.last_name}".strip()
        return name or self.email or f"Customer #{self.id}"
