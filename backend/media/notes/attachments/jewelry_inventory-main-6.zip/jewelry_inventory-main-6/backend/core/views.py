from decimal import Decimal

from django.contrib.admin.views.decorators import staff_member_required
from django.contrib.auth.decorators import login_required
from django.db.models import Count, F, Q, Sum
from django.shortcuts import render

from rest_framework import viewsets
from rest_framework.decorators import api_view, permission_classes
from rest_framework.parsers import FormParser, JSONParser, MultiPartParser
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response

from core.auth import CsrfExemptSessionAuthentication
from core.permissions import IsStaffOrReadOnly

from catalog.models import Collection, Product, ProductVariant
from core.models import Location
from pricing.models import MetalPriceSnapshot
from pricing.utils import get_latest_metal_prices
from suppliers.models import Supplier

from .serializers import LocationSerializer

from core.models import Location, Customer  # add Customer
...
from .serializers import LocationSerializer, CustomerSerializer


# -------------------------------------------------------------------
# Location API (used by frontend)
# -------------------------------------------------------------------


class LocationViewSet(viewsets.ModelViewSet):
    queryset = Location.objects.all().order_by("name")
    serializer_class = LocationSerializer
    permission_classes = [IsStaffOrReadOnly]
    authentication_classes = [CsrfExemptSessionAuthentication]
    parser_classes = [JSONParser, FormParser, MultiPartParser]


class CustomerViewSet(viewsets.ModelViewSet):
    """
    Basic CRUD for customers, used by the Contacts page.
    """

    queryset = Customer.objects.all().order_by("-created_at")
    serializer_class = CustomerSerializer
    permission_classes = [IsStaffOrReadOnly]
    authentication_classes = [CsrfExemptSessionAuthentication]
    parser_classes = [JSONParser, FormParser, MultiPartParser]


# -------------------------------------------------------------------
# Legacy server-rendered dashboard / pricing views
# (frontend now uses the dashboard_summary API instead)
# -------------------------------------------------------------------


@login_required
def dashboard(request):
    # Top-level KPIs
    total_products = Product.objects.count()
    total_variants = ProductVariant.objects.count()
    total_locations = Location.objects.count()
    total_suppliers = Supplier.objects.count()

    total_stock_qty = (
        ProductVariant.objects.aggregate(total=Sum("stock_quantity"))["total"] or 0
    )

    # Low-stock variants
    low_stock_variants = (
        ProductVariant.objects.filter(
            stock_quantity__lte=F("low_stock_threshold"),
            is_discontinued=False,
        )
        .select_related("product")
        .order_by("stock_quantity", "product__name")[:10]
    )

    # Stock by collection (for chart)
    stock_by_collection_qs = (
        ProductVariant.objects.values("product__collection__name")
        .annotate(total_stock=Sum("stock_quantity"))
        .order_by("-total_stock")
    )
    stock_by_collection = [
        {
            "collection": row["product__collection__name"] or "Unassigned",
            "total_stock": row["total_stock"] or 0,
        }
        for row in stock_by_collection_qs
    ]

    # Stock by metal (for cards if needed)
    metal_display = dict(Product.METAL_CHOICES)
    stock_by_metal_qs = (
        ProductVariant.objects.values("product__metal")
        .annotate(total_stock=Sum("stock_quantity"))
        .order_by("-total_stock")
    )
    stock_by_metal = [
        {
            "metal": metal_display.get(
                row["product__metal"], row["product__metal"] or "Unknown"
            ),
            "total_stock": row["total_stock"] or 0,
        }
        for row in stock_by_metal_qs
    ]

    # Key suppliers
    top_suppliers = Supplier.objects.annotate(product_count=Count("products")).order_by(
        "-product_count", "name"
    )[:5]

    # Live metal prices (now HTML-scraped via pricing.utils)
    price_snapshot, metal_price_error = get_latest_metal_prices()
    gold_per_gram_24k = None
    if price_snapshot and price_snapshot.gold_ounce_usd:
        # 1 troy ounce = 31.1034768 g
        gold_per_gram_24k = (
            price_snapshot.gold_ounce_usd / Decimal("31.1034768")
        ).quantize(Decimal("0.01"))

    # Gold price trend (up / down / same) based on previous snapshot
    gold_trend = None
    if price_snapshot and price_snapshot.gold_ounce_usd:
        current_price = price_snapshot.gold_ounce_usd

        previous_snapshot = (
            MetalPriceSnapshot.objects.filter(
                created_at__lt=price_snapshot.created_at,
                gold_ounce_usd__isnull=False,
            )
            .order_by("-created_at")
            .first()
        )

        if previous_snapshot and previous_snapshot.gold_ounce_usd:
            prev_price = previous_snapshot.gold_ounce_usd

            if prev_price > 0:
                percent_change = (
                    (current_price - prev_price) / prev_price * Decimal("100")
                ).quantize(Decimal("0.01"))
            else:
                percent_change = Decimal("0.00")

            if current_price > prev_price:
                direction = "up"
            elif current_price < prev_price:
                direction = "down"
            else:
                direction = "same"

            gold_trend = {
                "direction": direction,
                "percent_change": percent_change,
                "previous_price": prev_price,
                "current_price": current_price,
            }

    # Simple suggested repricing preview for a few gold products
    sample_repricing = []
    if gold_per_gram_24k is not None:
        sample_products = Product.objects.filter(
            metal="gold", weight_grams__isnull=False, active=True
        ).order_by("-updated_at")[:5]

        default_markup = Decimal("2.5")  # 2.5x cost — adjust as desired

        for p in sample_products:
            try:
                purity_str = (p.gold_purity or "").lower().replace("k", "")
                purity = Decimal(purity_str) if purity_str else Decimal("24")
            except Exception:
                purity = Decimal("24")

            purity_factor = purity / Decimal("24")
            metal_cost = gold_per_gram_24k * Decimal(p.weight_grams) * purity_factor
            suggested_price = (metal_cost * default_markup).quantize(Decimal("0.01"))

            sample_repricing.append(
                {
                    "product": p,
                    "current_price": p.base_price,
                    "suggested_price": suggested_price,
                    "purity": purity,
                    "weight_grams": p.weight_grams,
                }
            )

    context = {
        "total_products": total_products,
        "total_variants": total_variants,
        "total_locations": total_locations,
        "total_suppliers": total_suppliers,
        "total_stock_qty": total_stock_qty,
        "low_stock_variants": low_stock_variants,
        "stock_by_collection": stock_by_collection,
        "stock_by_metal": stock_by_metal,
        "top_suppliers": top_suppliers,
        "price_snapshot": price_snapshot,
        "metal_price_error": metal_price_error,
        "gold_per_gram_24k": gold_per_gram_24k,
        "sample_repricing": sample_repricing,
        "gold_trend": gold_trend,
    }
    return render(request, "core/dashboard.html", context)


@staff_member_required
def bulk_reprice_from_live_gold(request):
    """
    Staff-only: use latest gold spot to update base_price for gold products.

    Now uses the JM Bullion–scraped price via get_latest_metal_prices().
    """
    snapshot, error = get_latest_metal_prices()
    if not snapshot or not snapshot.gold_ounce_usd:
        return render(
            request,
            "core/reprice_result.html",
            {
                "error": error
                or "No gold price available from the live gold price source.",
            },
        )

    gold_per_gram_24k = snapshot.gold_ounce_usd / Decimal("31.1034768")

    if request.method == "POST":
        markup_str = request.POST.get("markup", "2.5")
        try:
            markup = Decimal(markup_str)
        except Exception:
            markup = Decimal("2.5")

        updated_rows = []

        qs = Product.objects.filter(
            metal="gold", weight_grams__isnull=False, active=True
        )
        for p in qs:
            try:
                purity_str = (p.gold_purity or "").lower().replace("k", "")
                purity = Decimal(purity_str) if purity_str else Decimal("24")
            except Exception:
                purity = Decimal("24")

            purity_factor = purity / Decimal("24")
            metal_cost = gold_per_gram_24k * Decimal(p.weight_grams) * purity_factor
            new_price = (metal_cost * markup).quantize(Decimal("0.01"))
            old_price = p.base_price
            p.base_price = new_price
            p.save(update_fields=["base_price"])
            updated_rows.append((p, old_price, new_price))

        return render(
            request,
            "core/reprice_result.html",
            {
                "snapshot": snapshot,
                "gold_per_gram_24k": gold_per_gram_24k.quantize(Decimal("0.01")),
                "markup": markup,
                "updated_rows": updated_rows,
                "updated_count": len(updated_rows),
            },
        )

    # GET: show a simple confirmation / form
    return render(
        request,
        "core/reprice_form.html",
        {
            "snapshot": snapshot,
            "gold_per_gram_24k": gold_per_gram_24k.quantize(Decimal("0.01")),
        },
    )


# -------------------------------------------------------------------
# Legacy label & scan HTML views
# -------------------------------------------------------------------


@login_required
def label_print(request):
    """
    Render a print-friendly page of barcode labels for product variants.
    Filters by search query, collection, supplier, and in-stock flag.
    """
    q = request.GET.get("q", "").strip()
    collection_id = request.GET.get("collection", "").strip()
    supplier_id = request.GET.get("supplier", "").strip()
    only_in_stock = request.GET.get("only_in_stock") == "1"

    variants = ProductVariant.objects.select_related(
        "product",
        "product__collection",
        "product__default_supplier",
    )

    if q:
        variants = variants.filter(
            Q(sku__icontains=q)
            | Q(product__name__icontains=q)
            | Q(product__collection__name__icontains=q)
        )

    if collection_id:
        variants = variants.filter(product__collection_id=collection_id)

    if supplier_id:
        variants = variants.filter(product__default_supplier_id=supplier_id)

    if only_in_stock:
        variants = variants.filter(stock_quantity__gt=0)

    variants = variants.order_by(
        "product__collection__name",
        "product__name",
        "sku",
    )

    collections = Collection.objects.all().order_by("name")
    suppliers = Supplier.objects.all().order_by("name")

    context = {
        "variants": variants,
        "q": q,
        "only_in_stock": only_in_stock,
        "collections": collections,
        "suppliers": suppliers,
        "selected_collection": collection_id,
        "selected_supplier": supplier_id,
    }
    return render(request, "core/labels.html", context)


@login_required
def scan_lookup(request):
    """
    Simple lookup page: you can type or scan a barcode / SKU and see the variant.
    Works with USB barcode readers (they act like a keyboard).
    """
    code = request.GET.get("code") or request.POST.get("code")
    variant = None

    if code:
        variant = (
            ProductVariant.objects.select_related("product")
            .filter(barcode=code)
            .first()
        )
        if not variant:
            # Fallback: search by SKU if barcode not found
            variant = (
                ProductVariant.objects.select_related("product")
                .filter(sku=code)
                .first()
            )

    context = {
        "code": code or "",
        "variant": variant,
    }
    return render(request, "core/scan.html", context)


# -------------------------------------------------------------------
# Dashboard summary API (used by React frontend)
# -------------------------------------------------------------------


@api_view(["GET"])
@permission_classes([IsAuthenticated])
def dashboard_summary(request):
    # Top-level KPIs
    total_products = Product.objects.count()
    total_variants = ProductVariant.objects.count()
    total_locations = Location.objects.count()
    total_suppliers = Supplier.objects.count()

    total_stock_qty = (
        ProductVariant.objects.aggregate(total=Sum("stock_quantity"))["total"] or 0
    )

    # Low-stock variants (top 10)
    low_stock_qs = (
        ProductVariant.objects.filter(
            stock_quantity__lte=F("low_stock_threshold"),
            is_discontinued=False,
        )
        .select_related("product")
        .order_by("stock_quantity", "product__name")[:10]
    )
    low_stock_variants = [
        {
            "id": v.id,
            "sku": v.sku,
            "product_name": v.product.name,
            "stock_quantity": v.stock_quantity,
            "low_stock_threshold": v.low_stock_threshold,
        }
        for v in low_stock_qs
    ]

    # Stock by collection (for chart)
    stock_by_collection_qs = (
        ProductVariant.objects.values("product__collection__name")
        .annotate(total_stock=Sum("stock_quantity"))
        .order_by("-total_stock")
    )
    stock_by_collection = [
        {
            "collection": row["product__collection__name"] or "Unassigned",
            "total_stock": row["total_stock"] or 0,
        }
        for row in stock_by_collection_qs
    ]

    # Stock by metal
    metal_display = dict(Product.METAL_CHOICES)
    stock_by_metal_qs = (
        ProductVariant.objects.values("product__metal")
        .annotate(total_stock=Sum("stock_quantity"))
        .order_by("-total_stock")
    )
    stock_by_metal = [
        {
            "metal": metal_display.get(
                row["product__metal"], row["product__metal"] or "Unknown"
            ),
            "total_stock": row["total_stock"] or 0,
        }
        for row in stock_by_metal_qs
    ]

    # Key suppliers
    top_suppliers_qs = (
        Supplier.objects.annotate(product_count=Count("products"))
        .order_by("-product_count", "name")[:5]
    )
    top_suppliers = [
        {
            "id": s.id,
            "name": s.name,
            "product_count": s.product_count,
        }
        for s in top_suppliers_qs
    ]

    # Metal prices + trend (from HTML scraped source)
    price_snapshot, metal_price_error = get_latest_metal_prices()
    gold_per_gram_24k = None
    price_info = None
    gold_trend_info = None

    if price_snapshot and price_snapshot.gold_ounce_usd:
        gold_per_gram_24k = (
            price_snapshot.gold_ounce_usd / Decimal("31.1034768")
        ).quantize(Decimal("0.01"))

        raw_payload = price_snapshot.raw_payload or {}
        price_info = {
            "gold_ounce_usd": str(price_snapshot.gold_ounce_usd),
            "base_currency": price_snapshot.base_currency,
            "created_at": price_snapshot.created_at.isoformat(),
            "source": raw_payload.get("source", "unknown"),
            "source_url": raw_payload.get("url"),
        }

        previous_snapshot = (
            MetalPriceSnapshot.objects.filter(
                created_at__lt=price_snapshot.created_at,
                gold_ounce_usd__isnull=False,
            )
            .order_by("-created_at")
            .first()
        )

        if previous_snapshot and previous_snapshot.gold_ounce_usd:
            current_price = price_snapshot.gold_ounce_usd
            prev_price = previous_snapshot.gold_ounce_usd

            if prev_price > 0:
                percent_change = (
                    (current_price - prev_price) / prev_price * Decimal("100")
                ).quantize(Decimal("0.01"))
            else:
                percent_change = Decimal("0.00")

            if current_price > prev_price:
                direction = "up"
            elif current_price < prev_price:
                direction = "down"
            else:
                direction = "same"

            gold_trend_info = {
                "direction": direction,
                "percent_change": str(percent_change),
            }

    # Sample repricing preview
    sample_repricing = []
    if gold_per_gram_24k is not None:
        sample_products = (
            Product.objects.filter(
                metal="gold", weight_grams__isnull=False, active=True
            )
            .order_by("-updated_at")[:5]
        )

        default_markup = Decimal("2.5")

        for p in sample_products:
            try:
                purity_str = (p.gold_purity or "").lower().replace("k", "")
                purity = Decimal(purity_str) if purity_str else Decimal("24")
            except Exception:
                purity = Decimal("24")

            purity_factor = purity / Decimal("24")
            metal_cost = gold_per_gram_24k * Decimal(p.weight_grams) * purity_factor
            suggested_price = (metal_cost * default_markup).quantize(
                Decimal("0.01")
            )

            sample_repricing.append(
                {
                    "product_id": p.id,
                    "name": p.name,
                    "purity": str(purity),
                    "weight_grams": float(p.weight_grams)
                    if p.weight_grams is not None
                    else None,
                    "current_price": str(p.base_price)
                    if p.base_price is not None
                    else None,
                    "suggested_price": str(suggested_price),
                    "currency": p.currency,
                }
            )

    data = {
        "total_products": total_products,
        "total_variants": total_variants,
        "total_locations": total_locations,
        "total_suppliers": total_suppliers,
        "total_stock_qty": total_stock_qty,
        "total_stock_quantity": total_stock_qty,  # backward compatibility
        "low_stock_variants": low_stock_variants,
        "stock_by_collection": stock_by_collection,
        "stock_by_metal": stock_by_metal,
        "top_suppliers": top_suppliers,
        "price_snapshot": price_info,
        "metal_price_error": metal_price_error,
        "gold_per_gram_24k": (
            str(gold_per_gram_24k) if gold_per_gram_24k is not None else None
        ),
        "gold_trend": gold_trend_info,
        "sample_repricing": sample_repricing,
    }
    return Response(data)


# -------------------------------------------------------------------
# Scan API
# -------------------------------------------------------------------


@api_view(["GET"])
@permission_classes([IsAuthenticated])
def scan_lookup_api(request):
    """
    API version of scan_lookup: accepts ?code=... and returns variant data as JSON.
    """
    code = (request.query_params.get("code") or "").strip()

    if not code:
        return Response({"code": "", "variant": None})

    variant = (
        ProductVariant.objects.select_related("product").filter(barcode=code).first()
    )

    if not variant:
        variant = (
            ProductVariant.objects.select_related("product").filter(sku=code).first()
        )

    if not variant:
        return Response({"code": code, "variant": None})

    data = {
        "id": variant.id,
        "sku": variant.sku,
        "barcode": variant.barcode,
        "name": variant.product.name,
        "collection": (
            variant.product.collection.name if variant.product.collection else None
        ),
        "metal": (
            variant.product.get_metal_display()
            if hasattr(variant.product, "get_metal_display")
            else variant.product.metal
        ),
        "size": variant.size,
        "stock_quantity": variant.stock_quantity,
        "is_discontinued": variant.is_discontinued,
        "current_price": (
            str(variant.current_price)
            if hasattr(variant, "current_price") and variant.current_price is not None
            else None
        ),
    }

    return Response({"code": code, "variant": data})


# -------------------------------------------------------------------
# Labels API (for React-based label printing)
# -------------------------------------------------------------------


@api_view(["GET"])
@permission_classes([IsAuthenticated])
def label_meta_api(request):
    collections = [
        {"id": c.id, "name": c.name}
        for c in Collection.objects.all().order_by("name")
    ]
    suppliers = [
        {"id": s.id, "name": s.name}
        for s in Supplier.objects.all().order_by("name")
    ]
    return Response({"collections": collections, "suppliers": suppliers})


@api_view(["GET"])
@permission_classes([IsAuthenticated])
def label_variants_api(request):
    """
    Return variants for label printing, matching the old label_print filters.
    Supports:
      - q            (search: sku, product name, collection)
      - collection   (collection id)
      - supplier     (supplier id)
      - only_in_stock=1
      - limit        (max items, default 200)
    """
    q = (request.query_params.get("q") or "").strip()
    collection_id = (request.query_params.get("collection") or "").strip()
    supplier_id = (request.query_params.get("supplier") or "").strip()
    only_in_stock = request.query_params.get("only_in_stock") == "1"

    variants = ProductVariant.objects.select_related(
        "product",
        "product__collection",
        "product__default_supplier",
    )

    if q:
        variants = variants.filter(
            Q(sku__icontains=q)
            | Q(product__name__icontains=q)
            | Q(product__collection__name__icontains=q)
        )

    if collection_id:
        variants = variants.filter(product__collection_id=collection_id)

    if supplier_id:
        variants = variants.filter(product__default_supplier_id=supplier_id)

    if only_in_stock:
        variants = variants.filter(stock_quantity__gt=0)

    variants = variants.order_by(
        "product__collection__name",
        "product__name",
        "sku",
    )

    # Safety limit so we don't render thousands at once
    try:
        limit = int(request.query_params.get("limit", "200"))
    except ValueError:
        limit = 200
    limit = max(1, min(limit, 500))
    variants = variants[:limit]

    results = []
    for v in variants:
        p = v.product
        results.append(
            {
                "id": v.id,
                "product_name": p.name,
                "collection": p.collection.name if p.collection else "",
                "sku": v.sku,
                "barcode": v.barcode,
                "barcode_image_url": v.barcode_image.url if v.barcode_image else None,
                "size": v.size or "",
                "color": v.color or "",
                "chain_length_cm": (
                    str(v.chain_length_cm) if v.chain_length_cm is not None else None
                ),
                "metal": p.metal or "",
                "gold_purity": p.gold_purity or "",
                "price": (
                    str(v.price or p.base_price)
                    if (v.price or p.base_price) is not None
                    else None
                ),
                "currency": p.currency or "USD",
                "stock_quantity": v.stock_quantity,
            }
        )

    return Response({"results": results})