from rest_framework import viewsets
from .models import Collection, Product, ProductVariant
from .serializers import (
    CollectionSerializer,
    ProductSerializer,
    ProductVariantSerializer,
)
from core.permissions import IsStaffOrReadOnly


class CollectionViewSet(viewsets.ModelViewSet):
    queryset = Collection.objects.all()
    serializer_class = CollectionSerializer
    permission_classes = [IsStaffOrReadOnly]


class ProductViewSet(viewsets.ModelViewSet):
    queryset = Product.objects.all().select_related("collection", "default_supplier")
    serializer_class = ProductSerializer
    permission_classes = [IsStaffOrReadOnly]


class ProductVariantViewSet(viewsets.ModelViewSet):
    queryset = ProductVariant.objects.all().select_related("product")
    serializer_class = ProductVariantSerializer
    permission_classes = [IsStaffOrReadOnly]
