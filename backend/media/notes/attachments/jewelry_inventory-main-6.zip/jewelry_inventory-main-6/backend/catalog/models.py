from django.db import models

# Create your models here.
from core.models import TimeStampedModel
from suppliers.models import Supplier
from .utils import build_sku_for_variant


class Collection(TimeStampedModel):
    name = models.CharField(max_length=100, unique=True)
    slug = models.SlugField(unique=True)
    description = models.TextField(blank=True)

    def __str__(self):
        return self.name


class Product(TimeStampedModel):
    METAL_CHOICES = [
        ("gold", "Gold"),
        ("silver", "Silver"),
        ("platinum", "Platinum"),
    ]
    GOLD_PURITY_CHOICES = [
        ("14k", "14k"),
        ("18k", "18k"),
        ("22k", "22k"),
        ("24k", "24k"),
    ]

    name = models.CharField(max_length=200)
    slug = models.SlugField(unique=True)
    sku_base = models.CharField(max_length=50, unique=True)
    main_image = models.ImageField(
        upload_to="products/main/",
        blank=True,
        null=True,
        help_text="Primary product image for lists and detail pages.",
    )
    woo_id = models.BigIntegerField(
        null=True,
        blank=True,
        unique=True,
        help_text="WooCommerce product ID",
    )
    woo_permalink = models.URLField(
        blank=True,
        help_text="WooCommerce product URL",
    )
    woo_status = models.CharField(
        max_length=20,
        blank=True,
        help_text="WooCommerce status (publish, draft, etc.)",
    )
    woo_type = models.CharField(
        max_length=20,
        blank=True,
        help_text="WooCommerce product type (simple, variable, etc.)",
    )
    woo_data = models.JSONField(
        null=True,
        blank=True,
        help_text="Raw WooCommerce product payload",
    )
    primary_image_url = models.URLField(
        blank=True,
        help_text="Primary image URL from WooCommerce",
    )
    description = models.TextField(blank=True)
    collection = models.ForeignKey(
        Collection,
        related_name="products",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
    )
    metal = models.CharField(max_length=20, choices=METAL_CHOICES, default="gold")
    gold_purity = models.CharField(
        max_length=10, choices=GOLD_PURITY_CHOICES, blank=True
    )
    weight_grams = models.DecimalField(
        max_digits=8, decimal_places=3, null=True, blank=True
    )
    active = models.BooleanField(default=True)

    default_supplier = models.ForeignKey(
        Supplier,
        related_name="products",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
    )

    base_cost = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    base_price = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    currency = models.CharField(max_length=10, default="USD")

    def __str__(self):
        return self.name


class ProductVariant(TimeStampedModel):
    """Specific size / length / color combo."""

    product = models.ForeignKey(
        Product, related_name="variants", on_delete=models.CASCADE
    )
    # --- NEW: WooCommerce metadata ---
    woo_id = models.BigIntegerField(
        null=True,
        blank=True,
        unique=True,
        help_text="WooCommerce variation ID (or product ID for simple products)",
    )
    woo_parent_id = models.BigIntegerField(
        null=True,
        blank=True,
        help_text="WooCommerce parent product ID for variations",
    )
    woo_data = models.JSONField(
        null=True,
        blank=True,
        help_text="Raw WooCommerce variation payload",
    )
    image_url = models.URLField(
        blank=True,
        help_text="Variant image URL from WooCommerce (if any)",
    )

    sku = models.CharField(
        max_length=80,
        unique=True,
        blank=True,
        help_text="Leave blank to auto-generate from product + attributes.",
    )
    size = models.CharField(max_length=50, blank=True, help_text="Ring size, etc.")
    color = models.CharField(max_length=50, blank=True)
    chain_length_cm = models.DecimalField(
        max_digits=5, decimal_places=2, null=True, blank=True
    )

    # NEW: barcode fields
    barcode = models.CharField(
        max_length=64,
        unique=True,
        blank=True,
        help_text="Auto-generated; usually mirrors SKU",
    )
    barcode_image = models.ImageField(
        upload_to="barcodes/",
        blank=True,
        null=True,
        help_text="Auto-generated barcode image for labels",
    )

    stock_quantity = models.IntegerField(default=0)
    low_stock_threshold = models.IntegerField(default=1)
    backorder_allowed = models.BooleanField(default=True)
    lead_time_days = models.PositiveIntegerField(default=14)
    is_discontinued = models.BooleanField(default=False)

    cost = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    price = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)

    def __str__(self):
        return f"{self.product.name} ({self.sku})"

    def save(self, *args, **kwargs):
        # First: ensure SKU exists
        if not self.sku:
            self.sku = build_sku_for_variant(self)

        # Save once so we have a PK
        super().save(*args, **kwargs)

        # Then ensure barcode is present
        from .utils import generate_barcode_for_variant

        changed = generate_barcode_for_variant(self)
        if changed:
            # Save updated barcode fields, avoiding recursion
            super(ProductVariant, self).save(update_fields=["barcode", "barcode_image"])
