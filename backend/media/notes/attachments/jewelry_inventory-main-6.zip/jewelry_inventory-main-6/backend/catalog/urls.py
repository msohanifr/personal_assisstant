from rest_framework.routers import DefaultRouter
from . import views

router = DefaultRouter()
router.register(r"collections", views.CollectionViewSet)
router.register(r"products", views.ProductViewSet)
router.register(r"variants", views.ProductVariantViewSet)
urlpatterns = router.urls