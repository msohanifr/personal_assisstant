from django.contrib import admin
from . import models
from django.utils.safestring import mark_safe


@admin.register(models.Collection)
class CollectionAdmin(admin.ModelAdmin):
    prepopulated_fields = {"slug": ("name",)}
    list_display = ("name",)


@admin.register(models.Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ("name", "sku_base", "gold_purity", "active")
    list_filter = ("gold_purity", "collection", "active")
    search_fields = ("name", "sku_base", "description")
    prepopulated_fields = {"slug": ("name",)}


@admin.register(models.ProductVariant)
class ProductVariantAdmin(admin.ModelAdmin):
    list_display = ("sku", "product", "size", "stock_quantity", "low_stock_threshold")
    list_filter = ("product__collection", "product__gold_purity")
    search_fields = ("sku", "product__name")
    readonly_fields = ("barcode", "barcode_image_preview")

    fieldsets = (
        (None, {"fields": ("product", "sku", "size", "color", "chain_length_cm")}),
        (
            "Pricing",
            {
                "fields": ("cost", "price"),
            },
        ),
        (
            "Inventory",
            {
                "fields": (
                    "stock_quantity",
                    "low_stock_threshold",
                    "backorder_allowed",
                    "lead_time_days",
                    "is_discontinued",
                ),
            },
        ),
        (
            "Barcode",
            {
                "fields": ("barcode", "barcode_image_preview"),
            },
        ),
    )

    def barcode_image_preview(self, obj):
        if obj.barcode_image:
            return mark_safe(
                f'<img src="{obj.barcode_image.url}" height="70" alt="barcode">'
            )
        return "No barcode image yet"

    barcode_image_preview.short_description = "Barcode"
