from rest_framework import serializers
from .models import (
    Product,
    ProductVariant,
    Collection,
)


class CollectionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Collection
        fields = "__all__"


class ProductVariantSerializer(serializers.ModelSerializer):
    class Meta:
        model = ProductVariant
        fields = "__all__"


class ProductSerializer(serializers.ModelSerializer):
    variants = ProductVariantSerializer(many=True, read_only=True)
    main_image_url = serializers.SerializerMethodField()  # 🔽 add

    class Meta:
        model = Product
        fields = "__all__"  # DRF will include main_image and main_image_url automatically
        # or be explicit:
        # fields = [
        #     "id", "name", "slug", "sku_base", "main_image", "main_image_url",
        #     "collection", "default_supplier", "metal", "gold_purity", ...
        # ]

    def get_main_image_url(self, obj):
        request = self.context.get("request")
        img = getattr(obj, "main_image", None)
        if not img:
            return None
        try:
            url = img.url
        except ValueError:
            return None
        if request is not None:
            return request.build_absolute_uri(url)
        return url  
