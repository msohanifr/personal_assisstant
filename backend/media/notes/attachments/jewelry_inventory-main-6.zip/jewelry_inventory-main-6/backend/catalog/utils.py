# catalog/utils.py

from core.utils import (
    build_sku_for_variant as _build_sku_for_variant,
    generate_barcode_for_variant as _generate_barcode_for_variant,
)


def build_sku_for_variant(variant):
    """Thin wrapper so catalog models can call into the shared SKU builder."""
    return _build_sku_for_variant(variant)


def generate_barcode_for_variant(variant):
    """Thin wrapper so catalog models can call into the shared barcode generator."""
    return _generate_barcode_for_variant(variant)
