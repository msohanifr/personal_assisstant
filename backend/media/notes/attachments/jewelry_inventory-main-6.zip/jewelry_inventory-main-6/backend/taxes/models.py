# Create your models here.
from decimal import Decimal
from django.db import models


class TaxRule(models.Model):
    """
    Configurable tax rule table.

    Example:
    - "NY State Tax" 0.08875 for US/NY
    - "Canada GST" 0.050 for CA
    - "Default Tax" fallback
    """

    name = models.CharField(max_length=100)

    # Simple geographic matching; you can extend later
    country = models.CharField(max_length=2, blank=True)  # "US", "CA"
    state = models.CharField(max_length=50, blank=True)  # "NY", "CA"
    city = models.CharField(max_length=100, blank=True)
    postal_code = models.CharField(max_length=20, blank=True)

    rate = models.DecimalField(
        max_digits=6,
        decimal_places=4,
        help_text="Tax rate as a fraction (0.08875 for 8.875%).",
    )

    applies_to_shipping = models.BooleanField(
        default=True,
        help_text="If checked, tax applies to shipping too.",
    )

    is_default = models.BooleanField(
        default=False,
        help_text="Use this as fallback when nothing else matches.",
    )

    active = models.BooleanField(default=True)

    class Meta:
        verbose_name = "Tax Rule"
        verbose_name_plural = "Tax Rules"

    def __str__(self):
        return f"{self.name} ({(self.rate or Decimal('0')) * 100:.3f}%)"
