from django.urls import path
from . import views

app_name = "taxes"

urlpatterns = [
    path("dashboard/", views.tax_dashboard, name="dashboard"),
]
