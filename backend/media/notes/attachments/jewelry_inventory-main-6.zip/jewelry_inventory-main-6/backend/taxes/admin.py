from django.contrib import admin

# Register your models here.
from .models import TaxRule


@admin.register(TaxRule)
class TaxRuleAdmin(admin.ModelAdmin):
    list_display = (
        "name",
        "country",
        "state",
        "city",
        "postal_code",
        "rate",
        "applies_to_shipping",
        "is_default",
        "active",
    )
    list_filter = ("active", "is_default", "applies_to_shipping", "country", "state")
    search_fields = ("name", "country", "state", "city", "postal_code")
