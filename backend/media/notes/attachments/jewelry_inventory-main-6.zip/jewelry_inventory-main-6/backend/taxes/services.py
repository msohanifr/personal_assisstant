from decimal import Decimal
from typing import Optional

from django.db.models import Q

from taxes.models import TaxRule


def find_applicable_tax_rule(order) -> Optional[TaxRule]:
    """
    Given an order instance, find the best matching TaxRule.
    Start from most specific (country+state) and fall back to default.
    """
    qs = TaxRule.objects.filter(active=True)

    filters = Q()

    if getattr(order, "billing_country", None):
        filters &= Q(country=order.billing_country)

    if getattr(order, "billing_state", None):
        filters &= Q(state=order.billing_state)

    # You can expand with city/postal later
    if filters:
        qs = qs.filter(filters)

    rule = qs.first()
    if rule:
        return rule

    # Fallback: default rule if defined
    return TaxRule.objects.filter(is_default=True, active=True).first()


def calculate_order_tax(order) -> None:
    """
    Mutates the passed-in order: sets tax_amount and total_amount
    based on TaxRule and order amounts.
    """
    rule = find_applicable_tax_rule(order)

    subtotal = order.subtotal_amount or Decimal("0")
    shipping = order.shipping_amount or Decimal("0")
    discount = order.discount_amount or Decimal("0")

    if not rule:
        # No tax rule: zero tax, total is subtotal+shipping-discount
        order.tax_amount = Decimal("0.00")
        order.total_amount = (subtotal + shipping - discount).quantize(Decimal("0.01"))
        return

    rate = rule.rate or Decimal("0")
    taxable_base = subtotal
    if rule.applies_to_shipping:
        taxable_base += shipping

    tax = (taxable_base * rate).quantize(Decimal("0.01"))

    order.tax_amount = tax
    order.total_amount = (subtotal + shipping + tax - discount).quantize(
        Decimal("0.01")
    )
