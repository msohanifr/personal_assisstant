from django.shortcuts import render

# Create your views here.

from django.contrib.auth.decorators import login_required
from django.db.models import Sum
from django.db.models.functions import TruncMonth

from sales.models import Order  # your existing Order model


@login_required
def tax_dashboard(request):
    """
    Tax overview: totals, by month, by channel, by country.
    """
    orders_qs = Order.objects.all()

    # You can later add date filters from request.GET

    totals = orders_qs.aggregate(
        total_subtotal=Sum("subtotal_amount"),
        total_tax=Sum("tax_amount"),
        total_shipping=Sum("shipping_amount"),
        total_discount=Sum("discount_amount"),
        total_grand=Sum("total_amount"),
    )

    monthly = (
        orders_qs.annotate(month=TruncMonth("created_at"))
        .values("month")
        .annotate(
            subtotal=Sum("subtotal_amount"),
            tax=Sum("tax_amount"),
            total=Sum("total_amount"),
        )
        .order_by("month")
    )

    by_channel = (
        orders_qs.values("channel")
        .annotate(
            subtotal=Sum("subtotal_amount"),
            tax=Sum("tax_amount"),
            total=Sum("total_amount"),
        )
        .order_by("channel")
    )

    by_country = (
        orders_qs.values("billing_country")
        .annotate(
            subtotal=Sum("subtotal_amount"),
            tax=Sum("tax_amount"),
            total=Sum("total_amount"),
        )
        .order_by("billing_country")
    )

    # Effective tax rate on taxable orders
    taxable = orders_qs.filter(tax_amount__gt=0).aggregate(
        taxable_subtotal=Sum("subtotal_amount"),
        taxable_tax=Sum("tax_amount"),
    )
    if taxable["taxable_subtotal"]:
        effective_rate = (taxable["taxable_tax"] or 0) / taxable["taxable_subtotal"]
    else:
        effective_rate = 0

    context = {
        "totals": totals,
        "monthly": monthly,
        "by_channel": by_channel,
        "by_country": by_country,
        "taxable": taxable,
        "effective_rate": effective_rate,
    }
    return render(request, "taxes/tax_dashboard.html", context)
