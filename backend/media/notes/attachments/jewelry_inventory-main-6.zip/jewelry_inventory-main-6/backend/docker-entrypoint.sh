#!/bin/sh
set -e

echo "Starting entrypoint for Django..."

# Wait for PostgreSQL if configured
if [ -n "$POSTGRES_HOST" ]; then
  echo "Waiting for PostgreSQL at $POSTGRES_HOST:$POSTGRES_PORT..."
  # simple wait loop
  RETRIES=30
  until nc -z "$POSTGRES_HOST" "${POSTGRES_PORT:-5432}" || [ $RETRIES -eq 0 ]; do
    echo "Postgres is unavailable - remaining tries: $RETRIES"
    RETRIES=$((RETRIES-1))
    sleep 2
  done
fi

# Apply migrations by default
echo "Applying database migrations..."
python manage.py migrate --noinput

if [ "$DJANGO_ENV" = "prod" ] || [ "$DJANGO_ENV" = "production" ]; then
  echo "Running in PRODUCTION mode (Gunicorn + collectstatic)"

  echo "Collecting static files..."
  python manage.py collectstatic --noinput

  echo "Starting Gunicorn..."
  exec gunicorn config.wsgi:application \
      --bind 0.0.0.0:8000 \
      --workers ${GUNICORN_WORKERS:-3} \
      --timeout ${GUNICORN_TIMEOUT:-120}
else
  echo "Running in DEVELOPMENT mode (Django runserver with auto-reload)"
  exec python manage.py runserver 0.0.0.0:8000
fi
