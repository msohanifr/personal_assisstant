from django.contrib import admin

# Register your models here.
# appsettings/admin.py
from .models import AppSettings


@admin.register(AppSettings)
class AppSettingsAdmin(admin.ModelAdmin):
    def has_add_permission(self, request):
        # prevent creating multiple rows from admin
        return not AppSettings.objects.exists()
