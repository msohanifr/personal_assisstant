from django.db import models

# Create your models here.
from decimal import Decimal


class AppSettings(models.Model):
    """
    Singleton model for global application settings.
    There should only ever be one row (pk=1).
    """

    # General
    site_name = models.CharField(max_length=100, default="Marysa Inventory")
    default_currency = models.CharField(max_length=10, default="USD")
    default_country = models.CharField(
        max_length=2, default="US", help_text="Default billing/shipping country code"
    )
    default_region = models.CharField(
        max_length=100, blank=True, help_text="Default region/state"
    )

    # Barcode / label generation
    barcode_module_width = models.DecimalField(
        max_digits=5,
        decimal_places=3,
        default=Decimal("0.18"),
        help_text="Width of a single barcode bar in mm (smaller = more compact).",
    )
    barcode_module_height = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        default=Decimal("6.0"),
        help_text="Height of the barcode bars in mm.",
    )
    barcode_quiet_zone = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        default=Decimal("1.0"),
        help_text="Quiet zone (padding) around barcode in mm.",
    )
    barcode_dpi = models.PositiveIntegerField(default=300)
    barcode_show_text = models.BooleanField(
        default=False, help_text="Show human-readable text under barcode?"
    )

    # Metal price API (optional – can still default to env vars)
    metals_api_key = models.CharField(max_length=255, blank=True)
    metals_api_url = models.URLField(
        blank=True, help_text="e.g. https://www.goldapi.io/api/XAU/USD"
    )

    # Later: markup multipliers, default tax options, etc.

    def save(self, *args, **kwargs):
        # Force singleton pk
        self.pk = 1
        super().save(*args, **kwargs)

    @classmethod
    def load(cls):
        obj, created = cls.objects.get_or_create(pk=1)
        return obj

    def __str__(self):
        return "Application Settings"
