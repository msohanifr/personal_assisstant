from django import forms
from .models import AppSettings


class AppSettingsForm(forms.ModelForm):
    class Meta:
        model = AppSettings
        fields = [
            "site_name",
            "default_currency",
            "default_country",
            "default_region",
            "barcode_module_width",
            "barcode_module_height",
            "barcode_quiet_zone",
            "barcode_dpi",
            "barcode_show_text",
            "metals_api_key",
            "metals_api_url",
        ]
