from django.shortcuts import render

# Create your views here.
from django.contrib.admin.views.decorators import staff_member_required
from django.shortcuts import redirect
from django.contrib import messages

from core.utils import get_app_settings
from .forms import AppSettingsForm


@staff_member_required
def settings_view(request):
    settings_obj = get_app_settings()

    if request.method == "POST":
        form = AppSettingsForm(request.POST, instance=settings_obj)
        if form.is_valid():
            form.save()
            messages.success(request, "Settings updated.")
            return redirect("appsettings:settings")
    else:
        form = AppSettingsForm(instance=settings_obj)

    return render(request, "appsettings/settings.html", {"form": form})
