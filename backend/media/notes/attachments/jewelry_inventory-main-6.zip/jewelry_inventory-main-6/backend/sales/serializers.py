# sales/serializers.py
from decimal import Decimal

from rest_framework import serializers

from .models import SalesRecord
from catalog.models import ProductVariant


class SalesRecordSerializer(serializers.ModelSerializer):
    # Write-only input: user enters this in the form
    variant_sku = serializers.CharField(write_only=True)

    # Read-only convenience fields for the frontend
    variant_id = serializers.IntegerField(source="variant.id", read_only=True)
    product_name = serializers.CharField(
        source="variant.product.name", read_only=True
    )
    sku = serializers.CharField(source="variant.sku", read_only=True)

    class Meta:
        model = SalesRecord
        fields = [
            "id",
            "sale_date",
            "channel",
            "location",
            "customer",
            "variant",      # read-only pk
            "variant_id",
            "variant_sku",  # write-only
            "sku",
            "product_name",
            "quantity",
            "unit_price",
            "discount_amount",
            "total",
            "notes",
            "created_at",
            "updated_at",
        ]
        read_only_fields = [
            "id",
            "variant",
            "variant_id",
            "sku",
            "product_name",
            "total",
            "created_at",
            "updated_at",
        ]

    def validate(self, attrs):
        quantity = attrs.get("quantity") or 1
        unit_price = attrs.get("unit_price")
        discount_amount = attrs.get("discount_amount") or Decimal("0")

        if unit_price is None:
            raise serializers.ValidationError(
                {"unit_price": "Unit price is required."}
            )

        if quantity <= 0:
            raise serializers.ValidationError(
                {"quantity": "Quantity must be at least 1."}
            )

        # Calculate total
        attrs["total"] = quantity * unit_price - discount_amount
        if attrs["total"] < 0:
            raise serializers.ValidationError(
                {"discount_amount": "Discount cannot exceed line value."}
            )

        return attrs

    def create(self, validated_data):
        sku = validated_data.pop("variant_sku", "").strip()
        if not sku:
            raise serializers.ValidationError(
                {"variant_sku": "SKU is required."}
            )

        try:
            variant = ProductVariant.objects.select_related("product").get(sku=sku)
        except ProductVariant.DoesNotExist:
            raise serializers.ValidationError(
                {"variant_sku": "No variant found with this SKU."}
            )

        validated_data["variant"] = variant
        return super().create(validated_data)

    def update(self, instance, validated_data):
        # We don't support changing SKU/variant via this serializer
        validated_data.pop("variant_sku", None)
        return super().update(instance, validated_data)