from . import models
from django.contrib import admin

# sales/admin.py
from django.contrib import admin
from .models import Order, OrderLine, SalesRecord


@admin.register(SalesRecord)
class SalesRecordAdmin(admin.ModelAdmin):
    list_display = (
        "sale_date",
        "variant",
        "quantity",
        "unit_price",
        "total",
        "channel",
        "location",
    )
    list_filter = ("channel", "location", "sale_date")
    search_fields = (
        "variant__sku",
        "variant__product__name",
        "notes",
        "customer__first_name",
        "customer__last_name",
        "customer__email",
    )
    autocomplete_fields = ("variant", "customer", "location")


@admin.register(models.Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = (
        "order_number",
        "order_date",
        "status",
        "channel",
        "currency",
        "total_amount",
        "tax_amount",
    )
    list_filter = ("status", "channel", "billing_country", "billing_region")
    search_fields = (
        "order_number",
        "customer__first_name",
        "customer__last_name",
        "customer__email",
    )
    date_hierarchy = "order_date"


@admin.register(models.OrderLine)
class OrderLineAdmin(admin.ModelAdmin):
    list_display = (
        "order",
        "product",
        "variant",
        "quantity",
        "unit_price",
        "tax_amount",
        "line_total",
    )
    list_filter = ("order__status", "order__channel")
    search_fields = ("order__order_number", "product__name", "variant__sku")
