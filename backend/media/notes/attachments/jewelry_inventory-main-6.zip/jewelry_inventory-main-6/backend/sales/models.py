from django.db import models
from core.models import TimeStampedModel
from catalog.models import Product, ProductVariant
# sales/models.py
from django.db import models
from decimal import Decimal

from core.models import TimeStampedModel, Customer, Location
from catalog.models import ProductVariant
# Order / OrderLine already defined above, leave them as-is


class Order(TimeStampedModel):
    """Sales order, used for tax and revenue reporting."""

    STATUS_CHOICES = [
        ("pending", "Pending"),
        ("paid", "Paid"),
        ("refunded", "Refunded"),
        ("cancelled", "Cancelled"),
    ]
    CHANNEL_CHOICES = [
        ("online", "Online store"),
        ("in_store", "In-store"),
        ("wholesale", "Wholesale"),
        ("etsy", "Etsy"),
        ("other", "Other"),
    ]

    order_number = models.CharField(max_length=50, unique=True)
    customer = models.ForeignKey(
        Customer,
        related_name="orders",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
    )
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="paid")
    channel = models.CharField(max_length=20, choices=CHANNEL_CHOICES, default="online")

    order_date = models.DateTimeField(
        help_text="Date/time of sale (used for tax period)"
    )

    billing_country = models.CharField(max_length=2, blank=True)
    billing_region = models.CharField(max_length=100, blank=True)
    currency = models.CharField(max_length=10, default="USD")

    subtotal_amount = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    tax_amount = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    total_amount = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    shipping_amount = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    discount_amount = models.DecimalField(max_digits=12, decimal_places=2, default=0)

    notes = models.TextField(blank=True)

    external_source = models.CharField(
        max_length=20,
        blank=True,
        help_text="Source system: 'woocommerce', 'shopify', etc.",
    )
    external_id = models.CharField(
        max_length=64,
        blank=True,
        help_text="ID of the order in the external system.",
    )

    class Meta:
        unique_together = [
            ("external_source", "external_id"),
        ]

    def __str__(self):
        return f"Order {self.order_number}"

    def update_tax(self):
        """
        Call tax service to recalculate tax_amount and total_amount
        using TaxRule configuration.
        """
        from taxes.services import calculate_order_tax  # local import to avoid circular

        calculate_order_tax(self)

    def save(self, *args, **kwargs):
        """
        Optional: automatically recalc tax before saving.
        If you prefer manual control, remove the update_tax() call here
        and call it only in specific workflows or admin forms.
        """
        # Only recalc if subtotal is present
        if self.subtotal_amount is not None:
            self.update_tax()
        super().save(*args, **kwargs)


class OrderLine(TimeStampedModel):
    """Line item on an order."""

    order = models.ForeignKey(Order, related_name="lines", on_delete=models.CASCADE)
    product = models.ForeignKey(
        Product,
        related_name="order_lines",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
    )
    variant = models.ForeignKey(
        ProductVariant,
        related_name="order_lines",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
    )

    description = models.CharField(max_length=255, blank=True)

    quantity = models.PositiveIntegerField(default=1)
    unit_price = models.DecimalField(max_digits=12, decimal_places=2)
    line_subtotal = models.DecimalField(max_digits=12, decimal_places=2)
    tax_rate_percent = models.DecimalField(max_digits=5, decimal_places=2, default=0)
    tax_amount = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    line_total = models.DecimalField(max_digits=12, decimal_places=2)

    def __str__(self):
        return f"{self.order.order_number} – {self.description or self.product}"



class SalesRecord(TimeStampedModel):
    """
    Simple record of a sale of a specific variant.

    This is intended for quick manual sales entry (in-store, Instagram, etc.)
    and is separate from e-commerce Order/OrderLine to keep things simple.
    """

    CHANNEL_CHOICES = [
        ("store", "Store / In-person"),
        ("online", "Online (manual)"),
        ("instagram", "Instagram / Social"),
        ("phone", "Phone / WhatsApp"),
        ("other", "Other"),
    ]

    variant = models.ForeignKey(
        ProductVariant,
        related_name="sales_records",
        on_delete=models.PROTECT,
        help_text="Which specific SKU was sold.",
    )

    customer = models.ForeignKey(
        Customer,
        related_name="sales_records",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
    )

    location = models.ForeignKey(
        Location,
        related_name="sales_records",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        help_text="Optional store / location where sale happened.",
    )

    sale_date = models.DateTimeField(
        help_text="When the sale happened.",
    )

    channel = models.CharField(
        max_length=20,
        choices=CHANNEL_CHOICES,
        default="store",
    )

    quantity = models.PositiveIntegerField(default=1)
    unit_price = models.DecimalField(
        max_digits=12, decimal_places=2, help_text="Final price per unit in sale currency."
    )
    discount_amount = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        default=0,
        help_text="Total discount applied to this line (not per unit).",
    )
    total = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        help_text="Final total charged for this line (quantity * unit_price − discount_amount).",
    )

    notes = models.TextField(blank=True)

    class Meta:
        ordering = ["-sale_date", "-id"]

    def __str__(self):
        return f"{self.variant.sku} – {self.quantity} pcs on {self.sale_date.date()}"

    def recalculate_total(self):
        qty = self.quantity or 0
        unit = self.unit_price or Decimal("0")
        discount = self.discount_amount or Decimal("0")
        self.total = qty * unit - discount

    def save(self, *args, **kwargs):
        # Auto-calc total if not explicitly set
        if self.total in (None, Decimal("0")):
            self.recalculate_total()
        super().save(*args, **kwargs)