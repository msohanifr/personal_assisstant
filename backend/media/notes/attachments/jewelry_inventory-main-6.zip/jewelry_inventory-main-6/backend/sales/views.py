from datetime import datetime
from django.contrib.admin.views.decorators import staff_member_required
from django.shortcuts import render
from django.utils import timezone
from django.db.models.functions import TruncMonth
from django.db.models import Sum

from decimal import Decimal

from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response

from .models import Order

# sales/views.py (append at bottom)

from rest_framework import viewsets, permissions
from django.utils.dateparse import parse_datetime, parse_date

from .models import SalesRecord
from .serializers import SalesRecordSerializer


class SalesRecordViewSet(viewsets.ModelViewSet):
    """
    API for listing and creating Jewelry sales records.
    Used by the frontend Sales page.
    """

    serializer_class = SalesRecordSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        qs = (
            SalesRecord.objects.select_related(
                "variant",
                "variant__product",
                "location",
                "customer",
            )
            .all()
        )

        request = self.request
        start = request.query_params.get("start_date")
        end = request.query_params.get("end_date")

        if start:
            # allow both date and datetime strings
            dt = parse_datetime(start) or parse_date(start)
            if dt:
                qs = qs.filter(sale_date__gte=dt)

        if end:
            dt = parse_datetime(end) or parse_date(end)
            if dt:
                qs = qs.filter(sale_date__lte=dt)

        return qs.order_by("-sale_date", "-id")


@staff_member_required
def tax_dashboard(request):
    """
    Staff-only dashboard with all key aggregates needed for tax calculation.
    """

    # Date range filter (default: current calendar year)
    today = timezone.now().date()
    default_start = today.replace(month=1, day=1)
    default_end = today

    start_str = request.GET.get("from")
    end_str = request.GET.get("to")

    try:
        start_date = (
            datetime.strptime(start_str, "%Y-%m-%d").date()
            if start_str
            else default_start
        )
    except ValueError:
        start_date = default_start

    try:
        end_date = (
            datetime.strptime(end_str, "%Y-%m-%d").date() if end_str else default_end
        )
    except ValueError:
        end_date = default_end

    # Convert to datetimes in current timezone
    start_dt = timezone.make_aware(datetime.combine(start_date, datetime.min.time()))
    end_dt = timezone.make_aware(datetime.combine(end_date, datetime.max.time()))

    # Only include 'paid' orders in the window
    orders_qs = Order.objects.filter(
        status="paid",
        order_date__range=(start_dt, end_dt),
    )

    # Top-level aggregates

    gross_revenue = orders_qs.aggregate(total=Sum("total_amount"))["total"] or 0
    tax_collected = orders_qs.aggregate(total=Sum("tax_amount"))["total"] or 0
    shipping_total = orders_qs.aggregate(total=Sum("shipping_amount"))["total"] or 0
    discounts_total = orders_qs.aggregate(total=Sum("discount_amount"))["total"] or 0

    order_count = orders_qs.count()

    # Revenue by month (for chart)
    monthly = (
        orders_qs.annotate(month=TruncMonth("order_date"))
        .values("month")
        .annotate(
            revenue=Sum("total_amount"),
            tax=Sum("tax_amount"),
        )
        .order_by("month")
    )
    monthly_data = [
        {
            "month": m["month"].strftime("%Y-%m"),
            "revenue": float(m["revenue"] or 0),
            "tax": float(m["tax"] or 0),
        }
        for m in monthly
    ]

    # Revenue by channel
    channel_data_raw = (
        orders_qs.values("channel")
        .annotate(
            revenue=Sum("total_amount"),
            tax=Sum("tax_amount"),
        )
        .order_by("-revenue")
    )
    channel_data = [
        {
            "channel": row["channel"] or "unknown",
            "revenue": row["revenue"] or 0,
            "tax": row["tax"] or 0,
        }
        for row in channel_data_raw
    ]

    # Revenue by country/region (good for VAT / state sales tax summaries)
    country_data_raw = (
        orders_qs.values("billing_country")
        .annotate(
            revenue=Sum("total_amount"),
            tax=Sum("tax_amount"),
        )
        .order_by("-revenue")
    )
    country_data = [
        {
            "country": row["billing_country"] or "—",
            "revenue": row["revenue"] or 0,
            "tax": row["tax"] or 0,
        }
        for row in country_data_raw
    ]

    context = {
        "start_date": start_date,
        "end_date": end_date,
        "order_count": order_count,
        "gross_revenue": gross_revenue,
        "tax_collected": tax_collected,
        "shipping_total": shipping_total,
        "discounts_total": discounts_total,
        "monthly_data": monthly_data,
        "channel_data": channel_data,
        "country_data": country_data,
    }
    return render(request, "core/tax_dashboard.html", context)


@api_view(["GET"])
@permission_classes([IsAuthenticated])
def tax_summary_api(request):
    """
    JSON API for the Tax Dashboard (sales orders).
    Mirrors the staff-only HTML tax_dashboard but for the SPA.
    """
    today = timezone.now().date()

    def parse_date_param(name: str):
        value = request.query_params.get(name)
        if not value:
            return None
        try:
            return datetime.strptime(value, "%Y-%m-%d").date()
        except ValueError:
            return None

    start_date = parse_date_param("start_date")
    end_date = parse_date_param("end_date")

    # Default: current calendar year up to today
    if end_date is None:
        end_date = today
    if start_date is None:
        start_date = end_date.replace(month=1, day=1)

    # Only paid orders
    qs = Order.objects.filter(
        status="paid",
        order_date__date__gte=start_date,
        order_date__date__lte=end_date,
    )

    agg = qs.aggregate(
        gross_revenue=Sum("total_amount"),
        tax_collected=Sum("tax_amount"),
        shipping_total=Sum("shipping_amount"),
        discounts_total=Sum("discount_amount"),
    )

    order_count = qs.count()
    gross_revenue = agg["gross_revenue"] or Decimal("0")
    tax_collected = agg["tax_collected"] or Decimal("0")
    shipping_total = agg["shipping_total"] or Decimal("0")
    discounts_total = agg["discounts_total"] or Decimal("0")

    # Revenue + tax by month
    monthly_qs = (
        qs.annotate(month=TruncMonth("order_date"))
        .values("month")
        .annotate(
            revenue=Sum("total_amount"),
            tax=Sum("tax_amount"),
        )
        .order_by("month")
    )
    monthly_data = [
        {
            "month": row["month"].strftime("%Y-%m") if row["month"] else "",
            "revenue": str(row["revenue"] or Decimal("0")),
            "tax": str(row["tax"] or Decimal("0")),
        }
        for row in monthly_qs
    ]

    # Revenue + tax by sales channel
    channel_qs = (
        qs.values("channel")
        .annotate(
            revenue=Sum("total_amount"),
            tax=Sum("tax_amount"),
        )
        .order_by("channel")
    )
    channel_data = [
        {
            "channel": row["channel"] or "other",
            "revenue": str(row["revenue"] or Decimal("0")),
            "tax": str(row["tax"] or Decimal("0")),
        }
        for row in channel_qs
    ]

    # Revenue + tax by billing country
    country_qs = (
        qs.values("billing_country")
        .annotate(
            revenue=Sum("total_amount"),
            tax=Sum("tax_amount"),
        )
        .order_by("billing_country")
    )
    country_data = [
        {
            "country": row["billing_country"] or "Unknown",
            "revenue": str(row["revenue"] or Decimal("0")),
            "tax": str(row["tax"] or Decimal("0")),
        }
        for row in country_qs
    ]

    data = {
        "start_date": start_date.isoformat(),
        "end_date": end_date.isoformat(),
        "today": today.isoformat(),
        "order_count": order_count,
        "gross_revenue": str(gross_revenue),
        "tax_collected": str(tax_collected),
        "shipping_total": str(shipping_total),
        "discounts_total": str(discounts_total),
        "monthly_data": monthly_data,
        "channel_data": channel_data,
        "country_data": country_data,
    }
    return Response(data)