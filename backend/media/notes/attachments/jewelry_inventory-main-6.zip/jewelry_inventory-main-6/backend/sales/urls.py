from django.urls import path
from . import views

urlpatterns = [
    path("tax/", views.tax_dashboard, name="tax_dashboard"),
]
