from django.shortcuts import render

# Create your views here.
# backend/repairs/views.py
from datetime import date

from django.db.models import Q
from django.utils.dateparse import parse_date
from rest_framework import permissions, viewsets
from rest_framework.decorators import action
from rest_framework.response import Response

from .models import RepairTicket
from .serializers import RepairTicketSerializer


class RepairTicketViewSet(viewsets.ModelViewSet):
    """
    API for listing / creating / updating repair tickets.

    Used by the frontend Repairs dashboard.
    """

    serializer_class = RepairTicketSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        qs = RepairTicket.objects.select_related(
            "customer",
            "location",
            "variant",
            "variant__product",
        )

        params = self.request.query_params

        # status filter
        status = params.get("status")
        if status == "open":
            qs = qs.exclude(
                status__in=["completed", "delivered", "cancelled"]
            )
        elif status:
            qs = qs.filter(status=status)

        # intake date range
        start = params.get("start")
        if start:
            d = parse_date(start)
            if d:
                qs = qs.filter(intake_date__gte=d)

        end = params.get("end")
        if end:
            d = parse_date(end)
            if d:
                qs = qs.filter(intake_date__lte=d)

        # simple search
        q = (params.get("q") or "").strip()
        if q:
            qs = qs.filter(
                Q(ticket_number__icontains=q)
                | Q(description__icontains=q)
                | Q(internal_notes__icontains=q)
                | Q(customer__first_name__icontains=q)
                | Q(customer__last_name__icontains=q)
                | Q(customer__email__icontains=q)
                | Q(variant__sku__icontains=q)
                | Q(variant__product__name__icontains=q)
            )

        return qs.order_by("-intake_date", "-id")

    @action(detail=False, methods=["get"])
    def stats(self, request):
        """
        Simple stats endpoint for dashboard KPIs.
        """
        qs = self.get_queryset()
        today = date.today()

        total = qs.count()
        open_qs = qs.exclude(
            status__in=["completed", "delivered", "cancelled"]
        )
        completed_qs = qs.filter(status__in=["completed", "delivered"])
        overdue_qs = [t for t in open_qs if t.is_overdue]
        due_today_qs = open_qs.filter(promised_date=today)

        return Response(
            {
                "total": total,
                "open": open_qs.count(),
                "completed": completed_qs.count(),
                "overdue": len(overdue_qs),
                "due_today": due_today_qs.count(),
            }
        )