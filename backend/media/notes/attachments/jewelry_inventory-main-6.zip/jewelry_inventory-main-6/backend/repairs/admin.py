from django.contrib import admin

# Register your models here.
# backend/repairs/admin.py
from django.contrib import admin

from .models import RepairTicket


@admin.register(RepairTicket)
class RepairTicketAdmin(admin.ModelAdmin):
    list_display = (
        "ticket_number",
        "status",
        "priority",
        "intake_date",
        "promised_date",
        "location",
        "customer",
        "variant",
        "estimated_price",
        "actual_price",
        "is_overdue_flag",
    )
    list_filter = ("status", "priority", "source", "location", "warranty")
    search_fields = (
        "ticket_number",
        "description",
        "internal_notes",
        "customer__first_name",
        "customer__last_name",
        "customer__email",
        "variant__sku",
    )
    date_hierarchy = "intake_date"

    def is_overdue_flag(self, obj):
        return obj.is_overdue

    is_overdue_flag.boolean = True
    is_overdue_flag.short_description = "Overdue"