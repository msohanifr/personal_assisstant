# backend/repairs/serializers.py
from datetime import date

from rest_framework import serializers

from .models import RepairTicket
from catalog.models import ProductVariant


class RepairTicketSerializer(serializers.ModelSerializer):
    # Write-only SKU input to attach a variant
    variant_sku = serializers.CharField(
        write_only=True, required=False, allow_blank=True
    )

    # Read-only convenience fields
    customer_name = serializers.SerializerMethodField()
    sku = serializers.CharField(source="variant.sku", read_only=True)
    product_name = serializers.CharField(
        source="variant.product.name", read_only=True
    )
    location_name = serializers.CharField(
        source="location.name", read_only=True
    )
    is_overdue = serializers.SerializerMethodField()

    class Meta:
        model = RepairTicket
        fields = [
            "id",
            "ticket_number",
            "status",
            "priority",
            "source",
            "intake_date",
            "promised_date",
            "completed_date",
            "delivered_date",
            "warranty",
            "estimated_price",
            "actual_price",
            "description",
            "internal_notes",
            "vendor_name",
            "customer",
            "customer_name",
            "location",
            "location_name",
            "variant",
            "variant_sku",
            "sku",
            "product_name",
            "is_overdue",
            "created_at",
            "updated_at",
        ]
        read_only_fields = [
            "ticket_number",
            "created_at",
            "updated_at",
            "customer_name",
            "location_name",
            "sku",
            "product_name",
            "is_overdue",
        ]

    def get_customer_name(self, obj):
        return str(obj.customer) if obj.customer else ""

    def get_is_overdue(self, obj):
        return obj.is_overdue

    def create(self, validated_data):
        sku = validated_data.pop("variant_sku", "").strip()
        if sku:
            try:
                variant = ProductVariant.objects.select_related("product").get(
                    sku=sku
                )
            except ProductVariant.DoesNotExist:
                raise serializers.ValidationError(
                    {"variant_sku": "No variant found with this SKU."}
                )
            validated_data["variant"] = variant
        return super().create(validated_data)

    def update(self, instance, validated_data):
        # Do not allow changing SKU via update
        validated_data.pop("variant_sku", None)
        return super().update(instance, validated_data)