from django.db import models

# Create your models here.
# backend/repairs/models.py
from decimal import Decimal
from datetime import date

from django.db import models
from django.utils import timezone

from core.models import TimeStampedModel, Customer, Location
from catalog.models import ProductVariant


class RepairTicket(TimeStampedModel):
    """
    A repair ticket for a specific piece of jewelry.

    This is meant to track bench work: resizing, soldering, stone setting, etc.
    """

    STATUS_CHOICES = [
        ("intake", "Intake / New"),
        ("in_progress", "In progress"),
        ("waiting_parts", "Waiting for parts / vendor"),
        ("ready", "Ready for pickup"),
        ("completed", "Completed"),
        ("delivered", "Delivered to customer"),
        ("cancelled", "Cancelled"),
    ]

    PRIORITY_CHOICES = [
        ("low", "Low"),
        ("normal", "Normal"),
        ("rush", "Rush"),
    ]

    SOURCE_CHOICES = [
        ("store", "Store / walk-in"),
        ("mail_in", "Mail-in"),
        ("wholesale", "Wholesale / trade"),
        ("online", "Online / e-comm"),
        ("other", "Other"),
    ]

    ticket_number = models.CharField(
        max_length=32,
        unique=True,
        blank=True,
        help_text="Auto-generated like R2025-0001.",
    )

    customer = models.ForeignKey(
        Customer,
        related_name="repair_tickets",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
    )

    location = models.ForeignKey(
        Location,
        related_name="repair_tickets",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        help_text="Store / workshop handling this repair.",
    )

    variant = models.ForeignKey(
        ProductVariant,
        related_name="repair_tickets",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        help_text="Linked catalog variant, if known.",
    )

    source = models.CharField(
        max_length=20,
        choices=SOURCE_CHOICES,
        default="store",
    )

    status = models.CharField(
        max_length=20,
        choices=STATUS_CHOICES,
        default="intake",
    )

    priority = models.CharField(
        max_length=20,
        choices=PRIORITY_CHOICES,
        default="normal",
    )

    intake_date = models.DateField(
        default=date.today,
        help_text="Date the piece was received.",
    )
    promised_date = models.DateField(
        null=True,
        blank=True,
        help_text="Target ready date for the customer.",
    )
    completed_date = models.DateField(
        null=True,
        blank=True,
        help_text="When bench work was completed.",
    )
    delivered_date = models.DateField(
        null=True,
        blank=True,
        help_text="When the item was returned to the customer.",
    )

    warranty = models.BooleanField(
        default=False,
        help_text="Check if this repair is under warranty (no charge).",
    )

    estimated_price = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        default=Decimal("0.00"),
    )
    actual_price = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        default=Decimal("0.00"),
    )

    description = models.TextField(
        blank=True,
        help_text="Customer-facing description of the issue / work to be done.",
    )
    internal_notes = models.TextField(
        blank=True,
        help_text="Internal bench / workshop notes.",
    )

    vendor_name = models.CharField(
        max_length=100,
        blank=True,
        help_text="External bench jeweler / vendor if subbed out.",
    )

    class Meta:
        ordering = ["-intake_date", "-id"]
        indexes = [
            models.Index(fields=["ticket_number"]),
            models.Index(fields=["status"]),
            models.Index(fields=["promised_date"]),
        ]

    def __str__(self) -> str:
        base = self.ticket_number or f"Repair #{self.id}"
        if self.description:
            return f"{base} – {self.description[:40]}"
        return base

    @property
    def is_overdue(self) -> bool:
        """
        A ticket is considered overdue if promised_date is in the past
        and it's not in a terminal state.
        """
        if not self.promised_date:
            return False
        if self.status in ("completed", "delivered", "cancelled"):
            return False
        return self.promised_date < date.today()

    def _generate_ticket_number(self) -> str:
        """
        Generate a ticket number like R2025-0001 based on intake year
        and last sequence for that year.
        """
        year = (self.intake_date or date.today()).year
        prefix = f"R{year}"
        last = (
            RepairTicket.objects.filter(ticket_number__startswith=prefix)
            .order_by("-ticket_number")
            .first()
        )
        next_seq = 1
        if last and last.ticket_number:
            try:
                next_seq = int(last.ticket_number.split("-")[-1]) + 1
            except (ValueError, IndexError):
                next_seq = 1
        return f"{prefix}-{next_seq:04d}"

    def save(self, *args, **kwargs):
        if not self.ticket_number:
            # Ensure intake_date is set before generating ticket number
            if not self.intake_date:
                self.intake_date = timezone.now().date()
            self.ticket_number = self._generate_ticket_number()
        super().save(*args, **kwargs)