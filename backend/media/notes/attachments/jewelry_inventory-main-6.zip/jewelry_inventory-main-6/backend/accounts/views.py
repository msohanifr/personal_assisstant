from django.shortcuts import render

# Create your views here.
from django.conf import settings
from django.contrib.auth import authenticate, get_user_model, login, logout
from django.views.decorators.csrf import csrf_exempt

from rest_framework.decorators import (
    api_view,
    authentication_classes,
    permission_classes,
)
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.response import Response

from google.oauth2 import id_token as google_id_token
from google.auth.transport import requests as google_requests


@csrf_exempt
@api_view(["POST"])
@permission_classes([AllowAny])
@authentication_classes([])  # no DRF auth; we manually authenticate
def api_login(request):
    """
    Log in a user using Django's session auth.
    Expects JSON: { "username": "...", "password": "..." }

    On success:
      - Sets Django session cookie.
      - Returns basic user info for the frontend.
    """
    username = request.data.get("username")
    password = request.data.get("password")

    if not username or not password:
        return Response({"detail": "Username and password required."}, status=400)

    user = authenticate(request, username=username, password=password)
    if user is None:
        return Response({"detail": "Invalid credentials."}, status=400)

    if not user.is_active:
        return Response({"detail": "This account is disabled."}, status=403)

    login(request, user)

    return Response(
        {
            "username": user.username,
            "email": getattr(user, "email", "") or "",
            "is_staff": user.is_staff,
            "is_superuser": user.is_superuser,
            "is_accounting": getattr(user, "is_accounting", False),
        }
    )


@csrf_exempt
@api_view(["POST"])
@permission_classes([AllowAny])
@authentication_classes([])  # disable SessionAuthentication (no CSRF needed)
def api_logout(request):
    """
    SPA-friendly logout endpoint.

    - No CSRF required.
    - Works with Django session auth.
    - Idempotent (safe to call even if not logged in).
    """
    logout(request)
    return Response({"detail": "Logged out."})


@api_view(["GET"])
@permission_classes([IsAuthenticated])
def api_me(request):
    """
    Return current logged-in user info.
    Used by frontend to check if session is still valid.
    """
    user = request.user
    return Response(
        {
            "username": user.username,
            "email": getattr(user, "email", "") or "",
            "is_staff": user.is_staff,
            "is_superuser": user.is_superuser,
            "is_accounting": getattr(user, "is_accounting", False),
        }
    )


@csrf_exempt
@api_view(["POST"])
@permission_classes([AllowAny])
@authentication_classes([])  # no auth required; we verify Google token instead
def api_google_login(request):
    """
    Google OAuth login / registration.

    Frontend sends: { "id_token": "<google_id_token>" }

    Flow:
      - Verify the ID token with Google's public keys.
      - Ensure 'aud' matches settings.GOOGLE_CLIENT_ID.
      - Find or create a Django user based on the email.
      - Log the user in via Django session.
      - Return user info (same shape as api_login).
    """
    id_token_str = request.data.get("id_token")
    if not id_token_str:
        return Response({"detail": "Missing id_token."}, status=400)

    client_id = getattr(settings, "GOOGLE_CLIENT_ID", "")
    if not client_id:
        return Response(
            {"detail": "GOOGLE_CLIENT_ID is not configured on the server."},
            status=500,
        )

    try:
        # Verify the token and get the claims
        idinfo = google_id_token.verify_oauth2_token(
            id_token_str,
            google_requests.Request(),
            client_id,
        )
    except Exception as exc:
        return Response(
            {"detail": f"Invalid Google token: {exc}"}, status=400
        )

    # Basic issuer checks
    if idinfo.get("iss") not in ["accounts.google.com", "https://accounts.google.com"]:
        return Response({"detail": "Invalid token issuer."}, status=400)

    email = idinfo.get("email")
    email_verified = idinfo.get("email_verified", False)
    sub = idinfo.get("sub")  # Google user ID (not used directly, but available)
    given_name = idinfo.get("given_name", "")
    family_name = idinfo.get("family_name", "")
    full_name = idinfo.get("name", "")

    if not email:
        return Response(
            {"detail": "Google token did not include an email."}, status=400
        )

    if not email_verified:
        # You can relax this requirement if desired
        return Response(
            {"detail": "Google email is not verified."}, status=400
        )

    User = get_user_model()
    username = email  # simplest: use email as username

    user, created = User.objects.get_or_create(
        email=email,
        defaults={
            "username": username,
            "first_name": given_name or full_name,
            "last_name": family_name,
        },
    )

    # Optional domain restriction:
    # allowed_domain = "marysa.co"
    # if not email.endswith("@" + allowed_domain):
    #     return Response({"detail": "Not allowed domain."}, status=403)

    if not user.is_active:
        return Response({"detail": "This account is disabled."}, status=403)

    # Log the user in via Django session
    login(request, user)

    return Response(
        {
            "username": user.username,
            "email": user.email or "",
            "full_name": full_name or f"{user.first_name} {user.last_name}".strip(),
            "is_staff": user.is_staff,
            "is_superuser": user.is_superuser,
            "is_accounting": getattr(user, "is_accounting", False),
            "created": created,
        }
    )