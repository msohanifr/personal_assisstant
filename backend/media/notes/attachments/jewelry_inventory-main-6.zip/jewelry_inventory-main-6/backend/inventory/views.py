from rest_framework import viewsets
from rest_framework.permissions import IsAuthenticated
from core.permissions import IsStaffOrReadOnly
from .models import VariantLocationStock
from .serializers import VariantLocationStockSerializer


class VariantLocationStockViewSet(viewsets.ModelViewSet):
    queryset = VariantLocationStock.objects.all().select_related("variant", "location")
    serializer_class = VariantLocationStockSerializer
    permission_classes = [IsStaffOrReadOnly]
