from django.db import models
from core.models import TimeStampedModel
from catalog.models import ProductVariant
from core.models import Location


class VariantLocationStock(TimeStampedModel):
    """Inventory per variant per location."""

    variant = models.ForeignKey(
        ProductVariant, related_name="location_stocks", on_delete=models.CASCADE
    )
    location = models.ForeignKey(
        Location, related_name="stocks", on_delete=models.CASCADE
    )
    quantity = models.IntegerField(default=0)

    class Meta:
        unique_together = ("variant", "location")

    def __str__(self):
        return f"{self.variant.sku} @ {self.location.code}: {self.quantity}"
