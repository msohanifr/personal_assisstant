# backend/suppliers/views.py
from rest_framework import viewsets
from core.permissions import IsStaffOrReadOnly
from core.auth import CsrfExemptSessionAuthentication
from rest_framework.parsers import JSONParser, FormParser, MultiPartParser

from .serializers import SupplierSerializer
from .models import Supplier


class SupplierViewSet(viewsets.ModelViewSet):
    queryset = Supplier.objects.all().order_by("name")
    serializer_class = SupplierSerializer
    permission_classes = [IsStaffOrReadOnly]
    authentication_classes = [CsrfExemptSessionAuthentication]
    parser_classes = [JSONParser, FormParser, MultiPartParser]