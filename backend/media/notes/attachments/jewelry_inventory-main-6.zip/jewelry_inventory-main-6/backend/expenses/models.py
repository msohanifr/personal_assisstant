from django.db import models
from decimal import Decimal
from core.models import TimeStampedModel


class ExpenseCategory(models.Model):
    """
    Categories for expenses (rent, gold purchase, tools, marketing, etc.).
    """

    name = models.CharField(max_length=100, unique=True)
    code = models.CharField(
        max_length=20,
        blank=True,
        help_text="Optional short code (e.g. GOLD, RENT, MKTG).",
    )

    def __str__(self):
        return self.name


class ExpenseRecord(TimeStampedModel):
    """
    A financial record for an expense or purchase, used for
    cashflow and tax reporting.

    Examples:
    - Gold raw material purchase
    - Casting fees
    - Packaging
    - Rent
    - Marketing
    """

    TYPE_CHOICES = [
        ("inventory", "Inventory purchase"),
        ("expense", "Operating expense"),
        ("labor", "Labor / services"),
        ("shipping", "Shipping"),
        ("other", "Other"),
    ]

    payment_method_choices = [
        ("card", "Card"),
        ("cash", "Cash"),
        ("bank", "Bank transfer"),
        ("paypal", "PayPal"),
        ("other", "Other"),
    ]

    date = models.DateField(help_text="Date of the expense or purchase")
    description = models.CharField(max_length=255)
    category = models.ForeignKey(
        ExpenseCategory,
        related_name="expenses",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
    )
    type = models.CharField(
        max_length=20,
        choices=TYPE_CHOICES,
        default="expense",
    )
    vendor = models.CharField(
        max_length=255, blank=True, help_text="Supplier, landlord, etc."
    )
    currency = models.CharField(max_length=10, default="USD")

    # Monetary fields
    subtotal_amount = models.DecimalField(
        max_digits=12, decimal_places=2, default=Decimal("0.00")
    )
    tax_amount = models.DecimalField(
        max_digits=12, decimal_places=2, default=Decimal("0.00")
    )
    total_amount = models.DecimalField(
        max_digits=12, decimal_places=2, default=Decimal("0.00")
    )

    payment_method = models.CharField(
        max_length=20,
        choices=payment_method_choices,
        default="card",
    )

    # Optional link to product / variant to start associating cost-per-piece
    product = models.ForeignKey(
        "catalog.Product",
        related_name="expenses",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
    )
    variant = models.ForeignKey(
        "catalog.ProductVariant",
        related_name="expenses",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
    )
    quantity_related = models.PositiveIntegerField(
        default=0,
        help_text="Units this expense relates to (for cost per piece calculations).",
    )

    notes = models.TextField(blank=True)

    class Meta:
        ordering = ["-date", "-created_at"]

    def __str__(self):
        return f"{self.date} – {self.description} ({self.total_amount} {self.currency})"


class ExpenseReceipt(models.Model):
    """
    One or more image files attached to an ExpenseRecord
    (photo of receipt, invoice, etc.).
    """

    expense = models.ForeignKey(
        ExpenseRecord,
        related_name="receipts",
        on_delete=models.CASCADE,
    )
    image = models.ImageField(upload_to="expense_receipts/")
    uploaded_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Receipt for {self.expense_id} ({self.image.name})"
