from datetime import datetime
from django.db.models import Sum
from django.utils import timezone
from decimal import Decimal
from django.shortcuts import render, redirect
from django.contrib.admin.views.decorators import staff_member_required

from core.auth import CsrfExemptSessionAuthentication
from .models import (
    ExpenseRecord,
    ExpenseCategory,
    ExpenseReceipt,
)
from catalog.models import Product, ProductVariant
from datetime import datetime
from decimal import Decimal

from django.db.models import Sum
from django.utils import timezone

from rest_framework.decorators import api_view, permission_classes, authentication_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from datetime import datetime
from django.db.models import Sum
from django.utils import timezone
from decimal import Decimal
from django.shortcuts import render, redirect
from django.contrib.admin.views.decorators import staff_member_required

from django.views.decorators.csrf import csrf_exempt
from rest_framework.decorators import api_view, permission_classes, authentication_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response

from .models import (
    ExpenseRecord,
    ExpenseCategory,
    ExpenseReceipt,
)
from catalog.models import Product, ProductVariant
from django.http import HttpResponse
import csv
from django.utils import timezone

@staff_member_required
def expense_dashboard(request):
    """
    Staff-only dashboard for recording and reviewing expenses / purchases
    with receipt attachments and basic reporting.
    """
    # Date range filter (default: current month)
    today = timezone.now().date()
    default_start = today.replace(day=1)
    default_end = today

    start_str = request.GET.get("from")
    end_str = request.GET.get("to")

    try:
        start_date = (
            datetime.strptime(start_str, "%Y-%m-%d").date()
            if start_str
            else default_start
        )
    except ValueError:
        start_date = default_start

    try:
        end_date = (
            datetime.strptime(end_str, "%Y-%m-%d").date() if end_str else default_end
        )
    except ValueError:
        end_date = default_end

    expenses_qs = ExpenseRecord.objects.filter(date__range=(start_date, end_date))

    # Top-level aggregates
    total_spent = expenses_qs.aggregate(total=Sum("total_amount"))["total"] or Decimal(
        "0.00"
    )
    total_inventory = expenses_qs.filter(type="inventory").aggregate(
        total=Sum("total_amount")
    )["total"] or Decimal("0.00")
    total_operating = expenses_qs.exclude(type="inventory").aggregate(
        total=Sum("total_amount")
    )["total"] or Decimal("0.00")

    # By category (for mini-report / future chart)
    by_category_raw = (
        expenses_qs.values("category__name")
        .annotate(total=Sum("total_amount"))
        .order_by("-total")
    )
    by_category = [
        {
            "category": row["category__name"] or "Uncategorized",
            "total": row["total"] or 0,
        }
        for row in by_category_raw
    ]

    # Recent records
    latest_expenses = expenses_qs.select_related("category").order_by(
        "-date", "-created_at"
    )[:20]

    categories = ExpenseCategory.objects.all().order_by("name")

    if request.method == "POST":
        # Process new expense form
        date_str = request.POST.get("date") or str(today)
        description = request.POST.get("description", "").strip()
        category_id = request.POST.get("category") or None
        type_value = request.POST.get("type") or "expense"
        vendor = request.POST.get("vendor", "").strip()
        currency = request.POST.get("currency", "USD")
        subtotal_str = request.POST.get("subtotal_amount") or "0"
        tax_str = request.POST.get("tax_amount") or "0"
        total_str = request.POST.get("total_amount") or "0"
        payment_method = request.POST.get("payment_method") or "card"
        notes = request.POST.get("notes", "").strip()

        # Optional product/variant link
        product_id = request.POST.get("product") or None
        variant_id = request.POST.get("variant") or None
        quantity_related_str = request.POST.get("quantity_related") or "0"

        try:
            date_obj = datetime.strptime(date_str, "%Y-%m-%d").date()
        except ValueError:
            date_obj = today

        try:
            subtotal = Decimal(subtotal_str)
        except Exception:
            subtotal = Decimal("0.00")

        try:
            tax_amount = Decimal(tax_str)
        except Exception:
            tax_amount = Decimal("0.00")

        try:
            total_amount = Decimal(total_str)
        except Exception:
            total_amount = subtotal + tax_amount

        try:
            quantity_related = int(quantity_related_str)
        except ValueError:
            quantity_related = 0

        category = None
        if category_id:
            category = ExpenseCategory.objects.filter(pk=category_id).first()

        product = None
        if product_id:
            product = Product.objects.filter(pk=product_id).first()

        variant = None
        if variant_id:
            variant = ProductVariant.objects.filter(pk=variant_id).first()

        expense = ExpenseRecord.objects.create(
            date=date_obj,
            description=description or "Expense",
            category=category,
            type=type_value,
            vendor=vendor,
            currency=currency,
            subtotal_amount=subtotal,
            tax_amount=tax_amount,
            total_amount=total_amount,
            payment_method=payment_method,
            product=product,
            variant=variant,
            quantity_related=quantity_related,
            notes=notes,
        )

        # Handle receipt uploads (multiple files)
        for f in request.FILES.getlist("receipts"):
            ExpenseReceipt.objects.create(expense=expense, image=f)

        # Redirect to clear POST and show updated list
        return redirect("expense_dashboard")

    context = {
        "start_date": start_date,
        "end_date": end_date,
        "total_spent": total_spent,
        "total_inventory": total_inventory,
        "total_operating": total_operating,
        "by_category": by_category,
        "latest_expenses": latest_expenses,
        "categories": categories,
        "today": today,
    }
    return render(request, "core/expense_dashboard.html", context)


@api_view(["GET"])
@permission_classes([IsAuthenticated])
def expense_summary_api(request):
    """
    JSON API for the Expense Dashboard.
    """
    today = timezone.now().date()

    def parse_date_param(name: str):
        value = request.query_params.get(name)
        if not value:
            return None
        try:
            return datetime.strptime(value, "%Y-%m-%d").date()
        except ValueError:
            return None

    start_date = parse_date_param("start_date")
    end_date = parse_date_param("end_date")

    if end_date is None:
        end_date = today
    if start_date is None:
        start_date = today.replace(day=1)

    qs = ExpenseRecord.objects.filter(date__gte=start_date, date__lte=end_date)

    total_spent = qs.aggregate(total=Sum("total_amount"))["total"] or Decimal("0.00")
    total_inventory = (
        qs.filter(type="inventory").aggregate(total=Sum("total_amount"))["total"]
        or Decimal("0.00")
    )
    total_operating = (
        qs.exclude(type="inventory").aggregate(total=Sum("total_amount"))["total"]
        or Decimal("0.00")
    )

    by_category_qs = (
        qs.values("category__name")
        .annotate(total=Sum("total_amount"))
        .order_by("-total")
    )
    by_category = [
        {
            "category": row["category__name"] or "Uncategorized",
            "total": str(row["total"] or Decimal("0.00")),
        }
        for row in by_category_qs
    ]

    latest_qs = (
        qs.select_related("category")
        .prefetch_related("receipts")
        .order_by("-date", "-created_at")[:25]
    )

    latest_expenses = []
    for e in latest_qs:
        latest_expenses.append(
            {
                "id": e.id,
                "date": e.date.isoformat(),
                "description": e.description,
                "type": e.type,
                "type_display": e.get_type_display(),
                "category_name": e.category.name if e.category else None,
                "vendor": e.vendor or "",
                "total_amount": str(e.total_amount),
                "currency": e.currency,
                "receipt_count": e.receipts.count(),
            }
        )

    categories_qs = ExpenseCategory.objects.order_by("name")
    categories = [
        {"id": c.id, "name": c.name, "code": c.code or ""} for c in categories_qs
    ]

    data = {
        "start_date": start_date.isoformat(),
        "end_date": end_date.isoformat(),
        "today": today.isoformat(),
        "total_spent": str(total_spent),
        "total_inventory": str(total_inventory),
        "total_operating": str(total_operating),
        "by_category": by_category,
        "latest_expenses": latest_expenses,
        "categories": categories,
    }
    return Response(data)


from rest_framework.permissions import IsAuthenticated
from rest_framework.decorators import api_view, permission_classes
from django.views.decorators.csrf import csrf_exempt

@csrf_exempt
@api_view(["POST"])
@authentication_classes([CsrfExemptSessionAuthentication])
@permission_classes([IsAuthenticated])
def expense_create_api(request):
    """
    Create a new ExpenseRecord from JSON.

    Expected JSON body:
    {
      "date": "YYYY-MM-DD",
      "type": "inventory" | "operating",
      "category_id": 1 (optional),
      "description": "...",
      "vendor": "...",
      "total_amount": "123.45",
      "currency": "USD"
    }
    """
    data = request.data

    date_str = (data.get("date") or "").strip()
    type_str = (data.get("type") or "").strip()
    description = (data.get("description") or "").strip()
    vendor = (data.get("vendor") or "").strip()
    total_amount_str = (data.get("total_amount") or "").strip()
    currency = (data.get("currency") or "USD").strip()
    category_id = data.get("category_id")

    if not date_str:
        return Response({"detail": "Date is required."}, status=400)
    if not type_str:
        return Response({"detail": "Type is required."}, status=400)
    if not total_amount_str:
        return Response({"detail": "Total amount is required."}, status=400)

    from datetime import datetime
    from decimal import Decimal
    from .models import ExpenseCategory, ExpenseRecord

    try:
        date = datetime.strptime(date_str, "%Y-%m-%d").date()
    except ValueError:
        return Response(
            {"detail": "Invalid date format, expected YYYY-MM-DD."}, status=400
        )

    try:
        total_amount = Decimal(total_amount_str)
    except Exception:
        return Response({"detail": "Invalid total amount."}, status=400)

    category = None
    if category_id:
        try:
            category = ExpenseCategory.objects.get(id=category_id)
        except ExpenseCategory.DoesNotExist:
            return Response({"detail": "Invalid category."}, status=400)

    expense = ExpenseRecord.objects.create(
        date=date,
        type=type_str,
        category=category,
        description=description,
        vendor=vendor,
        total_amount=total_amount,
        currency=currency,
    )

    payload = {
        "id": expense.id,
        "date": expense.date.isoformat(),
        "description": expense.description,
        "type": expense.type,
        "type_display": expense.get_type_display(),
        "category_name": expense.category.name if expense.category else None,
        "vendor": expense.vendor or "",
        "total_amount": str(expense.total_amount),
        "currency": expense.currency,
        "receipt_count": expense.receipts.count(),
    }

    return Response(payload, status=201)


@csrf_exempt
@api_view(["PATCH"])
@authentication_classes([CsrfExemptSessionAuthentication])
@permission_classes([IsAuthenticated])
def expense_update_api(request, pk):
    """
    Partially update an expense (inline edit from React).
    """
    if not request.user.is_authenticated:
        return Response({"detail": "Authentication credentials were not provided."}, status=401)

    try:
        expense = ExpenseRecord.objects.get(pk=pk)
    except ExpenseRecord.DoesNotExist:
        return Response({"detail": "Expense not found."}, status=404)

    data = request.data

    if "date" in data and data.get("date"):
        try:
            expense.date = datetime.strptime(data["date"], "%Y-%m-%d").date()
        except ValueError:
            return Response({"detail": "Invalid date format."}, status=400)

    if "type" in data and data.get("type"):
        expense.type = data["type"]

    if "description" in data:
        expense.description = (data.get("description") or "").strip()

    if "vendor" in data:
        expense.vendor = (data.get("vendor") or "").strip()

    if "total_amount" in data and data.get("total_amount"):
        try:
            expense.total_amount = Decimal(str(data["total_amount"]))
        except Exception:
            return Response({"detail": "Invalid total amount."}, status=400)

    if "currency" in data and data.get("currency"):
        expense.currency = (data.get("currency") or "").strip()

    if "category_id" in data:
        cat_id = data.get("category_id")
        if cat_id:
            try:
                category = ExpenseCategory.objects.get(id=cat_id)
            except ExpenseCategory.DoesNotExist:
                return Response({"detail": "Invalid category."}, status=400)
            expense.category = category
        else:
            expense.category = None

    expense.save()

    payload = {
        "id": expense.id,
        "date": expense.date.isoformat(),
        "description": expense.description,
        "type": expense.type,
        "type_display": expense.get_type_display(),
        "category_name": expense.category.name if expense.category else None,
        "vendor": expense.vendor or "",
        "total_amount": str(expense.total_amount),
        "currency": expense.currency,
        "receipt_count": expense.receipts.count(),
    }

    return Response(payload)

@csrf_exempt
@api_view(["POST"])
@authentication_classes([CsrfExemptSessionAuthentication])
@permission_classes([IsAuthenticated])
def expense_upload_receipt_api(request, pk):
    """
    Upload a receipt image for an expense (single file per request).
    """
    if not request.user.is_authenticated:
        return Response({"detail": "Authentication credentials were not provided."}, status=401)

    try:
        expense = ExpenseRecord.objects.get(pk=pk)
    except ExpenseRecord.DoesNotExist:
        return Response({"detail": "Expense not found."}, status=404)

    file_obj = request.FILES.get("image") or request.FILES.get("file")
    if not file_obj:
        return Response({"detail": "No file uploaded (expected field 'image')."}, status=400)

    receipt = ExpenseReceipt.objects.create(expense=expense, image=file_obj)

    payload = {
        "id": receipt.id,
        "uploaded_at": receipt.uploaded_at.isoformat(),
        "image_url": receipt.image.url if receipt.image and hasattr(receipt.image, "url") else "",
    }
    return Response(payload, status=201)

@staff_member_required
def expense_export_csv(request):
    """
    Export expenses for a date range as CSV.
    """
    today = timezone.now().date()

    def parse_date_param(name: str):
        value = request.GET.get(name)
        if not value:
            return None
        try:
            return datetime.strptime(value, "%Y-%m-%d").date()
        except ValueError:
            return None

    start_date = parse_date_param("start_date")
    end_date = parse_date_param("end_date")

    if end_date is None:
        end_date = today
    if start_date is None:
        start_date = today.replace(day=1)

    qs = ExpenseRecord.objects.filter(date__gte=start_date, date__lte=end_date).select_related("category")

    filename = f"expenses_{start_date.isoformat()}_to_{end_date.isoformat()}.csv"
    response = HttpResponse(content_type="text/csv")
    response["Content-Disposition"] = f'attachment; filename="{filename}"'

    writer = csv.writer(response)
    writer.writerow(["Date", "Type", "Category", "Vendor", "Description", "Total", "Currency"])

    for e in qs.order_by("date", "id"):
        writer.writerow([
            e.date.isoformat(),
            e.get_type_display(),
            e.category.name if e.category else "",
            e.vendor or "",
            e.description or "",
            str(e.total_amount),
            e.currency,
        ])

    return response