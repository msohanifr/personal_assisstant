from django.contrib import admin
from . import models


@admin.register(models.ExpenseCategory)
class ExpenseCategoryAdmin(admin.ModelAdmin):
    list_display = ("name", "code")
    search_fields = ("name", "code")


class ExpenseReceiptInline(admin.TabularInline):
    model = models.ExpenseReceipt
    extra = 1


@admin.register(models.ExpenseRecord)
class ExpenseRecordAdmin(admin.ModelAdmin):
    list_display = (
        "date",
        "description",
        "category",
        "type",
        "vendor",
        "total_amount",
        "currency",
        "payment_method",
    )
    list_filter = ("type", "category", "currency", "payment_method")
    search_fields = ("description", "vendor", "notes")
    date_hierarchy = "date"
    inlines = [ExpenseReceiptInline]
