from django.urls import path
from . import views

urlpatterns = [
    path("", views.expense_dashboard, name="expense_dashboard"),
]
