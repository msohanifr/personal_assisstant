# api/urls.py
from rest_framework.routers import DefaultRouter
from django.urls import path, include

from integrations.api_views import StoreIntegrationViewSet
from core import views as core_views
from sales.views import SalesRecordViewSet
from banking.views import AccountViewSet, BankTransactionViewSet
from repairs.views import RepairTicketViewSet

router = DefaultRouter()
# ... your other viewsets ...
router.register(r"banking/accounts", AccountViewSet, basename="bank-account")
router.register(
    r"banking/transactions", BankTransactionViewSet, basename="bank-transaction"
)
router.register(
    r"integrations/stores", StoreIntegrationViewSet, basename="store-integration"
)
router.register(
    r"sales/records", SalesRecordViewSet, basename="sales-record"
)
router.register(
        r"repairs/tickets", RepairTicketViewSet, basename="repair-ticket"
    ),

urlpatterns = [
    # New label APIs
    path(
        "labels/meta/",
        core_views.label_meta_api,
        name="label_meta_api",
    ),
    path(
        "labels/variants/",
        core_views.label_variants_api,
        name="label_variants_api",
    ),
    # Existing viewsets
    path("", include(router.urls)),
]