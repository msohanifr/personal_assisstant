# Create your views here.
from typing import Dict, Any

from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from django.db.models import Q

from catalog.models import Product, ProductVariant, Collection
from suppliers.models import Supplier


@api_view(["GET"])
@permission_classes([IsAuthenticated])
def label_variants_api(request):
    """
    API for the React label designer.

    Returns:
      - filtered variants with all data needed for labels
      - collections & suppliers for filters
      - basic pagination metadata
    """
    q = (request.query_params.get("q") or "").strip()
    collection_id = (request.query_params.get("collection") or "").strip()
    supplier_id = (request.query_params.get("supplier") or "").strip()
    only_in_stock = (request.query_params.get("only_in_stock") or "").strip() == "1"

    try:
        limit = int(request.query_params.get("limit") or "200")
    except ValueError:
        limit = 200
    try:
        offset = int(request.query_params.get("offset") or "0")
    except ValueError:
        offset = 0

    limit = max(1, min(limit, 500))
    offset = max(0, offset)

    variants_qs = ProductVariant.objects.select_related(
        "product",
        "product__collection",
        "product__default_supplier",
    )

    if q:
        variants_qs = variants_qs.filter(
            Q(sku__icontains=q)
            | Q(product__name__icontains=q)
            | Q(product__collection__name__icontains=q)
        )

    if collection_id:
        variants_qs = variants_qs.filter(product__collection_id=collection_id)

    if supplier_id:
        variants_qs = variants_qs.filter(product__default_supplier_id=supplier_id)

    if only_in_stock:
        variants_qs = variants_qs.filter(stock_quantity__gt=0)

    variants_qs = variants_qs.order_by(
        "product__collection__name",
        "product__name",
        "sku",
    )

    total = variants_qs.count()
    variants_page = variants_qs[offset : offset + limit]

    metal_display_map: Dict[Any, str] = dict(getattr(Product, "METAL_CHOICES", []))

    def serialize_variant(v: ProductVariant) -> dict:
        p = v.product
        metal_code = getattr(p, "metal", None)
        metal_display = (
            metal_display_map.get(metal_code, metal_code) if metal_code else None
        )
        collection_name = p.collection.name if p.collection else None

        price_raw = v.price if hasattr(v, "price") and v.price is not None else p.base_price
        price_str = str(price_raw) if price_raw is not None else None

        return {
            "id": v.id,
            "sku": v.sku,
            "product_name": p.name,
            "collection_name": collection_name,
            "metal": metal_display,
            "gold_purity": getattr(p, "gold_purity", None),
            "size": v.size or None,
            "color": v.color or None,
            "chain_length_cm": (
                str(v.chain_length_cm) if v.chain_length_cm is not None else None
            ),
            "barcode": v.barcode or "",
            "barcode_image_url": v.barcode_image.url if v.barcode_image else None,
            "price_raw": price_str,
            "currency": p.currency or "USD",
            "stock_quantity": v.stock_quantity,
        }

    variants_data = [serialize_variant(v) for v in variants_page]

    collections = [
        {"id": c.id, "name": c.name}
        for c in Collection.objects.all().order_by("name")
    ]
    suppliers = [
        {"id": s.id, "name": s.name}
        for s in Supplier.objects.all().order_by("name")
    ]

    return Response(
        {
            "results": variants_data,
            "filters": {
                "q": q,
                "collection": collection_id,
                "supplier": supplier_id,
                "only_in_stock": only_in_stock,
            },
            "collections": collections,
            "suppliers": suppliers,
            "pagination": {
                "limit": limit,
                "offset": offset,
                "total": total,
            },
        }
    )