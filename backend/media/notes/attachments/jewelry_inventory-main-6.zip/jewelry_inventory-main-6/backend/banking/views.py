from django.shortcuts import render

# Create your views here.
from datetime import timedelta
from decimal import Decimal
import difflib

from django.db.models import Q
from rest_framework import permissions, viewsets
from rest_framework.decorators import action
from rest_framework.response import Response

from .models import Account, BankTransaction
from .serializers import AccountSerializer, BankTransactionSerializer
from sales.models import Order
from expenses.models import ExpenseRecord

# banking/views.py (inside BankTransactionViewSet)

from rest_framework.decorators import action
from rest_framework import status

@action(detail=False, methods=["post"])
def bulk_import(self, request):
    """
    Create many BankTransaction objects in one go.
    Expected payload:
      {
        "account": <account_id>,
        "rows": [
          {
            "transaction_date": "2025-01-01",
            "description": "Stripe payout",
            "amount": 123.45,
            "currency": "USD",
            "external_id": "abc123",
            "raw_data": {...}
          },
          ...
        ]
      }
    """
    account_id = request.data.get("account")
    rows = request.data.get("rows", [])

    if not account_id or not rows:
        return Response(
          {"detail": "account and rows are required."},
          status=status.HTTP_400_BAD_REQUEST,
        )

    account = Account.objects.get(pk=account_id)
    created = 0

    for row in rows:
        # you can also add dedupe by external_id here
        BankTransaction.objects.create(
            account=account,
            transaction_date=row.get("transaction_date"),
            description=row.get("description", ""),
            amount=row.get("amount", 0),
            currency=row.get("currency", account.currency),
            external_id=row.get("external_id") or "",
            raw_data=row.get("raw_data"),
        )
        created += 1

    return Response({"created": created})


class AccountViewSet(viewsets.ModelViewSet):
    queryset = Account.objects.all().order_by("account_type", "name")
    serializer_class = AccountSerializer
    permission_classes = [permissions.IsAuthenticated]


class BankTransactionViewSet(viewsets.ModelViewSet):
    queryset = (
        BankTransaction.objects.select_related("account", "matched_order", "matched_expense")
        .all()
        .order_by("-transaction_date", "-id")
    )
    serializer_class = BankTransactionSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        qs = super().get_queryset()
        request = self.request

        account_id = request.query_params.get("account")
        if account_id:
            qs = qs.filter(account_id=account_id)

        search = request.query_params.get("search")
        if search:
            qs = qs.filter(
                Q(description__icontains=search)
                | Q(notes__icontains=search)
                | Q(external_id__icontains=search)
            )

        return qs

    @action(detail=True, methods=["get"])
    def suggest_matches(self, request, pk=None):
        """
        Fuzzy-suggest matching Orders and ExpenseRecords for this transaction.

        Heuristics:
        - Close amount (within tolerance)
        - Close date (± N days)
        - Some basic text similarity on description vs notes/description fields
        """

        txn = self.get_object()
        amount_abs = abs(txn.amount)
        tx_date = txn.transaction_date

        amount_tolerance = Decimal("1.00")  # $1 diff allowed
        date_window_days = 7

        min_date = tx_date - timedelta(days=date_window_days)
        max_date = tx_date + timedelta(days=date_window_days)

        # --- Candidate orders (sales) ---
        order_qs = Order.objects.filter(
            order_date__date__gte=min_date,
            order_date__date__lte=max_date,
            total_amount__gte=amount_abs - amount_tolerance,
            total_amount__lte=amount_abs + amount_tolerance,
        )

        candidates = []

        desc = (txn.description or "").lower()

        for order in order_qs[:50]:
            amount_diff = abs(order.total_amount - amount_abs)
            date_diff_days = abs((order.order_date.date() - tx_date).days)

            text_blob = f"{order.order_number} {order.channel} {order.notes}".lower()
            text_similarity = difflib.SequenceMatcher(None, desc, text_blob).ratio()

            score = 0.0
            # amount closeness (max weight)
            score += max(0.0, 1.0 - float(amount_diff / (amount_tolerance + Decimal("0.01")))) * 0.5
            # date closeness
            score += max(0.0, 1.0 - date_diff_days / (date_window_days + 1)) * 0.3
            # text similarity
            score += float(text_similarity) * 0.2

            candidates.append(
                {
                    "type": "order",
                    "id": order.id,
                    "order_number": order.order_number,
                    "amount": str(order.total_amount),
                    "order_date": order.order_date,
                    "score": round(score * 100, 1),  # as percentage
                }
            )

        # --- Candidate expenses ---
        expense_qs = ExpenseRecord.objects.filter(
            date__gte=min_date,
            date__lte=max_date,
            amount__gte=amount_abs - amount_tolerance,
            amount__lte=amount_abs + amount_tolerance,
        )

        for exp in expense_qs[:50]:
            amount_diff = abs(exp.amount - amount_abs)
            date_diff_days = abs((exp.date - tx_date).days)

            text_blob = f"{exp.description} {exp.category.name if exp.category_id else ''}".lower()
            text_similarity = difflib.SequenceMatcher(None, desc, text_blob).ratio()

            score = 0.0
            score += max(0.0, 1.0 - float(amount_diff / (amount_tolerance + Decimal("0.01")))) * 0.5
            score += max(0.0, 1.0 - date_diff_days / (date_window_days + 1)) * 0.3
            score += float(text_similarity) * 0.2

            candidates.append(
                {
                    "type": "expense",
                    "id": exp.id,
                    "description": exp.description,
                    "amount": str(exp.amount),
                    "date": exp.date,
                    "score": round(score * 100, 1),
                }
            )

        # sort by score descending and return top N
        candidates.sort(key=lambda c: c["score"], reverse=True)
        top = candidates[:10]

        return Response(
            {
                "transaction_id": txn.id,
                "transaction_description": txn.description,
                "transaction_amount": str(txn.amount),
                "transaction_date": txn.transaction_date,
                "candidates": top,
            }
        )