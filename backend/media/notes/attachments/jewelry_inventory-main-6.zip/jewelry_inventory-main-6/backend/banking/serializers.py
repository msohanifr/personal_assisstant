from rest_framework import serializers

from .models import Account, BankTransaction


class AccountSerializer(serializers.ModelSerializer):
    class Meta:
        model = Account
        fields = [
            "id",
            "name",
            "institution_name",
            "account_type",
            "currency",
            "last4",
            "is_active",
            "notes",
            "created_at",
            "updated_at",
        ]


class BankTransactionSerializer(serializers.ModelSerializer):
    account_name = serializers.CharField(source="account.name", read_only=True)

    class Meta:
        model = BankTransaction
        fields = [
            "id",
            "account",
            "account_name",
            "transaction_date",
            "posted_date",
            "description",
            "amount",
            "currency",
            "external_id",
            "raw_data",
            "matched_order",
            "matched_expense",
            "match_confidence",
            "notes",
            "created_at",
            "updated_at",
        ]
        read_only_fields = ["match_confidence"]