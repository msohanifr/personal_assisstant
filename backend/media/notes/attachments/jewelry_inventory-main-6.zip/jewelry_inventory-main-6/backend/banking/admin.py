from django.contrib import admin

# Register your models here.
from django.contrib import admin

from .models import Account, BankTransaction


@admin.register(Account)
class AccountAdmin(admin.ModelAdmin):
    list_display = (
        "name",
        "institution_name",
        "account_type",
        "currency",
        "last4",
        "is_active",
    )
    list_filter = ("account_type", "currency", "is_active")
    search_fields = ("name", "institution_name", "last4")


@admin.register(BankTransaction)
class BankTransactionAdmin(admin.ModelAdmin):
    list_display = (
        "transaction_date",
        "description",
        "amount",
        "account",
        "matched_order",
        "matched_expense",
        "match_confidence",
    )
    list_filter = ("account", "currency", "transaction_date")
    search_fields = (
        "description",
        "external_id",
        "notes",
        "matched_order__order_number",
        "matched_expense__description",
    )
    autocomplete_fields = ("account", "matched_order", "matched_expense")