from django.db import models

# Create your models here.
from decimal import Decimal
from datetime import date

from django.db import models

from core.models import TimeStampedModel
from expenses.models import ExpenseRecord
from sales.models import Order


class Account(TimeStampedModel):
    """
    A financial account (bank account, card, PayPal, etc.).
    Can be personal or business. You can attach multiple accounts.
    """

    ACCOUNT_TYPE_CHOICES = [
        ("business", "Business"),
        ("personal", "Personal"),
        ("card", "Credit / Debit card"),
        ("wallet", "Wallet (PayPal, Stripe, etc.)"),
        ("other", "Other"),
    ]

    name = models.CharField(
        max_length=100,
        help_text="Friendly name, e.g. 'Chase Business Checking', 'Amex Personal'.",
    )
    institution_name = models.CharField(
        max_length=100,
        blank=True,
        help_text="Bank / card issuer, e.g. 'Chase', 'Amex'.",
    )
    account_type = models.CharField(
        max_length=20,
        choices=ACCOUNT_TYPE_CHOICES,
        default="business",
    )
    currency = models.CharField(max_length=3, default="USD")
    last4 = models.CharField(
        max_length=4,
        blank=True,
        help_text="Last 4 digits to identify card or account (optional).",
    )

    is_active = models.BooleanField(default=True)

    notes = models.TextField(blank=True)

    class Meta:
        ordering = ["account_type", "name"]

    def __str__(self) -> str:
        base = self.name or self.institution_name or "Account"
        if self.last4:
            return f"{base} ••••{self.last4}"
        return base


class BankTransaction(TimeStampedModel):
    """
    A transaction imported from a bank/card/wallet statement.

    amount:
      - Positive = money IN (income, refund)
      - Negative = money OUT (expense, payment)
    """

    account = models.ForeignKey(
        Account,
        related_name="transactions",
        on_delete=models.CASCADE,
    )

    transaction_date = models.DateField(
        help_text="The date shown on the statement."
    )
    posted_date = models.DateField(
        null=True,
        blank=True,
        help_text="The date the bank actually posted the transaction.",
    )

    description = models.CharField(max_length=255)

    amount = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        help_text="Positive for incoming money, negative for outgoing.",
    )
    currency = models.CharField(max_length=3, default="USD")

    # For deduping / re-imports
    external_id = models.CharField(
        max_length=128,
        blank=True,
        help_text="Unique ID from bank feed / CSV if available.",
    )

    raw_data = models.JSONField(
        null=True,
        blank=True,
        help_text="Original raw data (JSON from API or parsed CSV row).",
    )

    # Optional links to your internal records
    matched_order = models.ForeignKey(
        Order,
        related_name="bank_transactions",
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
    )
    matched_expense = models.ForeignKey(
        ExpenseRecord,
        related_name="bank_transactions",
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
    )

    match_confidence = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        default=Decimal("0.00"),
        help_text="0–100, how confident the system is about the match.",
    )

    notes = models.TextField(blank=True)

    class Meta:
        ordering = ["-transaction_date", "-id"]
        indexes = [
            models.Index(fields=["transaction_date"]),
            models.Index(fields=["amount"]),
            models.Index(fields=["external_id"]),
        ]

    def __str__(self) -> str:
        sign = "+" if self.amount >= 0 else "-"
        return f"{self.transaction_date} {sign}{abs(self.amount)} {self.description[:40]}"