# Register your models here.
# integrations/admin.py
from django.contrib import admin
from .models import StoreIntegration
from .models import WooFieldMapping


@admin.register(StoreIntegration)
class StoreIntegrationAdmin(admin.ModelAdmin):
    list_display = ("name", "platform", "base_url", "is_active", "last_synced_at")
    list_filter = ("platform", "is_active")


@admin.register(WooFieldMapping)
class WooFieldMappingAdmin(admin.ModelAdmin):
    list_display = (
        "woo_path",
        "local_model",
        "local_field",
        "is_active",
        "sort_order",
    )
    list_filter = ("local_model", "is_active")
    search_fields = (
        "woo_path",
        "woo_description",
        "local_field",
        "local_description",
    )
    ordering = ("sort_order", "local_model", "woo_path")
    list_editable = ("is_active", "sort_order")

    fieldsets = (
        (None, {
            "fields": (
                "name",
                "woo_path",
                "woo_description",
            )
        }),
        ("Local mapping", {
            "fields": (
                "local_model",
                "local_field",
                "local_description",
            )
        }),
        ("Extra", {
            "fields": (
                "example_value",
                "is_active",
                "sort_order",
            )
        }),
    )