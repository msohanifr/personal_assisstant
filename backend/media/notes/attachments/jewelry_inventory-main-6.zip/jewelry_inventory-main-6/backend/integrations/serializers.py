from rest_framework import serializers
from .models import StoreIntegration


class StoreIntegrationSerializer(serializers.ModelSerializer):
    class Meta:
        model = StoreIntegration
        fields = [
            "id",
            "platform",
            "name",
            "base_url",
            "is_active",
            "last_synced_at",
        ]
        read_only_fields = ["last_synced_at"]
