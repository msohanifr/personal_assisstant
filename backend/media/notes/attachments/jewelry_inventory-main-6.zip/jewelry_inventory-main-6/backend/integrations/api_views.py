from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.permissions import IsAdminUser
from rest_framework.response import Response

from .models import StoreIntegration
from .serializers import StoreIntegrationSerializer
from .services import (
    sync_woocommerce_orders,
    sync_shopify_orders,
    sync_woocommerce_products,   # 👈 add this
)


class StoreIntegrationViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = StoreIntegration.objects.all()
    serializer_class = StoreIntegrationSerializer
    permission_classes = [IsAdminUser]

    @action(detail=True, methods=["post"], url_path="sync")
    def sync(self, request, pk=None):
        integ = self.get_object()

        if integ.platform == StoreIntegration.WOO:
            count = sync_woocommerce_orders(integ, since=integ.last_synced_at)
        elif integ.platform == StoreIntegration.SHOPIFY:
            count = sync_shopify_orders(integ, since=integ.last_synced_at)
        else:
            return Response(
                {"detail": "Unsupported platform."}, status=status.HTTP_400_BAD_REQUEST
            )

        return Response({"detail": "Sync complete.", "orders_synced": count})

    @action(detail=True, methods=["post"], url_path="sync-products")
    def sync_products(self, request, pk=None):
        """
        Trigger WooCommerce → local product sync from the frontend.
        """
        integ = self.get_object()

        if integ.platform != StoreIntegration.WOO:
            return Response(
                {"detail": "Product sync is currently only implemented for WooCommerce."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        # Optional: accept a "direction" param from the frontend, but for now only 'pull'
        direction = request.data.get("direction", "pull")
        if direction != "pull":
            return Response(
                {"detail": "Only 'pull' (Woo → local) is implemented right now."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        result = sync_woocommerce_products(integ)

        return Response(
            {
                "detail": "Product sync complete.",
                "products_created": result["created"],
                "products_updated": result["updated"],
            },
            status=status.HTTP_200_OK,
        )
    
    @action(detail=True, methods=["post"], url_path="set-active")
    def set_active(self, request, pk=None):
        """
        Mark this integration as active and deactivate the others.
        """
        integ = self.get_object()

        # Deactivate all others for the same platform (or for all, if you prefer)
        StoreIntegration.objects.exclude(id=integ.id).update(is_active=False)
        integ.is_active = True
        integ.save(update_fields=["is_active"])

        serializer = self.get_serializer(integ)
        return Response(serializer.data, status=status.HTTP_200_OK)