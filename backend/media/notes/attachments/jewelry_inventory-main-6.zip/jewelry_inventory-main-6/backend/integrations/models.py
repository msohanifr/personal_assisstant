from django.db import models

# Create your models here.


class StoreIntegration(models.Model):
    WOO = "woocommerce"
    SHOPIFY = "shopify"

    PLATFORM_CHOICES = [
        (WOO, "WooCommerce"),
        (SHOPIFY, "Shopify"),
    ]

    platform = models.CharField(max_length=20, choices=PLATFORM_CHOICES)
    name = models.CharField(max_length=100, default="Default store")

    # For Woo: https://yourstore.com
    # For Shopify: https://yourstore.myshopify.com
    base_url = models.URLField()

    # WooCommerce
    api_key = models.CharField(max_length=255, blank=True)
    api_secret = models.CharField(max_length=255, blank=True)

    # Shopify
    access_token = models.CharField(max_length=255, blank=True)

    is_active = models.BooleanField(default=True)
    last_synced_at = models.DateTimeField(null=True, blank=True)

    def __str__(self):
        return f"{self.get_platform_display()} – {self.name}"


# integrations/models.py
from django.db import models

# existing imports...
# from .models import StoreIntegration, etc.


class WooFieldMapping(models.Model):
    """
    Describes how a WooCommerce field (or JSON path) is mapped
    into our local Product / ProductVariant fields.
    """

    MODEL_CHOICES = [
        ("product", "Product"),
        ("variant", "Product variant"),
    ]

    name = models.CharField(
        max_length=200,
        help_text="Short name of this mapping (for humans).",
    )

    woo_path = models.CharField(
        max_length=255,
        help_text=(
            "WooCommerce JSON path, e.g. 'id', 'sku', "
            "'images[0].src', 'meta_data[rank_math_title]', "
            "'categories[].name'"
        ),
    )

    woo_description = models.TextField(
        blank=True,
        help_text="What this Woo field means (e.g. 'Woo product ID').",
    )

    local_model = models.CharField(
        max_length=20,
        choices=MODEL_CHOICES,
        help_text="Which local model this maps to.",
    )

    local_field = models.CharField(
        max_length=100,
        help_text="Local model field name, e.g. 'woo_id', 'name', 'primary_image_url'.",
    )

    local_description = models.TextField(
        blank=True,
        help_text="What this local field represents in our system.",
    )

    example_value = models.TextField(
        blank=True,
        help_text="Optional example value from Woo (for documentation).",
    )

    is_active = models.BooleanField(
        default=True,
        help_text="Whether this mapping is currently in use.",
    )

    sort_order = models.PositiveIntegerField(
        default=0,
        help_text="For ordering mappings in the admin UI.",
    )

    class Meta:
        ordering = ["sort_order", "local_model", "woo_path"]
        verbose_name = "Woo field mapping"
        verbose_name_plural = "Woo field mappings"

    def __str__(self) -> str:
        return f"{self.woo_path} → {self.local_model}.{self.local_field}"