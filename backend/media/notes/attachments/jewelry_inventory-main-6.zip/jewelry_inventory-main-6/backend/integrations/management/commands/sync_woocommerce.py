from django.core.management.base import BaseCommand
from integrations.models import StoreIntegration
from integrations.services import sync_woocommerce_orders


class Command(BaseCommand):
    help = "Sync WooCommerce orders into local Order model"

    def handle(self, *args, **options):
        qs = StoreIntegration.objects.filter(
            platform=StoreIntegration.WOO, is_active=True
        )
        if not qs.exists():
            self.stdout.write(
                self.style.WARNING("No active WooCommerce integrations found.")
            )
            return

        for integ in qs:
            self.stdout.write(f"Syncing WooCommerce store: {integ.name}")
            count = sync_woocommerce_orders(integ, since=integ.last_synced_at)
            self.stdout.write(self.style.SUCCESS(f"  Synced {count} orders."))
