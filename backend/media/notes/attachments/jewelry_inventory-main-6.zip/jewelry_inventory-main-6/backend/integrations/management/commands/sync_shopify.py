from django.core.management.base import BaseCommand
from integrations.models import StoreIntegration
from integrations.services import sync_shopify_orders


class Command(BaseCommand):
    help = "Sync Shopify orders into local Order model"

    def handle(self, *args, **options):
        qs = StoreIntegration.objects.filter(
            platform=StoreIntegration.SHOPIFY, is_active=True
        )
        if not qs.exists():
            self.stdout.write(
                self.style.WARNING("No active Shopify integrations found.")
            )
            return

        for integ in qs:
            self.stdout.write(f"Syncing Shopify store: {integ.name}")
            count = sync_shopify_orders(integ, since=integ.last_synced_at)
            self.stdout.write(self.style.SUCCESS(f"  Synced {count} orders."))
