from decimal import Decimal

import requests
from django.utils import timezone
from django.utils.text import slugify 

from sales.models import (
    Order,
    OrderLine,
    ProductVariant,
)  # adjust ProductVariant import if needed
from .models import StoreIntegration
from catalog.models import Product


def sync_woocommerce_orders(integration: StoreIntegration, since=None) -> int:
    """
    Fetch WooCommerce orders and upsert them into Order / OrderLine.
    """
    assert integration.platform == StoreIntegration.WOO

    base_url = integration.base_url.rstrip("/")
    url = f"{base_url}/wp-json/wc/v3/orders"

    params = {
        "per_page": 100,
        "status": "completed",
    }
    if since:
        params["after"] = since.isoformat()

    auth = (integration.api_key, integration.api_secret)

    resp = requests.get(url, params=params, auth=auth, timeout=30)
    resp.raise_for_status()
    orders = resp.json()

    count = 0
    for data in orders:
        _upsert_woo_order(integration, data)
        count += 1

    integration.last_synced_at = timezone.now()
    integration.save(update_fields=["last_synced_at"])
    return count

def sync_woocommerce_products(integration: StoreIntegration) -> dict:
    """
    Pull products from WooCommerce and upsert into local Product / ProductVariant.

    - Upserts Product by woo_id.
    - Syncs both simple products and variable products (variations).
    - Stores full Woo payload in woo_data on both Product and Variant.
    - Stores primary image URL(s).

    Returns a simple summary:
        {"created": int, "updated": int}
    """
    assert integration.platform == StoreIntegration.WOO

    base_url = integration.base_url.rstrip("/")
    products_url = f"{base_url}/wp-json/wc/v3/products"
    variations_url_tpl = f"{base_url}/wp-json/wc/v3/products/{{product_id}}/variations"

    per_page = 50
    page = 1

    created_count = 0
    updated_count = 0

    # Use same auth style as your order sync
    auth = (integration.api_key, integration.api_secret)

    while True:
        resp = requests.get(
            products_url,
            params={"page": page, "per_page": per_page, "status": "publish"},
            auth=auth,
            timeout=30,
        )
        resp.raise_for_status()
        products = resp.json()
        if not products:
            break

        for p in products:
            woo_id = p.get("id")
            if not woo_id:
                continue

            name = p.get("name") or f"Product {woo_id}"
            description = p.get("description") or ""
            slug_source = p.get("slug") or name
            base_slug = slugify(slug_source) or f"woo-{woo_id}"

            # Primary image URL
            images = p.get("images") or []
            primary_image_url = images[0].get("src") if images else ""

            # --- Upsert Product by woo_id ---
            product_obj = Product.objects.filter(woo_id=woo_id).first()

            if product_obj is None:
                # unique slug
                slug_val = base_slug[:50]
                counter = 2
                while Product.objects.filter(slug=slug_val).exists():
                    slug_val = f"{base_slug[:45]}-{counter}"
                    counter += 1

                # unique sku_base
                base_sku_base = (p.get("sku") or f"WOO-{woo_id}")[:40]
                sku_base = base_sku_base
                counter = 2
                while Product.objects.filter(sku_base=sku_base).exists():
                    sku_base = f"{base_sku_base[:35]}-{counter}"
                    counter += 1

                product_obj = Product.objects.create(
                    name=name,
                    slug=slug_val,
                    sku_base=sku_base,
                    description=description,
                    woo_id=woo_id,
                    woo_permalink=p.get("permalink") or "",
                    woo_status=p.get("status") or "",
                    woo_type=p.get("type") or "",
                    woo_data=p,
                    primary_image_url=primary_image_url or "",
                )
                created_count += 1
            else:
                changed = False
                fields_to_update = []

                if product_obj.name != name:
                    product_obj.name = name
                    changed = True
                    fields_to_update.append("name")

                if product_obj.description != description:
                    product_obj.description = description
                    changed = True
                    fields_to_update.append("description")

                status_val = p.get("status") or ""
                if product_obj.woo_status != status_val:
                    product_obj.woo_status = status_val
                    changed = True
                    fields_to_update.append("woo_status")

                type_val = p.get("type") or ""
                if product_obj.woo_type != type_val:
                    product_obj.woo_type = type_val
                    changed = True
                    fields_to_update.append("woo_type")

                permalink_val = p.get("permalink") or ""
                if product_obj.woo_permalink != permalink_val:
                    product_obj.woo_permalink = permalink_val
                    changed = True
                    fields_to_update.append("woo_permalink")

                if product_obj.primary_image_url != (primary_image_url or ""):
                    product_obj.primary_image_url = primary_image_url or ""
                    changed = True
                    fields_to_update.append("primary_image_url")

                # Always refresh raw Woo JSON
                product_obj.woo_data = p
                if "woo_data" not in fields_to_update:
                    fields_to_update.append("woo_data")
                    changed = True

                if changed:
                    product_obj.save(update_fields=fields_to_update)
                    updated_count += 1

            # --- Variants / Variations ---

            product_type = p.get("type")
            if product_type in ("variable",):
                # fetch variations
                variations_url = variations_url_tpl.format(product_id=woo_id)
                v_page = 1
                while True:
                    v_resp = requests.get(
                        variations_url,
                        params={"page": v_page, "per_page": 50},
                        auth=auth,
                        timeout=30,
                    )
                    v_resp.raise_for_status()
                    variations = v_resp.json()
                    if not variations:
                        break

                    for v in variations:
                        _created, _updated = _sync_single_variant_from_woo(
                            product_obj=product_obj,
                            woo_product=p,
                            woo_variation=v,
                        )
                        created_count += _created
                        updated_count += _updated

                    v_page += 1
            else:
                # treat simple product as a single variant
                _created, _updated = _sync_single_variant_from_woo(
                    product_obj=product_obj,
                    woo_product=p,
                    woo_variation=None,  # simple
                )
                created_count += _created
                updated_count += _updated

        page += 1

    integration.last_synced_at = timezone.now()
    integration.save(update_fields=["last_synced_at"])

    return {"created": created_count, "updated": updated_count}

def _sync_single_variant_from_woo(
    product_obj: Product,
    woo_product: dict,
    woo_variation: dict | None,
) -> tuple[int, int]:
    """
    Create/update a ProductVariant from Woo data.

    - For simple products: woo_variation is None, we use woo_product values.
    - For variable products: woo_variation is the variation payload.
    """
    created = 0
    updated = 0

    # decide which payload to use
    payload = woo_variation or woo_product
    woo_id = payload.get("id")
    parent_id = woo_product.get("id")

    if not woo_id:
        return created, updated

    sku = (payload.get("sku") or "").strip()

    # price
    try:
        regular_price = Decimal(payload.get("regular_price") or payload.get("price") or "0.00")
    except Exception:
        regular_price = Decimal("0.00")

    # attributes → size / color / length (best-effort mapping)
    size = ""
    color = ""
    chain_length_cm = None

    for attr in payload.get("attributes") or []:
        name = (attr.get("name") or "").lower()
        option = (attr.get("option") or "").strip()

        if "size" in name:
            size = option
        elif "color" in name or "colour" in name:
            color = option
        elif "length" in name:
            # try to parse e.g. "45 cm" → 45
            opt = option.replace("cm", "").strip()
            try:
                chain_length_cm = Decimal(opt)
            except Exception:
                pass

    # image URL for variant, fall back to product primary image
    images = payload.get("image") or payload.get("images") or []
    if isinstance(images, dict):
        variant_image_url = images.get("src") or ""
    else:
        variant_image_url = images[0].get("src") if images else ""

    if not variant_image_url:
        variant_image_url = product_obj.primary_image_url or ""

    variant_qs = ProductVariant.objects.filter(woo_id=woo_id)
    variant = variant_qs.first()

    if variant is None:
        # create new variant
        variant = ProductVariant.objects.create(
            product=product_obj,
            woo_id=woo_id,
            woo_parent_id=parent_id,
            woo_data=payload,
            sku=sku,  # if blank, model save() will auto-generate
            size=size,
            color=color,
            chain_length_cm=chain_length_cm,
            image_url=variant_image_url,
            cost=None,  # you can map this if Woo carries cost somewhere
            price=regular_price,
        )
        created += 1
    else:
        changed = False
        fields_to_update = []

        if sku and variant.sku != sku:
            variant.sku = sku
            changed = True
            fields_to_update.append("sku")

        if size and variant.size != size:
            variant.size = size
            changed = True
            fields_to_update.append("size")

        if color and variant.color != color:
            variant.color = color
            changed = True
            fields_to_update.append("color")

        if chain_length_cm is not None and variant.chain_length_cm != chain_length_cm:
            variant.chain_length_cm = chain_length_cm
            changed = True
            fields_to_update.append("chain_length_cm")

        if hasattr(variant, "price") and variant.price != regular_price:
            variant.price = regular_price
            changed = True
            fields_to_update.append("price")

        if variant.image_url != (variant_image_url or ""):
            variant.image_url = variant_image_url or ""
            changed = True
            fields_to_update.append("image_url")

        if variant.woo_parent_id != parent_id:
            variant.woo_parent_id = parent_id
            changed = True
            fields_to_update.append("woo_parent_id")

        # always update raw data
        variant.woo_data = payload
        if "woo_data" not in fields_to_update:
            fields_to_update.append("woo_data")
            changed = True

        if changed:
            variant.save(update_fields=fields_to_update)
            updated += 1

    return created, updated


def _upsert_woo_order(integration: StoreIntegration, data: dict) -> Order:
    ext_id = str(data["id"])
    currency = data.get("currency") or "USD"

    billing = data.get("billing") or {}

    order, created = Order.objects.get_or_create(
        external_source="woocommerce",
        external_id=ext_id,
        defaults={
            "order_number": data.get("number") or ext_id,
            "status": "paid" if data.get("status") == "completed" else "pending",
            "channel": "online",
            "currency": currency,
            "billing_country": billing.get("country") or "",
            "billing_state": billing.get("state") or "",
            "billing_postal_code": billing.get("postcode") or "",
        },
    )

    total = Decimal(data.get("total", "0.00"))
    total_tax = Decimal(data.get("total_tax", "0.00"))
    shipping_total = Decimal(data.get("shipping_total", "0.00"))
    shipping_tax = Decimal(data.get("shipping_tax", "0.00"))
    discount_total = Decimal(data.get("discount_total", "0.00"))

    subtotal = total - total_tax
    tax = total_tax + shipping_tax

    order.subtotal_amount = subtotal
    order.shipping_amount = shipping_total
    order.discount_amount = discount_total
    order.tax_amount = tax
    order.total_amount = total

    # If you prefer to enforce your TaxRule logic, uncomment:
    # calculate_order_tax(order)

    order.save()

    # Lines
    order.lines.all().delete()
    for item in data.get("line_items", []):
        sku = item.get("sku") or ""
        quantity = item.get("quantity") or 1
        line_subtotal = Decimal(item.get("subtotal", "0.00"))

        variant = ProductVariant.objects.filter(sku=sku).first()
        product = getattr(variant, "product", None)
        unit_price = (line_subtotal / quantity) if quantity else line_subtotal

        OrderLine.objects.create(
            order=order,
            variant=variant,
            product=product,
            quantity=quantity,
            unit_price=unit_price,
        )

    return order


def sync_shopify_orders(integration: StoreIntegration, since=None) -> int:
    """
    Fetch Shopify orders and upsert them into Order / OrderLine.
    """
    assert integration.platform == StoreIntegration.SHOPIFY

    base_url = integration.base_url.rstrip("/")
    url = f"{base_url}/admin/api/2024-01/orders.json"

    params = {
        "status": "any",
        "financial_status": "paid",
        "limit": 100,
    }
    if since:
        params["created_at_min"] = since.isoformat()

    headers = {
        "X-Shopify-Access-Token": integration.access_token,
        "Accept": "application/json",
    }

    resp = requests.get(url, params=params, headers=headers, timeout=30)
    resp.raise_for_status()
    payload = resp.json()
    orders = payload.get("orders", [])

    count = 0
    for o in orders:
        _upsert_shopify_order(integration, o)
        count += 1

    integration.last_synced_at = timezone.now()
    integration.save(update_fields=["last_synced_at"])
    return count


def _upsert_shopify_order(integration: StoreIntegration, data: dict) -> Order:
    ext_id = str(data["id"])
    currency = data.get("currency") or "USD"

    billing = data.get("billing_address") or {}

    order, created = Order.objects.get_or_create(
        external_source="shopify",
        external_id=ext_id,
        defaults={
            "order_number": data.get("name") or ext_id,
            "status": "paid" if data.get("financial_status") == "paid" else "pending",
            "channel": "online",
            "currency": currency,
            "billing_country": billing.get("country_code") or "",
            "billing_state": billing.get("province_code") or "",
            "billing_postal_code": billing.get("zip") or "",
        },
    )

    total = Decimal(data.get("total_price", "0.00"))
    total_tax = Decimal(data.get("total_tax", "0.00") or "0.00")
    shipping_lines = data.get("shipping_lines") or []
    shipping_total = sum(Decimal(s.get("price", "0.00")) for s in shipping_lines)
    discount_total = sum(
        Decimal(d.get("amount", "0.00"))
        for d in (data.get("discount_applications") or [])
    )

    subtotal = total - total_tax
    tax = total_tax

    order.subtotal_amount = subtotal
    order.shipping_amount = shipping_total
    order.discount_amount = discount_total
    order.tax_amount = tax
    order.total_amount = total

    # Or enforce your own tax rules:
    # calculate_order_tax(order)

    order.save()

    order.lines.all().delete()
    for item in data.get("line_items", []):
        sku = item.get("sku") or ""
        quantity = item.get("quantity") or 1
        unit_price = Decimal(item.get("price", "0.00"))
        line_subtotal = unit_price * quantity

        variant = ProductVariant.objects.filter(sku=sku).first()
        product = getattr(variant, "product", None)

        OrderLine.objects.create(
            order=order,
            variant=variant,
            product=product,
            quantity=quantity,
            unit_price=unit_price,
        )

    return order
