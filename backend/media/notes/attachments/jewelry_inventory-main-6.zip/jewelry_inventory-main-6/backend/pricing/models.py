from django.db import models


class MetalPriceSnapshot(models.Model):
    """
    Cached snapshot of precious metal prices (per troy ounce, in USD).
    """

    created_at = models.DateTimeField(auto_now_add=True)
    base_currency = models.CharField(max_length=3, default="USD")

    gold_ounce_usd = models.DecimalField(
        max_digits=12, decimal_places=4, null=True, blank=True
    )
    silver_ounce_usd = models.DecimalField(
        max_digits=12, decimal_places=4, null=True, blank=True
    )
    platinum_ounce_usd = models.DecimalField(
        max_digits=12, decimal_places=4, null=True, blank=True
    )
    palladium_ounce_usd = models.DecimalField(
        max_digits=12, decimal_places=4, null=True, blank=True
    )

    raw_payload = models.JSONField(null=True, blank=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"Metal prices @ {self.created_at:%Y-%m-%d %H:%M} {self.base_currency}"
