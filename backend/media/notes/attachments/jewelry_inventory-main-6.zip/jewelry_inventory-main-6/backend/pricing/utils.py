import os
import re
from datetime import timedelta
from decimal import Decimal
from typing import Optional, Tuple, Dict, Any

import requests
from django.utils import timezone

from core.utils import get_app_settings
from .models import MetalPriceSnapshot


DEFAULT_JMBULLION_URL = getattr(
    os.environ,
    "DEFAULT_JMBULLION_URL",
    "https://www.jmbullion.com/charts/gold-price/",
)


def resolve_api_config() -> Tuple[Optional[str], str]:
    """
    Decide which URL we should scrape.

    Priority:
      1. Env vars: METAL_SCRAPE_URL or METAL_API_URL (legacy)
      2. AppSettings: metals_scrape_url or metals_api_url (legacy)
      3. Default JM Bullion gold price URL

    We keep the (api_key, url) shape for backward compatibility.
    api_key is unused now.
    """
    url = (
        os.environ.get("METAL_SCRAPE_URL")
        or os.environ.get("METAL_API_URL")
        or None
    )

    settings = get_app_settings()
    if not url and getattr(settings, "metals_scrape_url", None):
        url = settings.metals_scrape_url
    if not url and getattr(settings, "metals_api_url", None):
        url = settings.metals_api_url

    if not url:
        url = DEFAULT_JMBULLION_URL

    api_key = None  # unused, but kept for compatibility
    return api_key, url


def _parse_decimal(text: str) -> Optional[Decimal]:
    if not text:
        return None
    try:
        cleaned = text.replace(",", "").strip()
        return Decimal(cleaned)
    except Exception:
        return None


def _extract_prices_from_html(html: str) -> Dict[str, Optional[Decimal]]:
    """
    Extract gold price in USD per ounce (and optionally gram/kilo) from JM Bullion HTML.

    We deliberately allow arbitrary HTML/whitespace between the label and the price,
    and between the price and 'USD' / change values.
    """

    # Make regex more forgiving:
    # - [^$]* between label and first '$' (allows tags and text)
    # - ([0-9,]+\.\d+) price capture
    flags = re.IGNORECASE | re.DOTALL

    ounce_match = re.search(
        r"Gold Price Per Ounce[^$]*\$([0-9,]+\.\d+)", html, flags
    )
    gram_match = re.search(
        r"Gold Price Per Gram[^$]*\$([0-9,]+\.\d+)", html, flags
    )
    kilo_match = re.search(
        r"Gold Price Per Kilo[^$]*\$([0-9,]+\.\d+)", html, flags
    )

    gold_ounce = _parse_decimal(ounce_match.group(1)) if ounce_match else None
    gold_gram = _parse_decimal(gram_match.group(1)) if gram_match else None
    gold_kilo = _parse_decimal(kilo_match.group(1)) if kilo_match else None

    # Fallback: section around "Gold Spot Price" – grab first "$... USD", allowing HTML entities
    if gold_ounce is None:
        spot_idx = html.lower().find("gold spot price")
        if spot_idx != -1:
            snippet = html[spot_idx : spot_idx + 3000]
            # Allow up to ~20 non-digit chars (spaces, &nbsp;, tags) between number and 'USD'
            spot_match = re.search(
                r"\$([0-9,]+\.\d+)[^0-9]{0,20}USD", snippet, flags
            )
            if spot_match:
                gold_ounce = _parse_decimal(spot_match.group(1))

    # Last resort: first "$... USD" anywhere in the page
    if gold_ounce is None:
        any_usd_match = re.search(
            r"\$([0-9,]+\.\d+)[^0-9]{0,20}USD", html, flags
        )
        if any_usd_match:
            gold_ounce = _parse_decimal(any_usd_match.group(1))

    return {
        "gold_ounce_usd": gold_ounce,
        "gold_gram_usd": gold_gram,
        "gold_kilo_usd": gold_kilo,
    }


def fetch_metal_prices_from_api() -> Tuple[Optional[Dict[str, Any]], Optional[str]]:
    """
    Fetch latest metal prices by scraping JM Bullion.

    Returns:
      (data_dict, error_str or None)

    data_dict is compatible with MetalPriceSnapshot:
      {
        "base_currency": "USD",
        "gold_ounce_usd": Decimal,
        "silver_ounce_usd": None,
        "platinum_ounce_usd": None,
        "palladium_ounce_usd": None,
        "raw_payload": { ... JSON-serializable ... },
      }
    """
    api_key, url = resolve_api_config()  # api_key unused
    if not url:
        return None, "No URL configured for metal price scraping."

    headers = {
        "User-Agent": "MarysaInventoryBot/1.0 (+scraping gold spot price)",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    }

    try:
        resp = requests.get(url, headers=headers, timeout=10)
        resp.raise_for_status()
        html = resp.text
    except Exception as exc:
        return None, f"Error fetching gold price page: {exc}"

    prices = _extract_prices_from_html(html)
    gold_ounce = prices.get("gold_ounce_usd")

    if gold_ounce is None:
        return None, "Could not parse gold price from JM Bullion HTML."

    data: Dict[str, Any] = {
        "base_currency": "USD",
        "gold_ounce_usd": gold_ounce,
        "silver_ounce_usd": None,
        "platinum_ounce_usd": None,
        "palladium_ounce_usd": None,
        "raw_payload": {
            "source": "jmbullion.com",
            "url": url,
            "gold_price_per_ounce": (
                str(prices.get("gold_ounce_usd"))
                if prices.get("gold_ounce_usd") is not None
                else None
            ),
            "gold_price_per_gram": (
                str(prices.get("gold_gram_usd"))
                if prices.get("gold_gram_usd") is not None
                else None
            ),
            "gold_price_per_kilo": (
                str(prices.get("gold_kilo_usd"))
                if prices.get("gold_kilo_usd") is not None
                else None
            ),
        },
    }
    return data, None


def get_latest_metal_prices(
    max_age_minutes: int = 10,
) -> Tuple[Optional[MetalPriceSnapshot], Optional[str]]:
    """
    Return (MetalPriceSnapshot or None, error_str or None).

    - If we have a recent snapshot (created_at within max_age_minutes), return it.
    - Otherwise, scrape JM Bullion for a fresh price, store it as a new
      MetalPriceSnapshot, and return that.
    - On scraping failure, fall back to the newest snapshot we have.
    """
    now = timezone.now()
    cutoff = now - timedelta(minutes=max_age_minutes)

    # Use recent snapshot if available
    latest = MetalPriceSnapshot.objects.filter(created_at__gte=cutoff).first()
    if latest:
        return latest, None

    # Fetch fresh data via scraping
    data, error = fetch_metal_prices_from_api()
    if error or not data:
        # Fallback to whatever we have (newest snapshot)
        fallback = MetalPriceSnapshot.objects.first()
        return fallback, error

    snapshot = MetalPriceSnapshot.objects.create(**data)
    return snapshot, None