
# 📦 Jewelry Inventory System  

A modular, scalable backend for managing products, variants, QR codes, pricing, tax rules, multi-location inventory, and e-commerce integrations (WooCommerce + Shopify).  
Built with **Django 4.2**, **PostgreSQL**, and **pytest**.

---

# 🚀 Features

### **Product & Catalog**
- Products + variants with auto-generated SKUs  
- Compact **QR code generation** for scanning workflows  
- Automatic uniqueness handling for SKUs  
- Collections, suppliers, variant metadata

### **Inventory Management**
- Multi-location stock (`VariantLocationStock`)  
- Per-location quantity tracking  
- Support for warehouses, stores, studios

### **Sales & Order Management**
- Sales orders with subtotal, shipping, discount, tax, and total calculation  
- Line items with per-line taxes  
- Automatic tax updates on save  
- Ready for checkout or external order imports

### **Tax Engine**
- Flexible `TaxRule` model (country + state)  
- Full tax computation in `taxes.services`  
- Optional application to shipping  
- Fallback logic:
  1. country+state  
  2. country  
  3. default rule  

### **Integrations**
- Sync framework for:
  - **WooCommerce**
  - **Shopify**
- DRF API endpoints  
- Admin-only sync action  
- External ID preservation  
- Last-sync timestamp tracking

### **Global Settings**
- Singleton `AppSettings`  
- Manages default country, currency, branding, and future configuration

### **QR Code Support**
- Version-1 Low error correction (smallest possible QR)  
- Encodes compact base36 short-codes  
- Auto-saving into variant image field  
- Scannable from mobile or hardware scanners

### **CI & Testing**
- Full `pytest` suite  
- GitHub Actions pipeline included  
- Coverage for:
  - Tax rules
  - Orders
  - Product variants
  - Core utilities (SKU, QR)
  - Integrations API  
  - AppSettings singleton behavior

---

# 🗂 Project Structure

```
jewelry_inventory/
  appsettings/        — Global singleton settings
  api/                — DRF serializers & API entrypoints
  catalog/            — Products, Variants, SKU/QR utilities
  core/               — Shared utils (SKU builder, QR generator)
  config/             — Django settings, urls, WSGI
  integrations/       — WooCommerce + Shopify connectors
  inventory/          — Variant per-location stock tracking
  sales/              — Orders + order lines
  suppliers/          — Supplier management
  taxes/              — Tax rules & tax engine
  tests/              — Comprehensive pytest suite
```

---

# 🛠 Requirements

- Python **3.11**
- Django **4.2**
- PostgreSQL **15+**
- Redis (optional)
- pip / virtualenv

See full dependencies in:

```
requirements.txt
```

---

# 🔧 Installation & Setup

### 1. Clone the repo

```bash
git clone https://github.com/your-org/jewelry-inventory.git
cd jewelry-inventory
```

### 2. Create a virtual environment

```bash
python3.11 -m venv venv
source venv/bin/activate
```

### 3. Install dependencies

```bash
pip install -r requirements.txt
```

### 4. Configure environment variables

Create a `.env` (or export into shell):

```
POSTGRES_DB=jewelrydb
POSTGRES_USER=jewelryuser
POSTGRES_PASSWORD=jewelrypass
POSTGRES_HOST=localhost
POSTGRES_PORT=5432

SECRET_KEY=your-secret-key
DEBUG=1
```

### 5. Apply migrations

```bash
python manage.py migrate
```

### 6. Create superuser

```bash
python manage.py createsuperuser
```

### 7. Run the server

```bash
python manage.py runserver
```

---

# 🧪 Running Tests

Run all tests:

```bash
pytest
```

With coverage:

```bash
pytest --cov=. --cov-report=term-missing
```

---

# 🤖 Continuous Integration (GitHub Actions)

Workflow file:

```
.github/workflows/django-ci.yml
```

Runs:

- Postgres
- Migrations  
- pytest  
- Coverage  

On:

- Push to `main`
- PRs to `main`

---

# 📄 API Overview

```
/api/integrations/stores/
/api/integrations/stores/<id>/sync/
/api/products/
/api/orders/
```

---

# 🧩 Key Utilities

### SKU Builder  
`core/utils.build_sku_for_variant()`

### QR Code Generator  
`core/utils.generate_barcode_for_variant()`

### Tax Engine  
`taxes/services.py`

### Sync Services  
`integrations/services.py`

---

# 🙌 Contributing

1. Fork  
2. Create feature branch  
3. Add tests  
4. PR  

Must pass CI.

---

# 🏁 License

MIT License.
