import {
  MouseEvent as ReactMouseEvent,
  useEffect,
  useRef,
  useState,
} from "react";

export type LabelFieldId =
  | "name"
  | "sku"
  | "size_color"
  | "metal_purity"
  | "price"
  | "barcode"
  | "stock";

export type LabelFieldConfig = {
  enabled: boolean;
  x: number; // percentage (0–100)
  y: number; // percentage (0–100)
};

export type LabelLayout = {
  fontPx: number;
  fields: Record<LabelFieldId, LabelFieldConfig>;
};

export type LabelSample = {
  name: string;
  sku: string;
  size_color: string;
  metal_purity: string;
  price: string;
  barcode: string;
  stock: string;
};

type Props = {
  sample: LabelSample;                  // sample text to preview with
  layout: LabelLayout;                  // current layout
  onLayoutChange: (layout: LabelLayout) => void; // callback when user drags fields
};

const FIELD_LABELS: Record<LabelFieldId, string> = {
  name: "Product name",
  sku: "SKU",
  size_color: "Size / color",
  metal_purity: "Metal / purity",
  price: "Price",
  barcode: "Barcode text",
  stock: "Stock qty",
};

export default function LabelDesigner({ sample, layout, onLayoutChange }: Props) {
  const canvasRef = useRef<HTMLDivElement | null>(null);
  const draggingFieldRef = useRef<LabelFieldId | null>(null);
  const dragOffsetRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });

  // --- dragging logic ---

  function startDrag(e: ReactMouseEvent<HTMLDivElement>, fieldId: LabelFieldId) {
    e.preventDefault();
    e.stopPropagation();
    const canvas = canvasRef.current;
    if (!canvas) return;

    draggingFieldRef.current = fieldId;

    const canvasRect = canvas.getBoundingClientRect();
    const fieldRect = (e.currentTarget as HTMLDivElement).getBoundingClientRect();

    dragOffsetRef.current = {
      x: e.clientX - fieldRect.left,
      y: e.clientY - fieldRect.top,
    };

    window.addEventListener("mousemove", onWindowMouseMove);
    window.addEventListener("mouseup", onWindowMouseUp);
  }

  function onWindowMouseMove(e: MouseEvent) {
    const canvas = canvasRef.current;
    const fieldId = draggingFieldRef.current;
    if (!canvas || !fieldId) return;

    const canvasRect = canvas.getBoundingClientRect();

    let leftPx = e.clientX - canvasRect.left - dragOffsetRef.current.x;
    let topPx = e.clientY - canvasRect.top - dragOffsetRef.current.y;

    // clamp to label bounds
    const fieldEl = canvas.querySelector(
      `[data-field-id="${fieldId}"]`
    ) as HTMLDivElement | null;
    const fieldRect = fieldEl?.getBoundingClientRect();

    const maxLeft = canvasRect.width - (fieldRect?.width || 0);
    const maxTop = canvasRect.height - (fieldRect?.height || 0);

    if (leftPx < 0) leftPx = 0;
    if (topPx < 0) topPx = 0;
    if (leftPx > maxLeft) leftPx = maxLeft;
    if (topPx > maxTop) topPx = maxTop;

    const xPerc = (leftPx / canvasRect.width) * 100;
    const yPerc = (topPx / canvasRect.height) * 100;

    onLayoutChange({
      ...layout,
      fields: {
        ...layout.fields,
        [fieldId]: {
          ...layout.fields[fieldId],
          x: xPerc,
          y: yPerc,
        },
      },
    });
  }

  function onWindowMouseUp() {
    draggingFieldRef.current = null;
    window.removeEventListener("mousemove", onWindowMouseMove);
    window.removeEventListener("mouseup", onWindowMouseUp);
  }

  useEffect(() => {
    return () => {
      window.removeEventListener("mousemove", onWindowMouseMove);
      window.removeEventListener("mouseup", onWindowMouseUp);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // --- helpers ---

  function getFieldText(id: LabelFieldId): string {
    switch (id) {
      case "name":
        return sample.name;
      case "sku":
        return sample.sku;
      case "size_color":
        return sample.size_color;
      case "metal_purity":
        return sample.metal_purity;
      case "price":
        return sample.price;
      case "barcode":
        return sample.barcode;
      case "stock":
        return sample.stock;
      default:
        return "";
    }
  }

  function toggleField(id: LabelFieldId, enabled: boolean) {
    onLayoutChange({
      ...layout,
      fields: {
        ...layout.fields,
        [id]: { ...layout.fields[id], enabled },
      },
    });
  }

  function changeFont(size: number) {
    onLayoutChange({
      ...layout,
      fontPx: size,
    });
  }

  return (
    <div>
      {/* Controls */}
      <div className="mb-3">
        <div className="row g-2">
          <div className="col-6">
            <label className="form-label small mb-1">Font size</label>
            <input
              type="range"
              className="form-range"
              min={7}
              max={12}
              value={layout.fontPx}
              onChange={(e) => changeFont(parseInt(e.target.value || "9", 10))}
            />
          </div>
          <div className="col-6">
            <label className="form-label small mb-1">Visible fields</label>
            <div className="row g-1">
              {(Object.keys(FIELD_LABELS) as LabelFieldId[]).map((id) => (
                <div className="col-6" key={id}>
                  <div className="form-check form-check-sm">
                    <input
                      id={`field-${id}`}
                      type="checkbox"
                      className="form-check-input"
                      checked={layout.fields[id].enabled}
                      onChange={(e) => toggleField(id, e.target.checked)}
                    />
                    <label
                      htmlFor={`field-${id}`}
                      className="form-check-label small"
                    >
                      {FIELD_LABELS[id]}
                    </label>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Label preview */}
      <div className="label-canvas-wrapper">
        <div className="label-canvas" ref={canvasRef}>
          <div
            className="label-canvas-inner"
            style={{ fontSize: layout.fontPx }}
          >
            {!sample && (
              <div className="label-preview-muted">
                Select a sample product to preview the label.
              </div>
            )}

            {(Object.keys(layout.fields) as LabelFieldId[]).map((id) => {
              const cfg = layout.fields[id];
              if (!cfg.enabled) return null;

              const text = getFieldText(id);
              if (!text) return null;

              const style = {
                left: `${cfg.x}%`,
                top: `${cfg.y}%`,
              };

              return (
                <div
                  key={id}
                  data-field-id={id}
                  className="draggable-field"
                  style={style}
                  onMouseDown={(e) => startDrag(e, id)}
                >
                  {text}
                </div>
              );
            })}
          </div>
        </div>
      </div>

      <p className="text-muted small mt-2 mb-0">
        Drag each field directly on the label to choose its placement. This
        layout can be reused for printing the real labels.
      </p>
    </div>
  );
}
