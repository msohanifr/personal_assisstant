import { useEffect, useState } from "react";
import { apiGet } from "../api/client";

type MeResponse = {
  username: string;
  is_staff: boolean;
  is_superuser: boolean;
};

export default function ProfilePage() {
  const [me, setMe] = useState<MeResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;

    async function load() {
      setLoading(true);
      setError(null);
      try {
        const res = await apiGet<MeResponse>("/api/auth/me/");
        if (!cancelled) {
          setMe(res);
        }
      } catch (err: any) {
        if (!cancelled) {
          setError(err.message || "Failed to load profile.");
        }
      } finally {
        if (!cancelled) {
          setLoading(false);
        }
      }
    }

    load();

    return () => {
      cancelled = true;
    };
  }, []);

  if (loading && !me) {
    return (
      <div className="container py-4">
        <p>Loading profile…</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="container py-4">
        <div className="alert alert-danger">{error}</div>
      </div>
    );
  }

  if (!me) {
    return (
      <div className="container py-4">
        <p className="text-muted">No profile information available.</p>
      </div>
    );
  }

  return (
    <div className="container py-4">
      <h1 className="h4 mb-3">Profile</h1>

      <div className="card shadow-sm mb-4">
        <div className="card-body">
          <h2 className="h5 mb-3">Account details</h2>

          <dl className="row mb-0">
            <dt className="col-sm-3">Username</dt>
            <dd className="col-sm-9">{me.username}</dd>

            <dt className="col-sm-3">Staff</dt>
            <dd className="col-sm-9">
              {me.is_staff ? "Yes (staff account)" : "No"}
            </dd>

            <dt className="col-sm-3">Superuser</dt>
            <dd className="col-sm-9">
              {me.is_superuser ? "Yes (superuser)" : "No"}
            </dd>
          </dl>
        </div>
      </div>

      <div className="card shadow-sm">
        <div className="card-body">
          <h2 className="h6 mb-2">Manage your account</h2>
          <p className="text-muted mb-3">
            For now, account changes (like password, email, permissions) are
            managed in the Django admin.
          </p>
          <a href="/admin/password_change/" className="btn btn-outline-dark btn-sm">
            Change password in admin
          </a>
        </div>
      </div>
    </div>
  );
}