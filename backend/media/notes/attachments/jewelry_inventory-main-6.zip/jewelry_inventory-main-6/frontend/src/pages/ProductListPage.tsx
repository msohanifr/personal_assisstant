import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { apiGet } from "../api/client";

type ProductVariantLite = {
  id: number;
  sku: string;
  size?: string | null;
  color?: string | null;
  stock_quantity?: number | null;
  [key: string]: any;
};

type ProductListItem = {
  id: number;
  name: string;
  slug?: string;
  sku_base?: string;
  gold_purity?: string | null;
  active?: boolean;
  variants?: ProductVariantLite[];
  // allow any extra fields – e.g. image_url, collection, etc.
  [key: string]: any;
};

type ProductListResponse =
  | ProductListItem[]
  | {
      results?: ProductListItem[];
      count?: number;
      next?: string | null;
      previous?: string | null;
    };

// safely normalize DRF list (array or {results:[...]})
function normalizeProducts(data: ProductListResponse): ProductListItem[] {
  if (Array.isArray(data)) return data;
  return data.results ?? [];
}

function getProductImageUrl(p: ProductListItem): string | null {
  // Try dedicated fields first
  const woo = (p as any).woo_data;
  const wooImages = Array.isArray(woo?.images) ? woo.images : [];
  const wooFirst = wooImages[0] || null;

  return (
    (p.main_image_url as string | undefined) || // uploaded image
    (p.primary_image_url as string | undefined) || // from Woo sync
    (p.image_url as string | undefined) ||
    (p.image as string | undefined) ||
    (wooFirst?.thumbnail as string | undefined) || // tiny Woo thumbnail
    (wooFirst?.src as string | undefined) || // full Woo image
    null
  );
}

function getVariantCount(p: ProductListItem): number {
  if (Array.isArray(p.variants)) return p.variants.length;
  return (p as any).variant_count ?? 0;
}

export default function ProductListPage() {
  const [products, setProducts] = useState<ProductListItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [search, setSearch] = useState("");

  // NEW: pagination state
  const [pageSize, setPageSize] = useState<number>(10);
  const [currentPage, setCurrentPage] = useState<number>(1);

  const navigate = useNavigate();

  useEffect(() => {
    void loadProducts();
  }, []);

  async function loadProducts() {
    setLoading(true);
    setError(null);
    try {
      // NOTE: This assumes you will mount catalog.urls under /api/catalog/
      // e.g. path("api/catalog/", include("catalog.urls"))
      const data = await apiGet<ProductListResponse>("/api/catalog/products/");
      setProducts(normalizeProducts(data));
      setCurrentPage(1); // reset page when data reloads
    } catch (err: any) {
      console.error(err);
      setError(err.message || "Failed to load products.");
    } finally {
      setLoading(false);
    }
  }

  const filtered = products.filter((p) => {
    if (!search.trim()) return true;
    const q = search.trim().toLowerCase();
    const name = (p.name || "").toLowerCase();
    const skuBase = (p.sku_base || "").toLowerCase();
    return name.includes(q) || skuBase.includes(q);
  });

  // Reset to page 1 when search or page size changes
  useEffect(() => {
    setCurrentPage(1);
  }, [search, pageSize]);

  // Pagination calculations
  const totalItems = filtered.length;
  const totalPages = totalItems > 0 ? Math.ceil(totalItems / pageSize) : 1;
  const safePage = Math.min(currentPage, totalPages);
  const startIndex = (safePage - 1) * pageSize;
  const endIndex = startIndex + pageSize;
  const paginated = filtered.slice(startIndex, endIndex);

  const startItemNumber = totalItems === 0 ? 0 : startIndex + 1;
  const endItemNumber = totalItems === 0 ? 0 : Math.min(endIndex, totalItems);

  function handlePageSizeChange(e: React.ChangeEvent<HTMLSelectElement>) {
    const value = parseInt(e.target.value, 10);
    setPageSize(value);
  }

  function goToFirstPage() {
    setCurrentPage(1);
  }

  function goToPrevPage() {
    setCurrentPage((p) => Math.max(1, p - 1));
  }

  function goToNextPage() {
    setCurrentPage((p) => Math.min(totalPages, p + 1));
  }

  function goToLastPage() {
    setCurrentPage(totalPages);
  }

  return (
    <div className="container-fluid py-3">
      {/* Header */}
      <div className="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-3">
        <div className="mb-2 mb-md-0">
          <h1 className="h4 mb-1">
            <i className="fa-solid fa-box-open me-2" />
            Products
          </h1>
          <p className="text-muted small mb-0">
            Browse your products with thumbnails and open details to see
            variants and settings.
          </p>
        </div>
        <div className="d-flex flex-wrap gap-2">
          <button
            type="button"
            className="btn btn-sm btn-outline-secondary"
            onClick={() => void loadProducts()}
          >
            <i className="fa-solid fa-rotate me-1" />
            Refresh
          </button>
          <button
            type="button"
            className="btn btn-sm btn-primary"
            onClick={() => navigate("/products/sync")}
          >
            <i className="fa-solid fa-arrows-rotate me-1" />
            Product sync
          </button>
        </div>
      </div>

      {/* Search bar */}
      <div className="card shadow-sm border-0 mb-3">
        <div className="card-body py-2">
          <div className="row g-2 align-items-center">
            <div className="col-md-6">
              <label className="form-label mb-1 small text-uppercase text-muted">
                Search
              </label>
              <input
                type="text"
                className="form-control form-control-sm"
                placeholder="Search by name or SKU base"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </div>
            <div className="col-md-6 text-md-end">
              <span className="small text-muted">
                Showing <strong>{totalItems}</strong> of{" "}
                <strong>{products.length}</strong> products
              </span>
            </div>
          </div>
        </div>
      </div>

      {error && (
        <div className="alert alert-danger py-2" role="alert">
          {error}
        </div>
      )}

      {loading && <p className="text-muted small mb-0">Loading products…</p>}

      {!loading && !error && filtered.length === 0 && (
        <div className="alert alert-secondary py-2">
          No products match your search.
        </div>
      )}

      {/* Product list */}
      {!loading && filtered.length > 0 && (
        <div className="card shadow-sm border-0">
          <div className="card-body p-2">
            {/* Pagination controls */}
            <div className="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-2 gap-2">
              <div className="small text-muted">
                Showing{" "}
                <strong>
                  {startItemNumber}–{endItemNumber}
                </strong>{" "}
                of <strong>{totalItems}</strong> products
              </div>
              <div className="d-flex flex-wrap align-items-center gap-2">
                <div className="d-flex align-items-center gap-1">
                  <span className="small text-muted">Rows per page:</span>
                  <select
                    className="form-select form-select-sm"
                    style={{ width: "80px" }}
                    value={pageSize}
                    onChange={handlePageSizeChange}
                  >
                    <option value={10}>10</option>
                    <option value={20}>20</option>
                    <option value={50}>50</option>
                    <option value={100}>100</option>
                  </select>
                </div>
                <div className="d-flex align-items-center gap-2">
                  <span className="small text-muted">
                    Page <strong>{safePage}</strong> of{" "}
                    <strong>{totalPages}</strong>
                  </span>
                  <div className="btn-group btn-group-sm" role="group">
                    <button
                      type="button"
                      className="btn btn-outline-secondary"
                      onClick={goToFirstPage}
                      disabled={safePage === 1}
                    >
                      «
                    </button>
                    <button
                      type="button"
                      className="btn btn-outline-secondary"
                      onClick={goToPrevPage}
                      disabled={safePage === 1}
                    >
                      ‹
                    </button>
                    <button
                      type="button"
                      className="btn btn-outline-secondary"
                      onClick={goToNextPage}
                      disabled={safePage === totalPages}
                    >
                      ›
                    </button>
                    <button
                      type="button"
                      className="btn btn-outline-secondary"
                      onClick={goToLastPage}
                      disabled={safePage === totalPages}
                    >
                      »
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Table */}
            <div className="table-responsive">
              <table className="table table-hover align-middle mb-0">
                <thead className="table-light">
                  <tr>
                    <th style={{ width: 72 }}>Image</th>
                    <th>Name</th>
                    <th style={{ width: 140 }}>SKU base</th>
                    <th style={{ width: 120 }}>Gold/purity</th>
                    <th style={{ width: 110 }}>Variants</th>
                    <th style={{ width: 90 }}>Status</th>
                    <th style={{ width: 70 }}></th>
                  </tr>
                </thead>
                <tbody>
                  {paginated.map((p) => {
                    const imageUrl = getProductImageUrl(p);
                    const variantCount = getVariantCount(p);
                    const active =
                      typeof p.active === "boolean" ? p.active : true;

                    return (
                      <tr
                        key={p.id}
                        style={{ cursor: "pointer" }}
                        onClick={() => navigate(`/products/${p.id}`)}
                      >
                        <td>
                          <div className="product-thumb">
                            {imageUrl ? (
                              <img
                                src={imageUrl}
                                alt={p.name}
                                className="product-thumb-img"
                              />
                            ) : (
                              <div className="product-thumb-placeholder">
                                {p.name ? p.name.charAt(0).toUpperCase() : "?"}
                              </div>
                            )}
                          </div>
                        </td>
                        <td>
                          <div className="fw-semibold">{p.name}</div>
                          {p.sku_base && (
                            <div className="small text-muted">
                              Base SKU: {p.sku_base}
                            </div>
                          )}
                        </td>
                        <td>
                          <span className="small">
                            {p.sku_base || (
                              <span className="text-muted">—</span>
                            )}
                          </span>
                        </td>
                        <td>
                          <span className="small">
                            {p.gold_purity || (
                              <span className="text-muted">—</span>
                            )}
                          </span>
                        </td>
                        <td>
                          <span className="badge bg-secondary-subtle text-dark">
                            {variantCount}
                          </span>
                        </td>
                        <td>
                          {active ? (
                            <span className="badge bg-success-subtle text-success">
                              Active
                            </span>
                          ) : (
                            <span className="badge bg-secondary-subtle text-muted">
                              Inactive
                            </span>
                          )}
                        </td>
                        <td className="text-end">
                          <button
                            type="button"
                            className="btn btn-sm btn-outline-secondary"
                            onClick={(e) => {
                              e.stopPropagation();
                              navigate(`/products/${p.id}`);
                            }}
                          >
                            <i className="fa-solid fa-pen-to-square" />
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}