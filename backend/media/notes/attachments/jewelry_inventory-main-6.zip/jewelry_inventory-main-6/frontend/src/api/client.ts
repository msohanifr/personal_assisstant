// frontend/src/api/client.ts
const API_BASE_URL = "";  // same origin

function getCookie(name: string): string | null {
  if (typeof document === "undefined") return null;
  const value = `; ${document.cookie}`;
  const parts = value.split(`; ${name}=`);
  if (parts.length === 2) {
    return parts.pop()!.split(";").shift() || null;
  }
  return null;
}

async function parseJsonOrText<T>(res: Response): Promise<T> {
  const text = await res.text();

  if (!res.ok) {
    let message = text;
    try {
      const parsed = JSON.parse(text);
      message = (parsed as any).detail || JSON.stringify(parsed);
    } catch {
      // ignore JSON parse errors
    }
    throw new Error(message || `API error ${res.status}`);
  }

  if (!text) {
    return {} as T;
  }

  try {
    return JSON.parse(text) as T;
  } catch {
    // fallback: return as text
    return text as unknown as T;
  }
}

export async function apiGet<T>(path: string, options: RequestInit = {}): Promise<T> {
  const res = await fetch(`${API_BASE_URL}${path}`, {
    credentials: "include",  // Django session auth
    ...options,
  });
  return parseJsonOrText<T>(res);
}

export async function apiPost<T>(
  path: string,
  body?: any,
  options: RequestInit = {}
): Promise<T> {
  const csrfToken = getCookie("csrftoken");

  const headers: HeadersInit = {
    "Content-Type": "application/json",
    ...(options.headers || {}),
  };

  if (csrfToken) {
    (headers as any)["X-CSRFToken"] = csrfToken;
  }

  const res = await fetch(`${API_BASE_URL}${path}`, {
    method: "POST",
    credentials: "include",
    headers,
    body: body ? JSON.stringify(body) : null,
    ...options,
  });
  return parseJsonOrText<T>(res);
}

export async function apiPatch<T>(
  path: string,
  body: any,
  options: RequestInit = {}
): Promise<T> {
  const csrfToken = getCookie("csrftoken");

  const headers: HeadersInit = {
    "Content-Type": "application/json",
    ...(options.headers || {}),
  };

  if (csrfToken) {
    (headers as any)["X-CSRFToken"] = csrfToken;
  }

  const res = await fetch(`${API_BASE_URL}${path}`, {
    method: "PATCH",
    credentials: "include",
    headers,
    body: JSON.stringify(body),
    ...options,
  });
  return parseJsonOrText<T>(res);
}

export async function apiPostForm<T>(
  path: string,
  formData: FormData,
  options: RequestInit = {}
): Promise<T> {
  const csrfToken = getCookie("csrftoken");

  const headers: HeadersInit = {
    ...(options.headers || {}),
  };

  if (csrfToken) {
    (headers as any)["X-CSRFToken"] = csrfToken;
  }

  const res = await fetch(`${API_BASE_URL}${path}`, {
    method: "POST",
    credentials: "include",
    headers,
    body: formData,
    ...options,
  });
  return parseJsonOrText<T>(res);
}