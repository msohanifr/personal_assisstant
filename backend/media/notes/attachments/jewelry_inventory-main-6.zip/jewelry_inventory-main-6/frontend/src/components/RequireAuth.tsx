import { ReactNode, useEffect, useState } from "react";
import { useLocation, Navigate } from "react-router-dom";

type Props = {
  children: ReactNode;
};

export default function RequireAuth({ children }: Props) {
  const [checking, setChecking] = useState(true);
  const [authenticated, setAuthenticated] = useState<boolean | null>(null);
  const location = useLocation();

  useEffect(() => {
    let cancelled = false;

    async function check() {
      try {
        const res = await fetch("/api/auth/me/", {
          credentials: "include",
        });

        if (cancelled) return;

        if (res.ok) {
          setAuthenticated(true);
        } else if (res.status === 401 || res.status === 403) {
          setAuthenticated(false);
        } else {
          setAuthenticated(false);
        }
      } catch (e) {
        if (!cancelled) setAuthenticated(false);
      } finally {
        if (!cancelled) setChecking(false);
      }
    }

    check();
    return () => {
      cancelled = true;
    };
  }, []);

  if (checking) {
    return <div className="p-3">Checking session…</div>;
  }

  if (!authenticated) {
    return <Navigate to="/login" state={{ from: location.pathname }} replace />;
  }

  return <>{children}</>;
}
