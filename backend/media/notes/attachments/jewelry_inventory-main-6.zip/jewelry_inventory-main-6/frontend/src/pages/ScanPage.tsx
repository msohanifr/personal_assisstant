import ScanLookupCard from "../components/ScanLookupCard";

export default function ScanPage() {
  return (
    <div className="container py-4">
      {/* Page header */}
      <div className="d-flex justify-content-between align-items-center mb-3">
        <div>
          <h1 className="h3 fw-bold">Scan &amp; Lookup</h1>
          <p className="text-muted mb-0">
            Use your barcode scanner or type a code to quickly find variants and
            check stock, pricing, and details.
          </p>
        </div>

        <div className="text-end d-none d-md-block">
          <span className="badge bg-light text-muted border">
            <i className="fa-solid fa-barcode me-1" />
            Optimized for hardware scanners
          </span>
        </div>
      </div>

      {/* Main layout: left = scan, right = space for tools */}
      <div className="row g-4">
        {/* Left column: main scan card */}
        <div className="col-lg-5 col-xl-4">
          <ScanLookupCard autoFocus />

          <div className="mt-3 small text-muted">
            Tips:
            <ul className="mb-0 ps-3">
              <li>
                Plug in your barcode scanner and scan directly into the input,
                then press Enter (most scanners do this automatically).
              </li>
              <li>
                You can also type a SKU manually if you don&apos;t have the tag
                in front of you.
              </li>
            </ul>
          </div>
        </div>

        {/* Right column: placeholder dashboard panels for future features */}
        <div className="col-lg-7 col-xl-8">
          {/* Session overview / placeholder */}
          <div className="card shadow-sm border-0 mb-3">
            <div className="card-body">
              <h5 className="card-title fw-semibold mb-2">
                Session overview (coming soon)
              </h5>
              <p className="text-muted small mb-0">
                This area is reserved for future tools, like:
              </p>
              <ul className="text-muted small mb-0 mt-1">
                <li>Recent scans in this session</li>
                <li>Quick stock adjustments for the scanned item</li>
                <li>Tag printing or QR-label reprints</li>
                <li>Price checks and margin helpers</li>
              </ul>
            </div>
          </div>

          {/* Quick navigation / shortcuts */}
          <div className="card shadow-sm border-0 mb-3">
            <div className="card-body">
              <h6 className="card-title fw-semibold mb-2">Shortcuts</h6>
              <p className="text-muted small">
                Handy links while you&apos;re scanning:
              </p>
              <ul className="small mb-0">
                <li>
                  <a href="/admin/catalog/product/" target="_blank" rel="noreferrer">
                    Open products list in admin
                  </a>
                </li>
                <li>
                  <a
                    href="/admin/catalog/productvariant/"
                    target="_blank"
                    rel="noreferrer"
                  >
                    Open variants list in admin
                  </a>
                </li>
                <li>
                  <a href="/admin" target="_blank" rel="noreferrer">
                    Go to Django admin home
                  </a>
                </li>
              </ul>
            </div>
          </div>

          {/* Help / how-to panel */}
          <div className="card shadow-sm border-0">
            <div className="card-body">
              <h6 className="card-title fw-semibold mb-2">
                How this scan dashboard works
              </h6>
              <p className="text-muted small mb-2">
                The scan input on the left calls your existing{" "}
                <code>/api/scan/lookup/</code> endpoint. It matches either:
              </p>
              <ul className="text-muted small mb-0">
                <li>Barcodes printed on your tags</li>
                <li>Variant SKUs (if you type them manually)</li>
              </ul>
              <p className="text-muted small mt-2 mb-0">
                We can extend this page later with batch operations, price
                checks, and more inventory tools — the layout here is designed
                to grow with those features.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}