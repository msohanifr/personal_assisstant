import {
  ChangeEvent,
  FormEvent,
  useEffect,
  useMemo,
  useState,
} from "react";
import { apiGet } from "../api/client";

type Location = {
  id: number;
  name: string;
  code: string;
  location_type: string;
  parent?: number | null;
  street?: string;
  street_number?: string;
  address_line2?: string;
  city?: string;
  region?: string;
  postcode?: string;
  country?: string;
  notes?: string;
  image?: string | null;
};

type LocationFormState = {
  id?: number | null;
  name: string;
  code: string;
  location_type: string;
  parent: number | null;
  street: string;
  street_number: string;
  address_line2: string;
  city: string;
  region: string;
  postcode: string;
  country: string;
  notes: string;
  imageFile: File | null;
};

const EMPTY_FORM: LocationFormState = {
  id: null,
  name: "",
  code: "",
  location_type: "site",
  parent: null,
  street: "",
  street_number: "",
  address_line2: "",
  city: "",
  region: "",
  postcode: "",
  country: "",
  notes: "",
  imageFile: null,
};

export default function LocationDashboardPage() {
  const [locations, setLocations] = useState<Location[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [form, setForm] = useState<LocationFormState>(EMPTY_FORM);
  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState<string | null>(null);

  const [selectedId, setSelectedId] = useState<number | null>(null);

  useEffect(() => {
    void loadLocations();
  }, []);

  async function loadLocations() {
    setLoading(true);
    setError(null);
    try {
      const data = await apiGet<Location[]>("/api/locations/");
      const list = Array.isArray(data)
        ? data
        : (data as any).results || [];
      setLocations(list);
    } catch (err: any) {
      console.error(err);
      setError(err.message || "Failed to load locations.");
    } finally {
      setLoading(false);
    }
  }

  function handleSelect(loc: Location) {
    setSelectedId(loc.id);
    setForm({
      id: loc.id,
      name: loc.name || "",
      code: loc.code || "",
      location_type: loc.location_type || "site",
      parent: (loc as any).parent ?? null,
      street: (loc as any).street || "",
      street_number: (loc as any).street_number || "",
      address_line2: (loc as any).address_line2 || "",
      city: (loc as any).city || "",
      region: (loc as any).region || "",
      postcode: (loc as any).postcode || "",
      country: (loc as any).country || "",
      notes: (loc as any).notes || "",
      imageFile: null,
    });
  }

  function handleNewLocation() {
    setSelectedId(null);
    setForm(EMPTY_FORM);
  }

  function handleInputChange(
    e: ChangeEvent<
      HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement
    >
  ) {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  }

  function handleImageChange(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0] ?? null;
    setForm((prev) => ({ ...prev, imageFile: file }));
  }

  const fullAddress = useMemo(() => {
    const parts = [
      form.street_number,
      form.street,
      form.address_line2,
      form.city,
      form.region,
      form.postcode,
      form.country,
    ].filter(Boolean);
    return parts.join(", ");
  }, [
    form.street_number,
    form.street,
    form.address_line2,
    form.city,
    form.region,
    form.postcode,
    form.country,
  ]);

  const mapUrl = fullAddress
    ? `https://www.google.com/maps?q=${encodeURIComponent(
        fullAddress
      )}&output=embed`
    : null;

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setSaving(true);
    setSaveError(null);

    try {
      const isNew = !form.id;
      const url = isNew
        ? "/api/locations/"
        : `/api/locations/${form.id}/`;

      const fd = new FormData();
      fd.append("name", form.name);
      fd.append("code", form.code);
      fd.append("location_type", form.location_type);
      if (form.parent) fd.append("parent", String(form.parent));
      fd.append("street", form.street);
      fd.append("street_number", form.street_number);
      fd.append("address_line2", form.address_line2);
      fd.append("city", form.city);
      fd.append("region", form.region);
      fd.append("postcode", form.postcode);
      fd.append("country", form.country);
      fd.append("notes", form.notes);
      if (form.imageFile) {
        fd.append("image", form.imageFile);
      }

      const res = await fetch(url, {
        method: isNew ? "POST" : "PATCH",
        credentials: "include",
        body: fd,
      });

      if (!res.ok) {
        const txt = await res.text();
        throw new Error(txt || `Save failed (${res.status})`);
      }

      await loadLocations();
    } catch (err: any) {
      console.error(err);
      setSaveError(err.message || "Failed to save location.");
    } finally {
      setSaving(false);
    }
  }

  const selectedLocation =
    locations.find((l) => l.id === selectedId) || null;

  return (
    <div className="container-fluid py-3">
      {/* Header */}
      <div className="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-3">
        <div>
          <h1 className="h4 mb-1">
            <i className="fa-solid fa-location-dot me-2" />
            Locations
          </h1>
          <p className="text-muted small mb-0">
            Manage studios, shops, safeboxes and other storage locations
            for your inventory.
          </p>
        </div>
        <div className="mt-2 mt-md-0">
          <button
            type="button"
            className="btn btn-sm btn-primary"
            onClick={handleNewLocation}
          >
            <i className="fa-solid fa-plus me-1" />
            New location
          </button>
        </div>
      </div>

      {error && (
        <div className="alert alert-danger py-2" role="alert">
          {error}
        </div>
      )}

      <div className="row g-3">
        {/* LEFT – list */}
        <div className="col-lg-5">
          <div className="card shadow-sm border-0 h-100">
            <div className="card-body">
              <h6 className="card-title fw-semibold mb-2">
                Location list
              </h6>
              <p className="text-muted small mb-3">
                Click a row to edit, or create a new location on the
                right.
              </p>

              {loading && (
                <p className="small text-muted mb-0">Loading…</p>
              )}

              {!loading && locations.length === 0 && (
                <p className="small text-muted mb-0">
                  No locations yet. Create your first one on the right.
                </p>
              )}

              {!loading && locations.length > 0 && (
                <div
                  className="table-responsive"
                  style={{ maxHeight: 420 }}
                >
                  <table className="table table-sm table-hover align-middle mb-0">
                    <thead className="table-light">
                      <tr>
                        <th>Name</th>
                        <th>Code</th>
                        <th>Type</th>
                        <th>City</th>
                      </tr>
                    </thead>
                    <tbody>
                      {locations.map((loc) => (
                        <tr
                          key={loc.id}
                          role="button"
                          className={
                            selectedId === loc.id ? "table-active" : ""
                          }
                          onClick={() => handleSelect(loc)}
                        >
                          <td>{loc.name}</td>
                          <td>
                            <code>{loc.code}</code>
                          </td>
                          <td className="text-capitalize">
                            {loc.location_type || "—"}
                          </td>
                          <td>{(loc as any).city || "—"}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* RIGHT – detail + map */}
        <div className="col-lg-7">
          <div className="card shadow-sm border-0 h-100">
            <div className="card-body">
              <h6 className="card-title fw-semibold mb-2">
                {form.id ? "Edit location" : "New location"}
              </h6>
              <p className="text-muted small mb-3">
                Store-level locations (studio, shop) or nested storage
                points (safebox, desk, tray).
              </p>

              {saveError && (
                <div className="alert alert-danger py-2">
                  {saveError}
                </div>
              )}

              <form onSubmit={handleSubmit}>
                <div className="row g-3">
                  {/* Basics */}
                  <div className="col-md-6">
                    <div className="mb-2">
                      <label className="form-label small mb-1">
                        Name
                      </label>
                      <input
                        type="text"
                        className="form-control form-control-sm"
                        name="name"
                        value={form.name}
                        onChange={handleInputChange}
                        required
                      />
                    </div>

                    <div className="mb-2">
                      <label className="form-label small mb-1">
                        Code
                      </label>
                      <input
                        type="text"
                        className="form-control form-control-sm"
                        name="code"
                        value={form.code}
                        onChange={handleInputChange}
                        required
                      />
                    </div>

                    <div className="mb-2">
                      <label className="form-label small mb-1">
                        Type
                      </label>
                      <select
                        className="form-select form-select-sm"
                        name="location_type"
                        value={form.location_type}
                        onChange={handleInputChange}
                      >
                        <option value="site">Site / Studio</option>
                        <option value="shop">Shop / Storefront</option>
                        <option value="storage">Storage</option>
                        <option value="safebox">Safebox</option>
                        <option value="desk">Desk</option>
                        <option value="other">Other</option>
                      </select>
                      <div className="form-text small">
                        Use “storage”, “safebox”, or “desk” for granular
                        bins where items live.
                      </div>
                    </div>

                    <div className="mb-2">
                      <label className="form-label small mb-1">
                        Parent location (optional)
                      </label>
                      <select
                        className="form-select form-select-sm"
                        name="parent"
                        value={form.parent ?? ""}
                        onChange={(e) =>
                          setForm((prev) => ({
                            ...prev,
                            parent: e.target.value
                              ? Number(e.target.value)
                              : null,
                          }))
                        }
                      >
                        <option value="">— None —</option>
                        {locations
                          .filter((l) => !form.id || l.id !== form.id)
                          .map((l) => (
                            <option key={l.id} value={l.id}>
                              {l.name}
                            </option>
                          ))}
                      </select>
                      <div className="form-text small">
                        Link storage bins to a studio / shop if needed.
                      </div>
                    </div>
                  </div>

                  {/* Address */}
                  <div className="col-md-6">
                    <div className="mb-2">
                      <label className="form-label small mb-1">
                        Street
                      </label>
                      <input
                        type="text"
                        className="form-control form-control-sm"
                        name="street"
                        value={form.street}
                        onChange={handleInputChange}
                      />
                    </div>

                    <div className="mb-2">
                      <label className="form-label small mb-1">
                        Street number
                      </label>
                      <input
                        type="text"
                        className="form-control form-control-sm"
                        name="street_number"
                        value={form.street_number}
                        onChange={handleInputChange}
                      />
                    </div>

                    <div className="mb-2">
                      <label className="form-label small mb-1">
                        Address line 2
                      </label>
                      <input
                        type="text"
                        className="form-control form-control-sm"
                        name="address_line2"
                        value={form.address_line2}
                        onChange={handleInputChange}
                      />
                    </div>

                    <div className="row g-2">
                      <div className="col-6">
                        <div className="mb-2">
                          <label className="form-label small mb-1">
                            City
                          </label>
                          <input
                            type="text"
                            className="form-control form-control-sm"
                            name="city"
                            value={form.city}
                            onChange={handleInputChange}
                          />
                        </div>
                      </div>
                      <div className="col-6">
                        <div className="mb-2">
                          <label className="form-label small mb-1">
                            State / region
                          </label>
                          <input
                            type="text"
                            className="form-control form-control-sm"
                            name="region"
                            value={form.region}
                            onChange={handleInputChange}
                          />
                        </div>
                      </div>
                    </div>

                    <div className="row g-2">
                      <div className="col-6">
                        <div className="mb-2">
                          <label className="form-label small mb-1">
                            Postal code
                          </label>
                          <input
                            type="text"
                            className="form-control form-control-sm"
                            name="postcode"
                            value={form.postcode}
                            onChange={handleInputChange}
                          />
                        </div>
                      </div>
                      <div className="col-6">
                        <div className="mb-2">
                          <label className="form-label small mb-1">
                            Country
                          </label>
                          <input
                            type="text"
                            className="form-control form-control-sm"
                            name="country"
                            value={form.country}
                            onChange={handleInputChange}
                            placeholder="US"
                          />
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Notes + image */}
                  <div className="col-md-6">
                    <div className="mb-2">
                      <label className="form-label small mb-1">
                        Notes
                      </label>
                      <textarea
                        className="form-control form-control-sm"
                        rows={3}
                        name="notes"
                        value={form.notes}
                        onChange={handleInputChange}
                      />
                    </div>

                    <div className="mb-2">
                      <label className="form-label small mb-1">
                        Location photo
                      </label>
                      <input
                        type="file"
                        className="form-control form-control-sm"
                        accept="image/*"
                        capture="environment"
                        onChange={handleImageChange}
                      />
                      <div className="form-text small">
                        Optional: take a quick picture (safebox, drawer,
                        etc.).
                      </div>
                    </div>

                    {selectedLocation && (selectedLocation as any).image && (
                      <div className="mt-2">
                        <div className="text-muted small mb-1">
                          Current image
                        </div>
                        <img
                          src={(selectedLocation as any).image}
                          alt={selectedLocation.name}
                          className="img-fluid rounded border"
                          style={{
                            maxHeight: 120,
                            objectFit: "cover",
                          }}
                        />
                      </div>
                    )}
                  </div>

                  {/* Map */}
                  <div className="col-md-6">
                    <div className="mb-2">
                      <label className="form-label small mb-1">
                        Map preview
                      </label>
                      {mapUrl ? (
                        <div className="ratio ratio-16x9 border rounded">
                          <iframe
                            src={mapUrl}
                            loading="lazy"
                            referrerPolicy="no-referrer-when-downgrade"
                            title="Location map"
                          />
                        </div>
                      ) : (
                        <div className="small text-muted border rounded p-2">
                          Add an address (street, city, country) to see a
                          small map preview.
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                <div className="mt-3">
                  <button
                    type="submit"
                    className="btn btn-primary btn-sm"
                    disabled={saving}
                  >
                    {saving ? "Saving…" : "Save location"}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}