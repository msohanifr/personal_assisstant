import {
  type FormEvent,
  type MouseEvent as ReactMouseEvent,
  type CSSProperties,
  useEffect,
  useRef,
  useState,
} from "react";
import { apiGet } from "../api/client";

type SimpleOption = {
  id: number;
  name: string;
};

type LabelVariant = {
  id: number;
  sku: string;
  product_name: string;
  collection_name: string | null;
  metal: string | null;
  gold_purity: string | null;
  size: string | null;
  color: string | null;
  chain_length_cm: string | null;
  barcode: string;
  barcode_image_url: string | null;
  price_raw: string | null;
  currency: string;
  stock_quantity: number;
};

type LabelVariantsResponse = {
  results?: LabelVariant[];
  collections?: SimpleOption[];
  suppliers?: SimpleOption[];
  filters?: {
    q: string;
    collection: string;
    supplier: string;
    only_in_stock: boolean;
  };
  pagination?: {
    limit: number;
    offset: number;
    total: number;
  };
};

type Filters = {
  q: string;
  collectionId: string;
  supplierId: string;
  onlyInStock: boolean;
};

type FieldId =
  | "name"
  | "sku"
  | "size_color"
  | "metal_purity"
  | "price"
  | "stock"
  | "code_text"
  | "qr";

type FieldDef = {
  id: FieldId;
  label: string;
};

type FieldConfig = {
  enabled: boolean;
  x: number; // percent
  y: number; // percent
};

type LabelLayout = {
  sizeKey: string;
  widthMm: number;
  heightMm: number;
  fontPx: number;
  fields: Record<FieldId, FieldConfig>;
};

type PresetsMap = Record<string, LabelLayout>;

type SelectionEntry = {
  include: boolean;
  qty: number;
};

type SelectionMap = Record<number, SelectionEntry>;

type PrintJob = {
  key: string;
  widthMm: number;
  heightMm: number;
  fontPx: number;
  layoutFields: Record<FieldId, FieldConfig>;
  variant: LabelVariant;
};

const FIELD_DEFS: FieldDef[] = [
  { id: "name", label: "Product name" },
  { id: "sku", label: "SKU" },
  { id: "size_color", label: "Size / color" },
  { id: "metal_purity", label: "Metal / purity" },
  { id: "price", label: "Price" },
  { id: "stock", label: "Stock qty" },
  { id: "code_text", label: "Code text" },
  { id: "qr", label: "Barcode image" },
];

const SIZE_PRESETS = [
  {
    key: "barbell-short",
    label: "Short barbell · 60 × 12 mm (rings)",
    widthMm: 60,
    heightMm: 12,
  },
  {
    key: "barbell-long",
    label: "Long barbell · 81 × 12 mm (bracelets/necklaces)",
    widthMm: 81,
    heightMm: 12,
  },
  {
    key: "butterfly-zebra",
    label: 'Butterfly · 55.6 × 12.7 mm (2.2" × 0.5")',
    widthMm: 55.6,
    heightMm: 12.7,
  },
  {
    key: "barbell-us-sheet",
    label: 'Barbell · 69.9 × 12.7 mm (0.5" × 2.75")',
    widthMm: 69.9,
    heightMm: 12.7,
  },
];

const DEFAULT_LAYOUT: LabelLayout = {
  sizeKey: "barbell-short",
  widthMm: 60,
  heightMm: 12,
  fontPx: 9,
  fields: {
    name: { enabled: true, x: 5, y: 12 },
    sku: { enabled: true, x: 5, y: 30 },
    size_color: { enabled: true, x: 5, y: 45 },
    metal_purity: { enabled: true, x: 5, y: 60 },
    price: { enabled: true, x: 5, y: 78 },
    stock: { enabled: false, x: 50, y: 78 },
    code_text: { enabled: true, x: 5, y: 92 },
    qr: { enabled: true, x: 85, y: 22 },
  },
};

const PRESETS_STORAGE_KEY = "label_designer_presets_v2";

function formatMoney(amount: string | null, currency: string | null): string {
  if (!amount) return "";
  const num = Number(amount);
  if (Number.isNaN(num)) return String(amount);
  try {
    return new Intl.NumberFormat(undefined, {
      style: "currency",
      currency: currency || "USD",
      maximumFractionDigits: 0,
    }).format(num);
  } catch {
    return amount;
  }
}

function buildSizeColor(v: LabelVariant): string {
  const parts: string[] = [];
  if (v.size) parts.push(v.size);
  if (v.color) parts.push(v.color);
  if (v.chain_length_cm) parts.push(`${v.chain_length_cm}cm`);
  return parts.join(" ");
}

function buildMetalPurity(v: LabelVariant): string {
  const parts: string[] = [];
  if (v.metal) parts.push(v.metal);
  if (v.gold_purity) parts.push(v.gold_purity);
  return parts.join(" ");
}

function buildFieldText(fieldId: FieldId, v: LabelVariant): string {
  switch (fieldId) {
    case "name":
      return v.product_name;
    case "sku":
      return v.sku;
    case "size_color":
      return buildSizeColor(v);
    case "metal_purity":
      return buildMetalPurity(v);
    case "price":
      return formatMoney(v.price_raw, v.currency);
    case "stock":
      return String(v.stock_quantity);
    case "code_text":
      return v.barcode;
    case "qr":
      return "";
    default:
      return "";
  }
}

export default function LabelsPage() {
  const [filters, setFilters] = useState<Filters>({
    q: "",
    collectionId: "",
    supplierId: "",
    onlyInStock: true,
  });

  const [collections, setCollections] = useState<SimpleOption[]>([]);
  const [suppliers, setSuppliers] = useState<SimpleOption[]>([]);
  const [variants, setVariants] = useState<LabelVariant[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [selection, setSelection] = useState<SelectionMap>({});
  const [activeVariantId, setActiveVariantId] = useState<number | null>(null);

  const [layout, setLayout] = useState<LabelLayout>(DEFAULT_LAYOUT);
  const [presets, setPresets] = useState<PresetsMap>({});
  const [currentPresetName, setCurrentPresetName] = useState("");

  const [presetNameInput, setPresetNameInput] = useState("");

  const [printJobs, setPrintJobs] = useState<PrintJob[]>([]);

  const canvasRef = useRef<HTMLDivElement | null>(null);
  const draggingFieldIdRef = useRef<FieldId | null>(null);
  const dragOffsetRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });

  // Load presets from localStorage
  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(PRESETS_STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw) as PresetsMap;
        setPresets(parsed);
      }
    } catch (e) {
      console.error("Failed to load label presets", e);
    }
  }, []);

  // Save presets on change
  useEffect(() => {
    try {
      window.localStorage.setItem(
        PRESETS_STORAGE_KEY,
        JSON.stringify(presets)
      );
    } catch (e) {
      console.error("Failed to save label presets", e);
    }
  }, [presets]);

  // Fetch initial variants
  useEffect(() => {
    void loadVariants(filters);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function loadVariants(currentFilters: Filters) {
    setLoading(true);
    setError(null);
    try {
      const params = new URLSearchParams();
      if (currentFilters.q.trim()) {
        params.set("q", currentFilters.q.trim());
      }
      if (currentFilters.collectionId) {
        params.set("collection", currentFilters.collectionId);
      }
      if (currentFilters.supplierId) {
        params.set("supplier", currentFilters.supplierId);
      }
      if (currentFilters.onlyInStock) {
        params.set("only_in_stock", "1");
      }
      params.set("limit", "200");

      const data = await apiGet<LabelVariantsResponse>(
        `/api/labels/variants/?${params.toString()}`
      );

      const results = data.results ?? [];

      setVariants(results);
      setCollections(data.collections ?? []);
      setSuppliers(data.suppliers ?? []);

      setSelection((prev) => {
        const next: SelectionMap = {};
        for (const v of results) {
          const existing = prev[v.id];
          next[v.id] = {
            include: existing?.include ?? true,
            qty: existing?.qty ?? 1,
          };
        }
        return next;
      });

      if (results.length > 0) {
        setActiveVariantId((prev) =>
          prev && results.some((v) => v.id === prev) ? prev : results[0].id
        );
      } else {
        setActiveVariantId(null);
      }
    } catch (err: any) {
      console.error(err);
      setError(err.message || "Failed to load variants.");
    } finally {
      setLoading(false);
    }
  }

  function handleFilterSubmit(e: FormEvent) {
    e.preventDefault();
    void loadVariants(filters);
  }

  function handleFilterChange(
    field: keyof Filters,
    value: string | boolean
  ): void {
    setFilters((prev) => ({
      ...prev,
      [field]: value,
    }));
  }

  const activeVariant =
    variants.find((v) => v.id === activeVariantId) || variants[0] || null;

  const totalSelectedVariants = Object.values(selection).filter(
    (s) => s.include && s.qty > 0
  ).length;
  const totalLabels = Object.entries(selection).reduce((sum, [, s]) => {
    if (!s.include || s.qty <= 0) return sum;
    return sum + s.qty;
  }, 0);

  function handleIncludeChange(variantId: number, include: boolean) {
    setSelection((prev) => ({
      ...prev,
      [variantId]: {
        include,
        qty: prev[variantId]?.qty ?? 1,
      },
    }));
  }

  function handleQtyChange(variantId: number, raw: string) {
    let value = parseInt(raw || "1", 10);
    if (Number.isNaN(value) || value < 1) value = 1;
    setSelection((prev) => ({
      ...prev,
      [variantId]: {
        include: prev[variantId]?.include ?? true,
        qty: value,
      },
    }));
  }

  function handleSelectAll() {
    setSelection((prev) => {
      const next: SelectionMap = { ...prev };
      for (const v of variants) {
        const existing = prev[v.id];
        next[v.id] = {
          include: true,
          qty: existing?.qty ?? 1,
        };
      }
      return next;
    });
  }

  function handleClearSelection() {
    setSelection((prev) => {
      const next: SelectionMap = { ...prev };
      for (const v of variants) {
        const existing = prev[v.id];
        next[v.id] = {
          include: false,
          qty: existing?.qty ?? 1,
        };
      }
      return next;
    });
  }

  function handleSizeChange(key: string) {
    const preset = SIZE_PRESETS.find((s) => s.key === key);
    if (!preset) return;

    setLayout((prev) => ({
      ...prev,
      sizeKey: preset.key,
      widthMm: preset.widthMm,
      heightMm: preset.heightMm,
    }));
  }

  function handleFontChange(value: string) {
    const fontPx = parseInt(value || "9", 10);
    setLayout((prev) => ({
      ...prev,
      fontPx,
    }));
  }

  function handleFieldToggle(fieldId: FieldId, enabled: boolean) {
    setLayout((prev) => ({
      ...prev,
      fields: {
        ...prev.fields,
        [fieldId]: {
          ...prev.fields[fieldId],
          enabled,
        },
      },
    }));
  }

  // Presets
  function handleSavePreset() {
    const name = presetNameInput.trim();
    if (!name) {
      alert("Enter a preset name first.");
      return;
    }
    setPresets((prev) => ({
      ...prev,
      [name]: JSON.parse(JSON.stringify(layout)),
    }));
    setCurrentPresetName(name);
  }

  function handleLoadPreset() {
    if (!currentPresetName || !presets[currentPresetName]) {
      alert("Select a preset to load.");
      return;
    }
    const preset = presets[currentPresetName];
    setLayout(JSON.parse(JSON.stringify(preset)));
  }

  function handleDeletePreset() {
    if (!currentPresetName || !presets[currentPresetName]) {
      alert("Select a preset to delete.");
      return;
    }
    const confirmDelete = window.confirm(
      `Delete preset "${currentPresetName}"?`
    );
    if (!confirmDelete) return;
    setPresets((prev) => {
      const copy = { ...prev };
      delete copy[currentPresetName];
      return copy;
    });
    setCurrentPresetName("");
  }

  // Canvas dragging
  function handleFieldMouseDown(
    e: ReactMouseEvent<HTMLDivElement>,
    fieldId: FieldId
  ) {
    e.preventDefault();
    e.stopPropagation();
    if (!canvasRef.current) return;

    draggingFieldIdRef.current = fieldId;

    const canvasRect = canvasRef.current.getBoundingClientRect();
    const fieldRect = (e.currentTarget as HTMLDivElement).getBoundingClientRect();

    dragOffsetRef.current = {
      x: e.clientX - fieldRect.left,
      y: e.clientY - fieldRect.top,
    };

    window.addEventListener("mousemove", handleWindowMouseMove);
    window.addEventListener("mouseup", handleWindowMouseUp);
  }

  function handleWindowMouseMove(e: MouseEvent) {
    const canvas = canvasRef.current;
    const fieldId = draggingFieldIdRef.current;
    if (!canvas || !fieldId) return;

    const canvasRect = canvas.getBoundingClientRect();
    let leftPx = e.clientX - canvasRect.left - dragOffsetRef.current.x;
    let topPx = e.clientY - canvasRect.top - dragOffsetRef.current.y;

    const fieldEl = canvas.querySelector(
      `.draggable-field[data-field-id="${fieldId}"]`
    ) as HTMLDivElement | null;
    const fieldRect = fieldEl?.getBoundingClientRect();

    const maxLeft = canvasRect.width - (fieldRect?.width || 0);
    const maxTop = canvasRect.height - (fieldRect?.height || 0);

    if (leftPx < 0) leftPx = 0;
    if (topPx < 0) topPx = 0;
    if (leftPx > maxLeft) leftPx = maxLeft;
    if (topPx > maxTop) topPx = maxTop;

    const xPerc = (leftPx / canvasRect.width) * 100;
    const yPerc = (topPx / canvasRect.height) * 100;

    setLayout((prev) => ({
      ...prev,
      fields: {
        ...prev.fields,
        [fieldId]: {
          ...prev.fields[fieldId],
          x: xPerc,
          y: yPerc,
        },
      },
    }));
  }

  function handleWindowMouseUp() {
    draggingFieldIdRef.current = null;
    window.removeEventListener("mousemove", handleWindowMouseMove);
    window.removeEventListener("mouseup", handleWindowMouseUp);
  }

  useEffect(() => {
    return () => {
      window.removeEventListener("mousemove", handleWindowMouseMove);
      window.removeEventListener("mouseup", handleWindowMouseUp);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Printing
  function handlePrint() {
    const jobs: PrintJob[] = [];
    const layoutSnapshot: LabelLayout = JSON.parse(JSON.stringify(layout));

    const sizePreset =
      SIZE_PRESETS.find((s) => s.key === layout.sizeKey) || SIZE_PRESETS[0];

    for (const v of variants) {
      const sel = selection[v.id];
      if (!sel || !sel.include || sel.qty <= 0) continue;
      for (let i = 0; i < sel.qty; i++) {
        jobs.push({
          key: `${v.id}-${i}-${Date.now()}`,
          widthMm: sizePreset.widthMm,
          heightMm: sizePreset.heightMm,
          fontPx: layoutSnapshot.fontPx,
          layoutFields: layoutSnapshot.fields,
          variant: v,
        });
      }
    }

    if (!jobs.length) {
      alert("Select at least one variant to print.");
      return;
    }

    setPrintJobs(jobs);
  }

  // Trigger window.print() when printJobs populated
  useEffect(() => {
    if (!printJobs.length) return;

    const afterPrint = () => {
      setPrintJobs([]);
      window.removeEventListener("afterprint", afterPrint);
    };

    window.addEventListener("afterprint", afterPrint);
    window.print();

    const timer = window.setTimeout(afterPrint, 2000);

    return () => {
      window.removeEventListener("afterprint", afterPrint);
      window.clearTimeout(timer);
    };
  }, [printJobs]);

  if (error) {
    return (
      <div className="container py-4">
        <div className="alert alert-danger mt-3" role="alert">
          {error}
        </div>
      </div>
    );
  }

  return (
    <div className="container-fluid label-page">
      {/* Header */}
      <div className="d-flex flex-column flex-lg-row justify-content-between align-items-lg-center mb-3 no-print">
        <div className="mb-2 mb-lg-0">
          <h1 className="h4 mb-1">
            <i className="fa-solid fa-tags me-2" />
            Print Jewelry Labels
          </h1>
          <p className="text-muted small mb-0">
            Filter variants, design your label layout by dragging fields, save
            presets, and print barbell-style jewelry labels.
          </p>
        </div>
        <div className="d-flex flex-column text-end small text-muted">
          <span>
            Selected variants: <strong>{totalSelectedVariants}</strong>
          </span>
          <span>
            Total labels: <strong>{totalLabels}</strong>
          </span>
        </div>
      </div>

      <div className="row g-3 no-print">
        {/* Left: filters + variants */}
        <div className="col-lg-7 col-xl-8">
          <div className="label-filters">
            <form
              className="row gy-2 gx-2 align-items-end"
              onSubmit={handleFilterSubmit}
            >
              <div className="col-md-4">
                <label className="form-label mb-1 small text-uppercase text-muted">
                  Search
                </label>
                <input
                  type="text"
                  className="form-control form-control-sm"
                  placeholder="SKU, product, collection"
                  value={filters.q}
                  onChange={(e) =>
                    handleFilterChange("q", e.target.value)
                  }
                />
              </div>

              <div className="col-md-3">
                <label className="form-label mb-1 small text-uppercase text-muted">
                  Collection
                </label>
                <select
                  className="form-select form-select-sm"
                  value={filters.collectionId}
                  onChange={(e) =>
                    handleFilterChange("collectionId", e.target.value)
                  }
                >
                  <option value="">All collections</option>
                  {collections.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </div>

              <div className="col-md-3">
                <label className="form-label mb-1 small text-uppercase text-muted">
                  Supplier
                </label>
                <select
                  className="form-select form-select-sm"
                  value={filters.supplierId}
                  onChange={(e) =>
                    handleFilterChange("supplierId", e.target.value)
                  }
                >
                  <option value="">All suppliers</option>
                  {suppliers.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.name}
                    </option>
                  ))}
                </select>
              </div>

              <div className="col-md-2 d-flex align-items-center">
                <div className="form-check">
                  <input
                    id="only-in-stock"
                    type="checkbox"
                    className="form-check-input"
                    checked={filters.onlyInStock}
                    onChange={(e) =>
                      handleFilterChange("onlyInStock", e.target.checked)
                    }
                  />
                  <label
                    htmlFor="only-in-stock"
                    className="form-check-label small"
                  >
                    Only in stock
                  </label>
                </div>
              </div>

              <div className="col-md-12 text-end mt-2">
                <button
                  type="submit"
                  className="btn btn-sm btn-primary me-2"
                  disabled={loading}
                >
                  {loading ? "Loading…" : "Apply filters"}
                </button>
                <button
                  type="button"
                  className="btn btn-sm btn-outline-secondary"
                  onClick={() => {
                    setFilters({
                      q: "",
                      collectionId: "",
                      supplierId: "",
                      onlyInStock: true,
                    });
                    void loadVariants({
                      q: "",
                      collectionId: "",
                      supplierId: "",
                      onlyInStock: true,
                    });
                  }}
                  disabled={loading}
                >
                  Reset
                </button>
              </div>
            </form>
          </div>

          {error && (
            <div className="alert alert-danger py-2">{error}</div>
          )}

          {!loading && variants.length === 0 && !error && (
            <div className="label-empty">
              No variants found. Adjust your filters or create more
              products.
            </div>
          )}

          {loading && (
            <p className="text-muted small mb-2">Loading variants…</p>
          )}

          <div className="d-flex justify-content-between align-items-center mt-3 mb-3">
            <h2 className="h6 mb-0">Variants</h2>
            {variants.length > 0 && (
              <div className="d-flex flex-wrap gap-2">
                <button
                  type="button"
                  className="btn btn-outline-secondary btn-sm"
                  onClick={handleSelectAll}
                >
                  <i className="fa-regular fa-square-check me-1" />
                  Select all
                </button>
                <button
                  type="button"
                  className="btn btn-outline-secondary btn-sm"
                  onClick={handleClearSelection}
                >
                  <i className="fa-regular fa-square me-1" />
                  Clear
                </button>
                <button
                  type="button"
                  className="btn btn-primary btn-sm"
                  onClick={handlePrint}
                >
                  <i className="fa-solid fa-print me-1" />
                  Print labels
                </button>
              </div>
            )}
          </div>

          <div className="card shadow-sm border-0">
            <div className="card-body">
              <div className="row row-cols-1 row-cols-sm-2 row-cols-lg-3 row-cols-xl-4 g-3">
                {variants.map((v) => {
                  const sel = selection[v.id] || { include: true, qty: 1 };
                  const isActive = v.id === activeVariantId;

                  return (
                    <div key={v.id} className="col">
                      <div
                        className={
                          "label-card h-100" + (isActive ? " active" : "")
                        }
                        onClick={() => setActiveVariantId(v.id)}
                      >
                        <div className="label-card-header">
                          <div>
                            <div className="label-product-name">
                              {v.product_name}
                            </div>
                            <div className="label-collection">
                              {v.collection_name && (
                                <>
                                  {v.collection_name} ·{" "}
                                </>
                              )}
                              {buildMetalPurity(v) || "—"}
                            </div>
                          </div>
                          <div className="text-end">
                            <span className="badge bg-light text-muted border">
                              {v.sku}
                            </span>
                          </div>
                        </div>

                        <div className="label-meta">
                          {buildSizeColor(v) && (
                            <span>{buildSizeColor(v)}</span>
                          )}
                          {v.barcode && (
                            <span>
                              <i className="fa-solid fa-barcode me-1" />
                              {v.barcode}
                            </span>
                          )}
                          {v.stock_quantity <= 0 ? (
                            <span className="text-danger">Out of stock</span>
                          ) : (
                            <span>Stock {v.stock_quantity}</span>
                          )}
                        </div>

                        <div className="label-footer">
                          <div
                            className="form-check form-check-sm"
                            onClick={(ev) => ev.stopPropagation()}
                          >
                            <input
                              type="checkbox"
                              className="form-check-input label-include"
                              id={`include-${v.id}`}
                              checked={sel.include}
                              onChange={(e) =>
                                handleIncludeChange(v.id, e.target.checked)
                              }
                            />
                            <label
                              htmlFor={`include-${v.id}`}
                              className="form-check-label small"
                            >
                              Include
                            </label>
                          </div>
                          <div
                            className="d-flex align-items-center gap-2"
                            onClick={(ev) => ev.stopPropagation()}
                          >
                            <label
                              htmlFor={`qty-${v.id}`}
                              className="small mb-0"
                            >
                              Qty
                            </label>
                            <input
                              id={`qty-${v.id}`}
                              type="number"
                              min={1}
                              className="form-control form-control-sm label-qty"
                              value={sel.qty}
                              onChange={(e) =>
                                handleQtyChange(v.id, e.target.value)
                              }
                              style={{ maxWidth: 70 }}
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>

        {/* Right: designer */}
        <div className="col-lg-5 col-xl-4">
          <div className="card designer-card no-print">
            <div className="card-body">
              <h6 className="card-title fw-semibold mb-2">
                Label designer
              </h6>
              <p className="designer-help mb-3">
                Pick a label size, toggle fields, and drag each field in
                the preview to position it. Saved presets are stored in
                your browser.
              </p>

              {/* Size & basic */}
              <fieldset className="designer-fieldset">
                <legend>Size &amp; basic</legend>
                <div className="row g-2">
                  <div className="col-12">
                    <label
                      htmlFor="label-size"
                      className="designer-label mb-1"
                    >
                      Label size
                    </label>
                    <select
                      id="label-size"
                      className="form-select form-select-sm"
                      value={layout.sizeKey}
                      onChange={(e) =>
                        handleSizeChange(e.target.value)
                      }
                    >
                      {SIZE_PRESETS.map((s) => (
                        <option key={s.key} value={s.key}>
                          {s.label}
                        </option>
                      ))}
                    </select>
                    <div className="designer-help mt-1">
                      Match this to the physical label stock in your
                      printer.
                    </div>
                  </div>
                  <div className="col-6">
                    <label
                      htmlFor="label-font-size"
                      className="designer-label mb-1"
                    >
                      Font size
                    </label>
                    <input
                      id="label-font-size"
                      type="range"
                      className="form-range"
                      min={7}
                      max={12}
                      value={layout.fontPx}
                      onChange={(e) =>
                        handleFontChange(e.target.value)
                      }
                    />
                    <div className="d-flex justify-content-between designer-help">
                      <span>Small</span>
                      <span>Large</span>
                    </div>
                  </div>
                </div>
              </fieldset>

              {/* Field visibility */}
              <fieldset className="designer-fieldset">
                <legend>Field visibility</legend>
                <div className="row g-2">
                  {FIELD_DEFS.map((fd) => (
                    <div className="col-6" key={fd.id}>
                      <div className="form-check form-check-sm">
                        <input
                          id={`field-${fd.id}`}
                          className="form-check-input field-toggle"
                          type="checkbox"
                          checked={layout.fields[fd.id].enabled}
                          onChange={(e) =>
                            handleFieldToggle(fd.id, e.target.checked)
                          }
                        />
                        <label
                          className="form-check-label small"
                          htmlFor={`field-${fd.id}`}
                        >
                          {fd.label}
                        </label>
                      </div>
                    </div>
                  ))}
                </div>
              </fieldset>

              {/* Presets */}
              <fieldset className="designer-fieldset">
                <legend>Presets</legend>
                <div className="row g-2 preset-controls">
                  <div className="col-7">
                    <label
                      className="designer-label mb-1"
                      htmlFor="preset-select"
                    >
                      Saved presets
                    </label>
                    <select
                      id="preset-select"
                      className="form-select form-select-sm"
                      value={currentPresetName}
                      onChange={(e) =>
                        setCurrentPresetName(e.target.value)
                      }
                    >
                      <option value="">
                        — No preset selected —
                      </option>
                      {Object.keys(presets).map((name) => (
                        <option key={name} value={name}>
                          {name}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div className="col-5">
                    <label
                      className="designer-label mb-1"
                      htmlFor="preset-name"
                    >
                      Preset name
                    </label>
                    <input
                      id="preset-name"
                      type="text"
                      className="form-control form-control-sm preset-name-input"
                      placeholder='e.g. "Rings small"'
                      value={presetNameInput}
                      onChange={(e) =>
                        setPresetNameInput(e.target.value)
                      }
                    />
                  </div>
                  <div className="col-12 d-flex flex-wrap gap-2 mt-1">
                    <button
                      type="button"
                      className="btn btn-outline-primary btn-sm"
                      onClick={handleSavePreset}
                    >
                      Save as new / update
                    </button>
                    <button
                      type="button"
                      className="btn btn-outline-secondary btn-sm"
                      onClick={handleLoadPreset}
                    >
                      Load preset
                    </button>
                    <button
                      type="button"
                      className="btn btn-outline-danger btn-sm"
                      onClick={handleDeletePreset}
                    >
                      Delete preset
                    </button>
                  </div>
                  <div className="col-12">
                    <p className="designer-help mb-0 mt-1">
                      Presets are stored in this browser only. You can
                      have different layouts for rings, necklaces, etc.
                    </p>
                  </div>
                </div>
              </fieldset>

              {/* Preview canvas */}
              <div className="mb-2">
                <label className="designer-label mb-1">
                  Live preview
                </label>
                <div className="label-canvas-wrapper">
                  <div className="label-canvas" ref={canvasRef}>
                    <div
                      className="label-canvas-inner"
                      style={{ fontSize: layout.fontPx }}
                    >
                      {!activeVariant && (
                        <div className="label-preview-muted">
                          Select a variant on the left to preview
                        </div>
                      )}
                      {activeVariant &&
                        FIELD_DEFS.map((fd) => {
                          const cfg = layout.fields[fd.id];
                          if (!cfg?.enabled) return null;

                          const text = buildFieldText(
                            fd.id,
                            activeVariant
                          );
                          if (!text && fd.id !== "qr") return null;

                          const style = {
                            left: `${cfg.x}%`,
                            top: `${cfg.y}%`,
                          };

                          const className =
                            "draggable-field" +
                            (fd.id === "qr"
                              ? " draggable-field-qr"
                              : "");

                          if (fd.id === "qr") {
                            return (
                              <div
                                key={fd.id}
                                className={className}
                                style={style}
                                data-field-id={fd.id}
                                onMouseDown={(e) =>
                                  handleFieldMouseDown(e, fd.id)
                                }
                              >
                                {activeVariant.barcode_image_url ? (
                                  <img
                                    src={
                                      activeVariant.barcode_image_url
                                    }
                                    alt="Code"
                                    style={{
                                      maxHeight: "100%",
                                      maxWidth: "100%",
                                    }}
                                  />
                                ) : (
                                  "Code"
                                )}
                              </div>
                            );
                          }

                          return (
                            <div
                              key={fd.id}
                              className={className}
                              style={style}
                              data-field-id={fd.id}
                              onMouseDown={(e) =>
                                handleFieldMouseDown(e, fd.id)
                              }
                            >
                              {text}
                            </div>
                          );
                        })}
                    </div>
                  </div>
                </div>
                <p className="designer-help mt-2 mb-0">
                  Drag each field to its desired position. The print
                  output will match this layout and label size.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Hidden print sheet (visible only during print) */}
      <div id="print-sheet">
        {printJobs.map((job) => {
          const styleVars: CSSProperties = {
            ["--label-width-mm" as any]: `${job.widthMm}mm`,
            ["--label-height-mm" as any]: `${job.heightMm}mm`,
          };
          const innerStyle: CSSProperties = {
            ["--label-font-px" as any]: `${job.fontPx}px`,
          };

          return (
            <div
              key={job.key}
              className="print-label"
              style={styleVars}
            >
              <div className="print-label-inner" style={innerStyle}>
                {FIELD_DEFS.map((fd) => {
                  const cfg = job.layoutFields[fd.id];
                  if (!cfg?.enabled) return null;

                  const text = buildFieldText(fd.id, job.variant);
                  if (!text && fd.id !== "qr") return null;

                  const style = {
                    left: `${cfg.x}%`,
                    top: `${cfg.y}%`,
                  };

                  const className =
                    "print-field" +
                    (fd.id === "qr" ? " print-field-qr" : "");

                  if (fd.id === "qr") {
                    if (!job.variant.barcode_image_url) return null;
                    return (
                      <div
                        key={fd.id}
                        className={className}
                        style={style}
                      >
                        <img
                          src={job.variant.barcode_image_url}
                          alt="Code"
                          style={{
                            maxHeight: "100%",
                            maxWidth: "100%",
                          }}
                        />
                      </div>
                    );
                  }

                  return (
                    <div
                      key={fd.id}
                      className={className}
                      style={style}
                    >
                      {text}
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}