import { FormEvent, useEffect, useRef, useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { apiPost } from "../api/client";

type LoginResponse = {
  username: string;
  is_staff: boolean;
  is_superuser: boolean;
  // backend also returns email, is_accounting, etc.,
  // but we don't need them here to navigate.
};

const GOOGLE_CLIENT_ID = import.meta.env
  .VITE_GOOGLE_CLIENT_ID as string | undefined;

declare global {
  interface Window {
    google?: any;
  }
}

export default function LoginPage() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const navigate = useNavigate();
  const location = useLocation() as any;
  const from = location.state?.from || "/";

  const googleButtonRef = useRef<HTMLDivElement | null>(null);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);

    if (!username || !password) {
      setError("Please enter username and password.");
      return;
    }

    setSubmitting(true);
    try {
      const data = await apiPost<LoginResponse>("/api/auth/login/", {
        username,
        password,
      });
      // success → redirect to previous page or dashboard
      console.log("Logged in as", data);
      navigate(from, { replace: true });
    } catch (err: any) {
      setError(err.message || "Login failed.");
    } finally {
      setSubmitting(false);
    }
  }

  // Google login handler (called by GIS after user selects account)
  async function handleGoogleCredentialResponse(response: any) {
    try {
      const idToken = response?.credential;
      if (!idToken) {
        return;
      }

      setError(null);
      setSubmitting(true);

      const data = await apiPost<any>("/api/auth/google/", {
        id_token: idToken,
      });

      console.log("Google login success", data);
      // Session cookie is set; RequireAuth will see the session via /api/auth/me/
      navigate(from, { replace: true });
    } catch (err: any) {
      console.error("Google login error:", err);
      // apiPost throws Error(message) with backend .detail when available
      setError(err.message || "Google login failed.");
    } finally {
      setSubmitting(false);
    }
  }

  // Initialize Google Identity button
  useEffect(() => {
    if (!GOOGLE_CLIENT_ID) {
      console.warn("VITE_GOOGLE_CLIENT_ID is not set.");
      return;
    }
    if (!window.google) {
      console.warn("Google Identity script not loaded yet.");
      return;
    }

    window.google.accounts.id.initialize({
      client_id: GOOGLE_CLIENT_ID,
      callback: handleGoogleCredentialResponse,
      // you can tweak these:
      // auto_select: false,
      // cancel_on_tap_outside: true,
    });

    if (googleButtonRef.current) {
      window.google.accounts.id.renderButton(googleButtonRef.current, {
        type: "standard",
        theme: "outline",
        size: "large",
        text: "continue_with",
        shape: "pill",
      });
    }

    // Optional: One-tap prompt:
    // window.google.accounts.id.prompt();

    // no cleanup needed for simple button render
  }, []);

  return (
    <div className="container py-5">
      <div className="row justify-content-center">
        <div className="col-md-4">
          <h1 className="h4 mb-3 text-center">Sign in</h1>

          {error && (
            <div className="alert alert-danger py-2" role="alert">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit}>
            <div className="mb-3">
              <label className="form-label">Username</label>
              <input
                className="form-control"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                autoComplete="username"
              />
            </div>

            <div className="mb-3">
              <label className="form-label">Password</label>
              <input
                type="password"
                className="form-control"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                autoComplete="current-password"
              />
            </div>

            <button
              type="submit"
              className="btn btn-dark w-100"
              disabled={submitting}
            >
              {submitting ? "Signing in..." : "Sign in"}
            </button>
          </form>

          {/* Divider */}
          <div className="d-flex align-items-center my-3">
            <div className="flex-grow-1 border-top" />
            <span className="mx-2 text-muted small">or</span>
            <div className="flex-grow-1 border-top" />
          </div>

          {/* Google sign-in button */}
          <div className="d-flex justify-content-center mb-2">
            <div ref={googleButtonRef} />
          </div>

          {GOOGLE_CLIENT_ID ? null : (
            <p className="text-muted small mt-2">
              Google login is not configured. Set{" "}
              <code>VITE_GOOGLE_CLIENT_ID</code> in your frontend env.
            </p>
          )}
        </div>
      </div>
    </div>
  );
}