import { ChangeEvent, FormEvent, useEffect, useRef, useState } from "react";
import { apiGet, apiPost, apiPatch, apiPostForm } from "../api/client";
import { Chart, registerables } from "chart.js";

Chart.register(...registerables);

type CategorySummary = {
  category: string;
  total: string; // decimal as string
};

type LatestExpenseRow = {
  id: number;
  date: string;
  description: string;
  type: string;
  type_display: string;
  category_name: string | null;
  vendor: string;
  total_amount: string;
  currency: string;
  receipt_count: number;
};

type Category = {
  id: number;
  name: string;
  code: string;
};

type ExpenseSummary = {
  start_date: string;
  end_date: string;
  today: string;
  total_spent: string;
  total_inventory: string;
  total_operating: string;
  by_category: CategorySummary[];
  latest_expenses: LatestExpenseRow[];
  categories: Category[];
};

type NewExpenseForm = {
  date: string;
  type: string;
  category_id: string;
  description: string;
  vendor: string;
  total_amount: string;
  currency: string;
};

const EMPTY_FORM: NewExpenseForm = {
  date: "",
  type: "inventory",
  category_id: "",
  description: "",
  vendor: "",
  total_amount: "",
  currency: "USD",
};

export default function ExpensesPage() {
  const [data, setData] = useState<ExpenseSummary | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const [startDate, setStartDate] = useState<string>("");
  const [endDate, setEndDate] = useState<string>("");

  // add-expense panel state
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState<NewExpenseForm>(EMPTY_FORM);
  const [formError, setFormError] = useState<string | null>(null);
  const [formSubmitting, setFormSubmitting] = useState(false);

  // inline edit state
  const [editingId, setEditingId] = useState<number | null>(null);
  const [editForm, setEditForm] = useState<NewExpenseForm | null>(null);
  const [editError, setEditError] = useState<string | null>(null);
  const [editSubmitting, setEditSubmitting] = useState(false);

  // receipt upload state
  const [uploadingId, setUploadingId] = useState<number | null>(null);

  const categoryChartRef = useRef<HTMLCanvasElement | null>(null);
  const categoryChartInstanceRef = useRef<Chart | null>(null);

  async function loadExpenses(opts?: { start?: string; end?: string }) {
    setLoading(true);
    setError(null);

    try {
      let url = "/api/expenses/summary/";
      const params: string[] = [];

      const s = opts?.start ?? startDate;
      const e = opts?.end ?? endDate;

      if (s) params.push(`start_date=${encodeURIComponent(s)}`);
      if (e) params.push(`end_date=${encodeURIComponent(e)}`);

      if (params.length) {
        url += "?" + params.join("&");
      }

      const res = await apiGet<ExpenseSummary>(url);
      setData(res);

      if (!startDate) setStartDate(res.start_date);
      if (!endDate) setEndDate(res.end_date);

      if (!form.date) {
        setForm((prev) => ({
          ...prev,
          date: res.today || res.end_date || prev.date,
        }));
      }
    } catch (err: any) {
      console.error(err);
      setError(err.message || "Failed to load expenses.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadExpenses();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Build / update category chart
  useEffect(() => {
    if (!data || !categoryChartRef.current) return;

    const ctx = categoryChartRef.current.getContext("2d");
    if (!ctx) return;

    if (categoryChartInstanceRef.current) {
      categoryChartInstanceRef.current.destroy();
    }

    const labels = data.by_category.map((row) => row.category);
    const values = data.by_category.map((row) => parseFloat(row.total || "0"));

    const chartData = {
      labels,
      datasets: [
        {
          label: "Total spent",
          data: values,
        },
      ],
    };

    const options = {
      responsive: true,
      maintainAspectRatio: false,
      indexAxis: "y" as const, // horizontal bars
      scales: {
        x: {
          beginAtZero: true,
          ticks: { precision: 0 },
        },
      },
      plugins: {
        legend: {
          display: false,
        },
      },
    };

    categoryChartInstanceRef.current = new Chart(ctx, {
      type: "bar",
      data: chartData,
      options,
    });

    return () => {
      if (categoryChartInstanceRef.current) {
        categoryChartInstanceRef.current.destroy();
      }
    };
  }, [data]);

  function handleFilterSubmit(e: FormEvent) {
    e.preventDefault();
    loadExpenses({ start: startDate, end: endDate });
  }

  function handleFormChange<K extends keyof NewExpenseForm>(
    key: K,
    value: NewExpenseForm[K]
  ) {
    setForm((prev) => ({ ...prev, [key]: value }));
  }

  async function handleFormSubmit(e: FormEvent) {
    e.preventDefault();
    setFormError(null);

    if (!form.date || !form.total_amount || !form.type) {
      setFormError("Date, type and total amount are required.");
      return;
    }

    setFormSubmitting(true);
    try {
      await apiPost("/api/expenses/create/", {
        date: form.date,
        type: form.type,
        category_id: form.category_id || null,
        description: form.description,
        vendor: form.vendor,
        total_amount: form.total_amount,
        currency: form.currency,
      });

      await loadExpenses({ start: startDate, end: endDate });

      setForm(EMPTY_FORM);
      if (data) {
        setForm((prev) => ({
          ...prev,
          date: data.today || data.end_date || prev.date,
          currency: prev.currency || "USD",
        }));
      }
      setShowForm(false);
    } catch (err: any) {
      console.error(err);
      setFormError(err.message || "Failed to save expense.");
    } finally {
      setFormSubmitting(false);
    }
  }

  function startEdit(row: LatestExpenseRow) {
    if (!data) return;
    setEditingId(row.id);
    setEditError(null);

    const matchedCategory = data.categories.find(
      (c) => c.name === row.category_name
    );

    setEditForm({
      date: row.date,
      type: row.type || "inventory",
      category_id: matchedCategory ? String(matchedCategory.id) : "",
      description: row.description,
      vendor: row.vendor,
      total_amount: row.total_amount,
      currency: row.currency || "USD",
    });
  }

  function cancelEdit() {
    setEditingId(null);
    setEditForm(null);
    setEditError(null);
  }

  function handleEditChange<K extends keyof NewExpenseForm>(
    key: K,
    value: NewExpenseForm[K]
  ) {
    if (!editForm) return;
    setEditForm((prev) => (prev ? { ...prev, [key]: value } : prev));
  }

  async function handleEditSave() {
    if (!editForm || editingId == null) return;
    setEditError(null);
    setEditSubmitting(true);

    try {
      await apiPatch(`/api/expenses/${editingId}/`, {
        date: editForm.date,
        type: editForm.type,
        category_id: editForm.category_id || null,
        description: editForm.description,
        vendor: editForm.vendor,
        total_amount: editForm.total_amount,
        currency: editForm.currency,
      });

      await loadExpenses({ start: startDate, end: endDate });
      cancelEdit();
    } catch (err: any) {
      console.error(err);
      setEditError(err.message || "Failed to update expense.");
    } finally {
      setEditSubmitting(false);
    }
  }

  async function handleReceiptChange(
    expenseId: number,
    event: ChangeEvent<HTMLInputElement>
  ) {
    const file = event.target.files?.[0];
    if (!file) return;

    setUploadingId(expenseId);
    try {
      const formData = new FormData();
      formData.append("image", file);
      await apiPostForm(`/api/expenses/${expenseId}/upload_receipt/`, formData);
      await loadExpenses({ start: startDate, end: endDate });
    } catch (err: any) {
      console.error(err);
      setError(err.message || "Failed to upload receipt.");
    } finally {
      setUploadingId(null);
      event.target.value = "";
    }
  }

  function handleExportCsv() {
    const params = new URLSearchParams();
    if (startDate) params.append("start_date", startDate);
    if (endDate) params.append("end_date", endDate);
    const url = `/api/expenses/export/?${params.toString()}`;
    window.open(url, "_blank");
  }

  function formatCurrency(amount: string, currency: string) {
    if (!amount) return "—";
    return `${amount} ${currency}`;
  }

  if (error) {
    return (
      <div className="alert alert-danger mt-3" role="alert">
        {error}
      </div>
    );
  }

  if (!data) {
    return <div className="p-3">Loading expenses…</div>;
  }

  return (
    <div>
      {/* Header */}
      <div className="d-flex justify-content-between align-items-center mb-3">
        <div>
          <h1 className="h4 mb-1">Expense Dashboard</h1>
          <p className="text-muted small mb-0">
            Record purchases, attach receipts, and track totals for any date range.
          </p>
        </div>

        <div className="d-flex align-items-center gap-3">
          {/* Date range filter */}
          <form
            className="d-flex align-items-center gap-2"
            onSubmit={handleFilterSubmit}
          >
            <div className="d-flex flex-column">
              <label className="form-label small mb-1">From</label>
              <input
                type="date"
                className="form-control form-control-sm"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
              />
            </div>
            <div className="d-flex flex-column">
              <label className="form-label small mb-1">To</label>
              <input
                type="date"
                className="form-control form-control-sm"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
              />
            </div>
            <div className="d-flex align-items-end">
              <button
                type="submit"
                className="btn btn-outline-secondary btn-sm"
                disabled={loading}
              >
                {loading ? "Updating…" : "Apply"}
              </button>
            </div>
          </form>

          {/* Export */}
          <button
            type="button"
            className="btn btn-outline-secondary btn-sm"
            onClick={handleExportCsv}
          >
            <i className="fa-solid fa-file-csv me-1" />
            Export CSV
          </button>

          {/* Add expense button */}
          <button
            type="button"
            className="btn btn-dark btn-sm"
            onClick={() => {
              setShowForm((prev) => !prev);
              setFormError(null);
              if (!form.date) {
                setForm((prev) => ({
                  ...prev,
                  date: data.today || data.end_date || prev.date,
                }));
              }
            }}
          >
            <i className="fa-solid fa-plus me-1" />
            Add expense
          </button>
        </div>
      </div>

      {/* Inline Add Expense panel */}
      {showForm && (
        <div className="card shadow-sm border-0 mb-4">
          <div className="card-body">
            <div className="d-flex justify-content-between align-items-center mb-3">
              <h5 className="card-title mb-0">New expense</h5>
              <button
                type="button"
                className="btn btn-sm btn-outline-secondary"
                onClick={() => setShowForm(false)}
              >
                Close
              </button>
            </div>

            {formError && (
              <div className="alert alert-danger py-2" role="alert">
                {formError}
              </div>
            )}

            <form onSubmit={handleFormSubmit}>
              <div className="row g-3">
                <div className="col-md-3">
                  <label className="form-label small">Date</label>
                  <input
                    type="date"
                    className="form-control form-control-sm"
                    value={form.date}
                    onChange={(e) => handleFormChange("date", e.target.value)}
                  />
                </div>

                <div className="col-md-3">
                  <label className="form-label small">Type</label>
                  <select
                    className="form-select form-select-sm"
                    value={form.type}
                    onChange={(e) => handleFormChange("type", e.target.value)}
                  >
                    <option value="inventory">Inventory purchase</option>
                    <option value="operating">Operating expense</option>
                  </select>
                </div>

                <div className="col-md-3">
                  <label className="form-label small">Category</label>
                  <select
                    className="form-select form-select-sm"
                    value={form.category_id}
                    onChange={(e) =>
                      handleFormChange("category_id", e.target.value)
                    }
                  >
                    <option value="">(none)</option>
                    {data.categories.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="col-md-3">
                  <label className="form-label small">Vendor</label>
                  <input
                    type="text"
                    className="form-control form-control-sm"
                    value={form.vendor}
                    onChange={(e) =>
                      handleFormChange("vendor", e.target.value)
                    }
                    placeholder="Optional"
                  />
                </div>

                <div className="col-md-6">
                  <label className="form-label small">Description</label>
                  <input
                    type="text"
                    className="form-control form-control-sm"
                    value={form.description}
                    onChange={(e) =>
                      handleFormChange("description", e.target.value)
                    }
                    placeholder="What did you purchase?"
                  />
                </div>

                <div className="col-md-3">
                  <label className="form-label small">Total amount</label>
                  <input
                    type="number"
                    step="0.01"
                    className="form-control form-control-sm"
                    value={form.total_amount}
                    onChange={(e) =>
                      handleFormChange("total_amount", e.target.value)
                    }
                  />
                </div>

                <div className="col-md-3">
                  <label className="form-label small">Currency</label>
                  <input
                    type="text"
                    className="form-control form-control-sm"
                    value={form.currency}
                    onChange={(e) =>
                      handleFormChange("currency", e.target.value)
                    }
                  />
                </div>
              </div>

              <div className="mt-3 d-flex justify-content-end">
                <button
                  type="submit"
                  className="btn btn-dark btn-sm"
                  disabled={formSubmitting}
                >
                  {formSubmitting ? "Saving…" : "Save expense"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* KPI CARDS */}
      <div className="row g-4 mb-4">
        <div className="col-md-4">
          <div className="card shadow-sm border-0">
            <div className="card-body">
              <p className="text-muted text-uppercase small mb-1">Total spent</p>
              <h4 className="fw-bold">{data.total_spent}</h4>
              <p className="text-muted small mb-0">All categories in range</p>
            </div>
          </div>
        </div>

        <div className="col-md-4">
          <div className="card shadow-sm border-0">
            <div className="card-body">
              <p className="text-muted text-uppercase small mb-1">
                Inventory purchases
              </p>
              <h4 className="fw-bold">{data.total_inventory}</h4>
              <p className="text-muted small mb-0">Type = inventory</p>
            </div>
          </div>
        </div>

        <div className="col-md-4">
          <div className="card shadow-sm border-0">
            <div className="card-body">
              <p className="text-muted text-uppercase small mb-1">
                Operating expenses
              </p>
              <h4 className="fw-bold">{data.total_operating}</h4>
              <p className="text-muted small mb-0">
                Rent, marketing, services, etc.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* CATEGORY SUMMARY + TABLE */}
      <div className="row g-4 mb-4">
        {/* Chart */}
        <div className="col-md-7">
          <div className="card shadow-sm border-0 h-100">
            <div className="card-body">
              <h5 className="card-title fw-semibold">By category</h5>
              <p className="text-muted small mb-2">
                Where your money is going in this range.
              </p>
              <div style={{ height: 260 }}>
                <canvas ref={categoryChartRef} />
              </div>
            </div>
          </div>
        </div>

        {/* Category table */}
        <div className="col-md-5">
          <div className="card shadow-sm border-0 h-100">
            <div className="card-body d-flex flex-column">
              <h5 className="card-title fw-semibold">Category breakdown</h5>
              <p className="text-muted small">
                Totals per expense category.
              </p>

              <div className="table-responsive flex-grow-1">
                <table className="table table-sm table-striped align-middle mb-0">
                  <thead className="table-light">
                    <tr>
                      <th>Category</th>
                      <th style={{ width: 140 }}>Total</th>
                    </tr>
                  </thead>
                  <tbody>
                    {data.by_category.length === 0 && (
                      <tr>
                        <td colSpan={2} className="text-muted small">
                          No expenses in this period.
                        </td>
                      </tr>
                    )}
                    {data.by_category.map((row, idx) => (
                      <tr key={idx}>
                        <td>{row.category}</td>
                        <td>{row.total}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <p className="text-muted small mt-2 mb-0">
                Categories come from your expense records. You can add or edit
                them in the admin if needed.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* LATEST EXPENSES TABLE */}
      <div className="card shadow-sm border-0">
        <div className="card-body">
          <h5 className="card-title fw-semibold">Latest expenses</h5>
          <p className="text-muted small mb-2">
            Most recent records in the selected date range.
          </p>

          {editError && (
            <div className="alert alert-danger py-2" role="alert">
              {editError}
            </div>
          )}

          <div className="table-responsive">
            <table className="table table-sm table-striped align-middle mb-0">
              <thead className="table-light">
                <tr>
                  <th style={{ width: 110 }}>Date</th>
                  <th>Description</th>
                  <th style={{ width: 110 }}>Type</th>
                  <th style={{ width: 140 }}>Category</th>
                  <th style={{ width: 160 }}>Vendor</th>
                  <th style={{ width: 140 }}>Total</th>
                  <th style={{ width: 150 }}>Receipts</th>
                  <th style={{ width: 130 }}>Actions</th>
                </tr>
              </thead>
              <tbody>
                {data.latest_expenses.length === 0 && (
                  <tr>
                    <td colSpan={8} className="text-muted small">
                      No records yet in this period.
                    </td>
                  </tr>
                )}
                {data.latest_expenses.map((e) => {
                  const isEditing = editingId === e.id;

                  if (isEditing && editForm) {
                    return (
                      <tr key={e.id}>
                        <td>
                          <input
                            type="date"
                            className="form-control form-control-sm"
                            value={editForm.date}
                            onChange={(ev) =>
                              handleEditChange("date", ev.target.value)
                            }
                          />
                        </td>
                        <td>
                          <input
                            type="text"
                            className="form-control form-control-sm"
                            value={editForm.description}
                            onChange={(ev) =>
                              handleEditChange("description", ev.target.value)
                            }
                          />
                        </td>
                        <td>
                          <select
                            className="form-select form-select-sm"
                            value={editForm.type}
                            onChange={(ev) =>
                              handleEditChange("type", ev.target.value)
                            }
                          >
                            <option value="inventory">Inventory</option>
                            <option value="operating">Operating</option>
                          </select>
                        </td>
                        <td>
                          <select
                            className="form-select form-select-sm"
                            value={editForm.category_id}
                            onChange={(ev) =>
                              handleEditChange("category_id", ev.target.value)
                            }
                          >
                            <option value="">(none)</option>
                            {data.categories.map((c) => (
                              <option key={c.id} value={c.id}>
                                {c.name}
                              </option>
                            ))}
                          </select>
                        </td>
                        <td>
                          <input
                            type="text"
                            className="form-control form-control-sm"
                            value={editForm.vendor}
                            onChange={(ev) =>
                              handleEditChange("vendor", ev.target.value)
                            }
                          />
                        </td>
                        <td>
                          <input
                            type="number"
                            step="0.01"
                            className="form-control form-control-sm"
                            value={editForm.total_amount}
                            onChange={(ev) =>
                              handleEditChange("total_amount", ev.target.value)
                            }
                          />
                        </td>
                        <td>{e.receipt_count > 0 ? `${e.receipt_count} file(s)` : "—"}</td>
                        <td>
                          <div className="d-flex gap-2">
                            <button
                              type="button"
                              className="btn btn-sm btn-dark"
                              onClick={handleEditSave}
                              disabled={editSubmitting}
                            >
                              {editSubmitting ? "Saving…" : "Save"}
                            </button>
                            <button
                              type="button"
                              className="btn btn-sm btn-outline-secondary"
                              onClick={cancelEdit}
                            >
                              Cancel
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  }

                  return (
                    <tr key={e.id}>
                      <td>{e.date}</td>
                      <td>{e.description}</td>
                      <td>{e.type_display}</td>
                      <td>{e.category_name ?? "—"}</td>
                      <td>{e.vendor || "—"}</td>
                      <td>{formatCurrency(e.total_amount, e.currency)}</td>
                      <td>
                        <div className="d-flex flex-column gap-1">
                          <span className="small">
                            {e.receipt_count > 0
                              ? `${e.receipt_count} file(s)`
                              : "No receipts"}
                          </span>
                          <input
                            type="file"
                            className="form-control form-control-sm"
                            onChange={(ev) =>
                              handleReceiptChange(e.id, ev)
                            }
                            disabled={uploadingId === e.id}
                          />
                        </div>
                      </td>
                      <td>
                        <button
                          type="button"
                          className="btn btn-sm btn-outline-primary"
                          onClick={() => startEdit(e)}
                        >
                          Edit
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

        </div>
      </div>
    </div>
  );
}