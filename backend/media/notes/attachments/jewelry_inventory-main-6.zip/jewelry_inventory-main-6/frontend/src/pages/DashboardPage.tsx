import { useEffect, useRef, useState } from "react";
import { apiGet } from "../api/client";
import { Chart, registerables } from "chart.js";

Chart.register(...registerables);

type LowStockVariant = {
  id: number;
  sku: string;
  product_name: string;
  stock_quantity: number;
  low_stock_threshold: number;
};

type StockByCollectionItem = {
  collection: string;
  total_stock: number;
};

type StockByMetalItem = {
  metal: string;
  total_stock: number;
};

type TopSupplier = {
  id: number;
  name: string;
  product_count: number;
};

type PriceSnapshotInfo = {
  gold_ounce_usd: string;
  base_currency: string;
  created_at: string;
} | null;

type GoldTrend = {
  direction: "up" | "down" | "same";
  percent_change: string;
} | null;

// Optional tiny history for sparkline – if backend sends it, we use it.
type GoldPricePoint = {
  timestamp: string;
  ounce_usd?: string;
  gold_ounce_usd?: string;
  price?: string;
  [key: string]: any;
};

type SampleRepricingItem = {
  product_id: number;
  name: string;
  purity: string;
  weight_grams: number | null;
  current_price: string | null;
  suggested_price: string;
  currency: string;
};

type DashboardSummary = {
  total_products: number;
  total_variants: number;
  total_locations: number;
  total_suppliers: number;
  total_stock_qty: number;
  total_stock_quantity?: number; // for compatibility
  low_stock_variants: LowStockVariant[];
  stock_by_collection: StockByCollectionItem[];
  stock_by_metal: StockByMetalItem[];
  top_suppliers: TopSupplier[];
  price_snapshot: PriceSnapshotInfo;
  metal_price_error: string | null;
  gold_per_gram_24k: string | null;
  gold_trend: GoldTrend;
  sample_repricing: SampleRepricingItem[];

  // Optional: if backend provides a short gold price history for the sparkline
  gold_price_history?: GoldPricePoint[];
};

export default function DashboardPage() {
  const [data, setData] = useState<DashboardSummary | null>(null);
  const [error, setError] = useState<string | null>(null);

  // main chart: stock by collection
  const collectionChartRef = useRef<HTMLCanvasElement | null>(null);
  const collectionChartInstanceRef = useRef<Chart | null>(null);

  // small KPI chart: stock by metal
  const metalChartRef = useRef<HTMLCanvasElement | null>(null);
  const metalChartInstanceRef = useRef<Chart | null>(null);

  // small KPI chart: top suppliers by product count
  const supplierChartRef = useRef<HTMLCanvasElement | null>(null);
  const supplierChartInstanceRef = useRef<Chart | null>(null);

  // tiny sparkline for gold price trend
  const goldTrendChartRef = useRef<HTMLCanvasElement | null>(null);
  const goldTrendChartInstanceRef = useRef<Chart | null>(null);

  useEffect(() => {
    apiGet<DashboardSummary>("/api/dashboard/summary/")
      .then((res) => {
        setData(res);
      })
      .catch((err) => {
        console.error(err);
        setError(err.message || "Failed to load dashboard.");
      });
  }, []);

  // Build / update charts when data changes
  useEffect(() => {
    if (!data) return;

    // --- MAIN: stock by collection ---
    const collectionCtx = collectionChartRef.current?.getContext("2d");
    if (collectionCtx) {
      if (collectionChartInstanceRef.current) {
        collectionChartInstanceRef.current.destroy();
      }

      const labels = data.stock_by_collection.map((item) => item.collection);
      const values = data.stock_by_collection.map((item) => item.total_stock);

      const chartData = {
        labels,
        datasets: [
          {
            label: "Pieces in stock",
            data: values,
          },
        ],
      };

      const options = {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
          y: {
            beginAtZero: true,
            ticks: { precision: 0 },
          },
        },
        plugins: {
          legend: {
            display: false,
          },
        },
      };

      collectionChartInstanceRef.current = new Chart(collectionCtx, {
        type: "bar",
        data: chartData,
        options,
      });
    }

    // --- KPI: stock by metal doughnut ---
    const metalCtx = metalChartRef.current?.getContext("2d");
    if (metalCtx) {
      if (metalChartInstanceRef.current) {
        metalChartInstanceRef.current.destroy();
      }

      const labels = data.stock_by_metal.map((m) => m.metal);
      const values = data.stock_by_metal.map((m) => m.total_stock);

      const metalData = {
        labels,
        datasets: [
          {
            label: "Pieces",
            data: values,
          },
        ],
      };

      const options = {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: "bottom" as const,
          },
        },
      };

      metalChartInstanceRef.current = new Chart(metalCtx, {
        type: "doughnut",
        data: metalData,
        options,
      });
    }

    // --- KPI: top suppliers bar chart ---
    const supplierCtx = supplierChartRef.current?.getContext("2d");
    if (supplierCtx) {
      if (supplierChartInstanceRef.current) {
        supplierChartInstanceRef.current.destroy();
      }

      const labels = data.top_suppliers.map((s) => s.name);
      const values = data.top_suppliers.map((s) => s.product_count);

      const supplierData = {
        labels,
        datasets: [
          {
            label: "Products",
            data: values,
          },
        ],
      };

      const options = {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
          y: {
            beginAtZero: true,
            ticks: { precision: 0 },
          },
        },
        plugins: {
          legend: {
            display: false,
          },
        },
      };

      supplierChartInstanceRef.current = new Chart(supplierCtx, {
        type: "bar",
        data: supplierData,
        options,
      });
    }

    // --- Tiny gold price sparkline (if history available) ---
    const goldTrendCtx = goldTrendChartRef.current?.getContext("2d");
    if (goldTrendCtx) {
      if (goldTrendChartInstanceRef.current) {
        goldTrendChartInstanceRef.current.destroy();
      }

      const history = Array.isArray(data.gold_price_history)
        ? data.gold_price_history
        : [];

      if (history.length > 1) {
        const labels = history.map((pt) => {
          try {
            return new Date(pt.timestamp).toLocaleTimeString();
          } catch {
            return pt.timestamp;
          }
        });

        const values = history.map((pt) => {
          const raw =
            pt.ounce_usd ??
            pt.gold_ounce_usd ??
            pt.price ??
            "0";
          const parsed = parseFloat(raw);
          return Number.isNaN(parsed) ? 0 : parsed;
        });

        const trendData = {
          labels,
          datasets: [
            {
              label: "Gold spot (oz)",
              data: values,
            },
          ],
        };

        const options = {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: { display: false },
            tooltip: { enabled: false },
          },
          scales: {
            x: { display: false },
            y: { display: false },
          },
        };

        goldTrendChartInstanceRef.current = new Chart(goldTrendCtx, {
          type: "line",
          data: trendData,
          options,
        });
      }
    }

    // cleanup on unmount or data change
    return () => {
      if (collectionChartInstanceRef.current) {
        collectionChartInstanceRef.current.destroy();
      }
      if (metalChartInstanceRef.current) {
        metalChartInstanceRef.current.destroy();
      }
      if (supplierChartInstanceRef.current) {
        supplierChartInstanceRef.current.destroy();
      }
      if (goldTrendChartInstanceRef.current) {
        goldTrendChartInstanceRef.current.destroy();
      }
    };
  }, [data]);

  if (error) {
    return (
      <div className="alert alert-danger mt-3" role="alert">
        {error}
      </div>
    );
  }

  if (!data) {
    return <div className="p-3">Loading dashboard…</div>;
  }

  const totalStock = data.total_stock_qty ?? data.total_stock_quantity ?? 0;

  const snapshot = data.price_snapshot;
  const trend = data.gold_trend;

  function formatDate(iso: string | undefined) {
    if (!iso) return "";
    try {
      return new Date(iso).toLocaleString();
    } catch {
      return iso;
    }
  }

  function renderTrendBadge() {
    if (!trend) return null;
    const percent = trend.percent_change;
    if (trend.direction === "up") {
      return <span className="small text-success">▲ {percent}%</span>;
    }
    if (trend.direction === "down") {
      return <span className="small text-danger">▼ {percent}%</span>;
    }
    return <span className="small text-muted">➝ {percent}%</span>;
  }

  return (
    <div>
      {/* Header */}
      <div className="d-flex justify-content-between align-items-center mb-3">
        <div>
          <h1 className="h3 fw-bold">Dashboard</h1>
          <p className="text-muted mb-0">
            High-level view of your jewelry inventory and suppliers.
          </p>
        </div>

        <div>
          <span className="badge bg-secondary me-2">
            Products: {data.total_products}
          </span>
          <span className="badge bg-secondary me-2">
            Variants: {data.total_variants}
          </span>
          <span className="badge bg-secondary">
            Locations: {data.total_locations}
          </span>
        </div>
      </div>

      {/* KPI CARDS */}
      <div className="row g-4 mb-4">
        {/* Total stock */}
        <div className="col-md-4">
          <div className="card shadow-sm border-0">
            <div className="card-body">
              <div className="text-muted small text-uppercase mb-1">
                Total stock pieces
              </div>
              <div className="fs-3 fw-bold">{totalStock}</div>
              <div className="text-muted small">
                Across {data.total_variants} variants
              </div>
            </div>
          </div>
        </div>

        {/* Active products */}
        <div className="col-md-4">
          <div className="card shadow-sm border-0">
            <div className="card-body">
              <div className="text-muted small text-uppercase mb-1">
                Active products
              </div>
              <div className="fs-3 fw-bold">{data.total_products}</div>
              <div className="text-muted small">
                Across {data.total_locations} locations and{" "}
                {data.total_suppliers} suppliers
              </div>
            </div>
          </div>
        </div>

        {/* 24k gold spot */}
        <div className="col-md-4">
          <div className="card shadow-sm border-0">
            <div className="card-body">
              <div className="d-flex justify-content-between align-items-baseline mb-1">
                <div className="text-muted small text-uppercase">
                  24k gold spot
                </div>
                {/* Ticker (up/down/same) */}
                {renderTrendBadge()}
              </div>

              {snapshot && data.gold_per_gram_24k ? (
                <>
                  <div className="fs-5 fw-bold mb-1">
                    {snapshot.gold_ounce_usd} {snapshot.base_currency}/oz
                  </div>
                  <div className="text-muted small mb-2">
                    ≈ {data.gold_per_gram_24k} {snapshot.base_currency}/gram ·{" "}
                    <span className="text-nowrap">
                      {formatDate(snapshot.created_at)}
                    </span>
                  </div>
                  {/* Tiny sparkline trend */}
                  <div style={{ height: 50 }}>
                    <canvas ref={goldTrendChartRef} />
                  </div>
                </>
              ) : data.metal_price_error ? (
                <>
                  <div className="fs-5 fw-bold">N/A</div>
                  <div className="small text-danger">
                    {data.metal_price_error}
                  </div>
                </>
              ) : (
                <>
                  <div className="fs-5 fw-bold">N/A</div>
                  <div className="small text-muted">No snapshot yet</div>
                </>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* SMALL KPI CHARTS ROW */}
      <div className="row g-4 mb-4">
        {/* Stock by metal (doughnut) */}
        <div className="col-md-6 col-lg-4">
          <div className="card shadow-sm border-0 h-100">
            <div className="card-body">
              <h6 className="card-title fw-semibold mb-2">Stock by metal</h6>
              <p className="text-muted small mb-2">
                Quick breakdown of pieces per metal.
              </p>
              <div style={{ height: 180 }}>
                <canvas ref={metalChartRef} />
              </div>
            </div>
          </div>
        </div>

        {/* Top suppliers (mini bar) */}
        <div className="col-md-6 col-lg-4">
          <div className="card shadow-sm border-0 h-100">
            <div className="card-body">
              <h6 className="card-title fw-semibold mb-2">Top suppliers</h6>
              <p className="text-muted small mb-2">
                Number of products per supplier.
              </p>
              <div style={{ height: 180 }}>
                <canvas ref={supplierChartRef} />
              </div>
            </div>
          </div>
        </div>

        {/* Optional: quick low-stock count card */}
        <div className="col-md-12 col-lg-4">
          <div className="card shadow-sm border-0 h-100">
            <div className="card-body d-flex flex-column justify-content-center">
              <h6 className="card-title fw-semibold mb-1">Low-stock alerts</h6>
              <p className="display-6 fw-bold mb-1">
                {data.low_stock_variants.length}
              </p>
              <p className="text-muted small mb-0">
                Variants at or below their threshold.{" "}
                {data.low_stock_variants.length > 0 &&
                  "Review replenishment for these items."}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* MAIN CHART & SUPPLIERS TABLE */}
      <div className="row g-4 mb-4">
        {/* Stock by collection chart */}
        <div className="col-md-6">
          <div className="card shadow-sm border-0 h-100">
            <div className="card-body">
              <h5 className="card-title fw-semibold">Stock by collection</h5>
              <p className="text-muted small mb-2">
                Visual overview of how many pieces you hold per collection.
              </p>
              <div style={{ height: 260 }}>
                <canvas ref={collectionChartRef} />
              </div>
            </div>
          </div>
        </div>

        {/* Suppliers + low stock */}
        <div className="col-md-6">
          <div className="card shadow-sm border-0 h-100">
            <div className="card-body d-flex flex-column">
              <h5 className="card-title fw-semibold">Key suppliers</h5>
              <p className="text-muted small">
                Suppliers linked as default on your products.
              </p>

              <div className="table-responsive mb-3">
                <table className="table table-sm table-striped align-middle mb-0">
                  <thead className="table-light">
                    <tr>
                      <th>Supplier</th>
                      <th style={{ width: 90 }}>Products</th>
                    </tr>
                  </thead>
                  <tbody>
                    {data.top_suppliers.length === 0 && (
                      <tr>
                        <td colSpan={2} className="text-muted small">
                          No suppliers linked yet.
                        </td>
                      </tr>
                    )}
                    {data.top_suppliers.map((s) => (
                      <tr key={s.id}>
                        <td>{s.name}</td>
                        <td>{s.product_count}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <h6 className="fw-semibold mt-3 mb-2">Low-stock variants</h6>
              <div className="table-responsive flex-grow-1">
                <table className="table table-sm table-striped align-middle mb-0">
                  <thead className="table-light">
                    <tr>
                      <th>SKU</th>
                      <th>Product</th>
                      <th style={{ width: 70 }}>Stock</th>
                      <th style={{ width: 80 }}>Threshold</th>
                    </tr>
                  </thead>
                  <tbody>
                    {data.low_stock_variants.length === 0 && (
                      <tr>
                        <td colSpan={4} className="text-muted small">
                          No low-stock variants at the moment.
                        </td>
                      </tr>
                    )}
                    {data.low_stock_variants.map((v) => (
                      <tr key={v.id}>
                        <td>{v.sku}</td>
                        <td>{v.product_name}</td>
                        <td>{v.stock_quantity}</td>
                        <td>{v.low_stock_threshold}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Gold pricing preview */}
      <div className="card shadow-sm border-0">
        <div className="card-body">
          <h5 className="card-title fw-semibold">Gold-based pricing overview</h5>
          <p className="text-muted small mb-2">
            Sample preview of how your recent gold products would price using
            the current 24k spot and a default markup.
          </p>

          {data.sample_repricing.length === 0 ? (
            <p className="text-muted small mb-0">
              No gold products with weight set yet, or live price unavailable.
            </p>
          ) : (
            <div className="table-responsive">
              <table className="table table-sm table-striped align-middle mb-0">
                <thead className="table-light">
                  <tr>
                    <th>Product</th>
                    <th style={{ width: 80 }}>Purity</th>
                    <th style={{ width: 90 }}>Weight (g)</th>
                    <th style={{ width: 120 }}>Current price</th>
                    <th style={{ width: 140 }}>Suggested price</th>
                  </tr>
                </thead>
                <tbody>
                  {data.sample_repricing.map((row) => (
                    <tr key={row.product_id}>
                      <td>{row.name}</td>
                      <td>{row.purity}k</td>
                      <td>{row.weight_grams ?? "—"}</td>
                      <td>
                        {row.current_price
                          ? `${row.current_price} ${row.currency}`
                          : "—"}
                      </td>
                      <td>
                        {row.suggested_price} {row.currency}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}