// frontend/src/pages/ContactsPage.tsx
import { FormEvent, useEffect, useState } from "react";
import { apiGet, apiPost } from "../api/client";

type Customer = {
  id: number;
  first_name: string;
  last_name: string;
  full_name?: string;
  email: string;
  phone: string;
  billing_country: string;
  billing_region: string;
  billing_city: string;
  billing_postcode: string;
};

type Supplier = {
  id: number;
  name: string;
  contact_name: string;
  email: string;
  phone: string;
  whatsapp: string;
  notes: string;
  is_active: boolean;
};

type NewCustomerForm = {
  first_name: string;
  last_name: string;
  email: string;
  phone: string;
  billing_country: string;
  billing_region: string;
  billing_city: string;
  billing_postcode: string;
};

type NewSupplierForm = {
  name: string;
  contact_name: string;
  email: string;
  phone: string;
  whatsapp: string;
  notes: string;
};

const EMPTY_CUSTOMER: NewCustomerForm = {
  first_name: "",
  last_name: "",
  email: "",
  phone: "",
  billing_country: "",
  billing_region: "",
  billing_city: "",
  billing_postcode: "",
};

const EMPTY_SUPPLIER: NewSupplierForm = {
  name: "",
  contact_name: "",
  email: "",
  phone: "",
  whatsapp: "",
  notes: "",
};

type Tab = "all" | "customers" | "suppliers";

export default function ContactsPage() {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [activeTab, setActiveTab] = useState<Tab>("all");
  const [search, setSearch] = useState("");

  const [newCustomer, setNewCustomer] =
    useState<NewCustomerForm>(EMPTY_CUSTOMER);
  const [newSupplier, setNewSupplier] =
    useState<NewSupplierForm>(EMPTY_SUPPLIER);
  const [creatingCustomer, setCreatingCustomer] = useState(false);
  const [creatingSupplier, setCreatingSupplier] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  useEffect(() => {
    void loadContacts();
  }, []);

  async function loadContacts() {
    setLoading(true);
    setError(null);
    try {
      const [customersData, suppliersData] = await Promise.all([
        apiGet<Customer[]>("/api/customers/"),
        apiGet<Supplier[]>("/api/suppliers/"),
      ]);
      setCustomers(customersData);
      setSuppliers(suppliersData);
    } catch (err: any) {
      console.error(err);
      setError(err.message || "Failed to load contacts.");
    } finally {
      setLoading(false);
    }
  }

  // --- Derived counts / filters ---

  const totalCustomers = customers.length;
  const totalSuppliers = suppliers.length;
  const totalContacts = totalCustomers + totalSuppliers;

  const searchLower = search.trim().toLowerCase();

  const filteredCustomers = customers.filter((c) => {
    if (!searchLower) return true;
    const fullName =
      `${c.first_name || ""} ${c.last_name || ""}`.trim().toLowerCase();
    return (
      fullName.includes(searchLower) ||
      (c.email || "").toLowerCase().includes(searchLower) ||
      (c.phone || "").toLowerCase().includes(searchLower) ||
      (c.billing_city || "").toLowerCase().includes(searchLower) ||
      (c.billing_region || "").toLowerCase().includes(searchLower)
    );
  });

  const filteredSuppliers = suppliers.filter((s) => {
    if (!searchLower) return true;
    return (
      (s.name || "").toLowerCase().includes(searchLower) ||
      (s.contact_name || "").toLowerCase().includes(searchLower) ||
      (s.email || "").toLowerCase().includes(searchLower) ||
      (s.phone || "").toLowerCase().includes(searchLower) ||
      (s.whatsapp || "").toLowerCase().includes(searchLower)
    );
  });

  // Combined view for "All" tab (simple union with a tag)
  const combinedContacts = [
    ...filteredCustomers.map((c) => ({
      type: "customer" as const,
      id: `customer-${c.id}`,
      name:
        (c.first_name || c.last_name
          ? `${c.first_name} ${c.last_name}`.trim()
          : c.email || `Customer #${c.id}`),
      email: c.email,
      phone: c.phone,
      city: c.billing_city,
      region: c.billing_region,
    })),
    ...filteredSuppliers.map((s) => ({
      type: "supplier" as const,
      id: `supplier-${s.id}`,
      name: s.name,
      email: s.email,
      phone: s.phone,
      city: "",
      region: "",
    })),
  ];

  // --- Handlers for forms ---

  function handleCustomerChange(
    e: React.ChangeEvent<HTMLInputElement>
  ) {
    const { name, value } = e.target;
    setNewCustomer((prev) => ({ ...prev, [name]: value }));
  }

  function handleSupplierChange(
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) {
    const { name, value } = e.target;
    setNewSupplier((prev) => ({ ...prev, [name]: value }));
  }

  async function handleCreateCustomer(e: FormEvent) {
    e.preventDefault();
    setFormError(null);

    if (
      !newCustomer.first_name.trim() &&
      !newCustomer.last_name.trim() &&
      !newCustomer.email.trim()
    ) {
      setFormError(
        "Please enter at least a name or an email for the customer."
      );
      return;
    }

    setCreatingCustomer(true);
    try {
      await apiPost<Customer>("/api/customers/", newCustomer);
      setNewCustomer(EMPTY_CUSTOMER);
      await loadContacts();
    } catch (err: any) {
      console.error(err);
      setFormError(err.message || "Failed to create customer.");
    } finally {
      setCreatingCustomer(false);
    }
  }

  async function handleCreateSupplier(e: FormEvent) {
    e.preventDefault();
    setFormError(null);

    if (!newSupplier.name.trim()) {
      setFormError("Please enter a vendor name.");
      return;
    }

    setCreatingSupplier(true);
    try {
      await apiPost<Supplier>("/api/suppliers/", {
        ...newSupplier,
        is_active: true,
      });
      setNewSupplier(EMPTY_SUPPLIER);
      await loadContacts();
    } catch (err: any) {
      console.error(err);
      setFormError(err.message || "Failed to create vendor contact.");
    } finally {
      setCreatingSupplier(false);
    }
  }

  return (
    <div className="container-fluid py-3">
      {/* Header */}
      <div className="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-3">
        <div className="mb-2 mb-md-0">
          <h1 className="h4 mb-1">
            <i className="fa-solid fa-address-book me-2" />
            Contacts
          </h1>
          <p className="text-muted small mb-0">
            Keep a centralized list of customers and vendor contacts
            for your jewelry business.
          </p>
        </div>
      </div>

      {/* Error */}
      {error && (
        <div className="alert alert-danger py-2" role="alert">
          {error}
        </div>
      )}

      {/* KPIs */}
      <div className="card shadow-sm border-0 mb-3">
        <div className="card-body py-3">
          <div className="row g-3">
            <div className="col-6 col-md-4">
              <div className="small text-muted text-uppercase mb-1">
                Total contacts
              </div>
              <div className="h5 mb-0">
                {totalContacts}
              </div>
            </div>
            <div className="col-6 col-md-4">
              <div className="small text-muted text-uppercase mb-1">
                Customers
              </div>
              <div className="h5 mb-0">
                {totalCustomers}
              </div>
            </div>
            <div className="col-6 col-md-4">
              <div className="small text-muted text-uppercase mb-1">
                Vendors
              </div>
              <div className="h5 mb-0">
                {totalSuppliers}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Filters + search + tabs */}
      <div className="card shadow-sm border-0 mb-3">
        <div className="card-body py-2">
          <div className="row g-2 align-items-center">
            <div className="col-md-4">
              <div className="btn-group" role="group">
                <button
                  type="button"
                  className={
                    "btn btn-sm " +
                    (activeTab === "all"
                      ? "btn-primary"
                      : "btn-outline-primary")
                  }
                  onClick={() => setActiveTab("all")}
                >
                  All
                </button>
                <button
                  type="button"
                  className={
                    "btn btn-sm " +
                    (activeTab === "customers"
                      ? "btn-primary"
                      : "btn-outline-primary")
                  }
                  onClick={() => setActiveTab("customers")}
                >
                  Customers
                </button>
                <button
                  type="button"
                  className={
                    "btn btn-sm " +
                    (activeTab === "suppliers"
                      ? "btn-primary"
                      : "btn-outline-primary")
                  }
                  onClick={() => setActiveTab("suppliers")}
                >
                  Vendors
                </button>
              </div>
            </div>

            <div className="col-md-4">
              <input
                type="text"
                className="form-control form-control-sm"
                placeholder="Search by name, email, phone…"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </div>

            <div className="col-md-4 text-md-end small text-muted">
              {loading ? "Refreshing contacts…" : null}
            </div>
          </div>
        </div>
      </div>

      {/* Forms row */}
      <div className="row mb-3">
        {/* New customer */}
        <div className="col-lg-6 mb-3">
          <div className="card shadow-sm border-0">
            <div className="card-body">
              <h5 className="card-title mb-3">New customer</h5>
              <form className="row g-2" onSubmit={handleCreateCustomer}>
                <div className="col-md-6">
                  <label className="form-label mb-1">First name</label>
                  <input
                    type="text"
                    name="first_name"
                    className="form-control form-control-sm"
                    value={newCustomer.first_name}
                    onChange={handleCustomerChange}
                  />
                </div>
                <div className="col-md-6">
                  <label className="form-label mb-1">Last name</label>
                  <input
                    type="text"
                    name="last_name"
                    className="form-control form-control-sm"
                    value={newCustomer.last_name}
                    onChange={handleCustomerChange}
                  />
                </div>
                <div className="col-md-6">
                  <label className="form-label mb-1">Email</label>
                  <input
                    type="email"
                    name="email"
                    className="form-control form-control-sm"
                    value={newCustomer.email}
                    onChange={handleCustomerChange}
                  />
                </div>
                <div className="col-md-6">
                  <label className="form-label mb-1">Phone</label>
                  <input
                    type="text"
                    name="phone"
                    className="form-control form-control-sm"
                    value={newCustomer.phone}
                    onChange={handleCustomerChange}
                  />
                </div>
                <div className="col-md-3">
                  <label className="form-label mb-1">Country</label>
                  <input
                    type="text"
                    name="billing_country"
                    className="form-control form-control-sm"
                    placeholder="US"
                    value={newCustomer.billing_country}
                    onChange={handleCustomerChange}
                  />
                </div>
                <div className="col-md-3">
                  <label className="form-label mb-1">State / Region</label>
                  <input
                    type="text"
                    name="billing_region"
                    className="form-control form-control-sm"
                    value={newCustomer.billing_region}
                    onChange={handleCustomerChange}
                  />
                </div>
                <div className="col-md-3">
                  <label className="form-label mb-1">City</label>
                  <input
                    type="text"
                    name="billing_city"
                    className="form-control form-control-sm"
                    value={newCustomer.billing_city}
                    onChange={handleCustomerChange}
                  />
                </div>
                <div className="col-md-3">
                  <label className="form-label mb-1">Postcode</label>
                  <input
                    type="text"
                    name="billing_postcode"
                    className="form-control form-control-sm"
                    value={newCustomer.billing_postcode}
                    onChange={handleCustomerChange}
                  />
                </div>
                <div className="col-12 d-flex justify-content-end mt-2">
                  <button
                    type="submit"
                    className="btn btn-sm btn-primary"
                    disabled={creatingCustomer}
                  >
                    {creatingCustomer ? "Saving…" : "Save customer"}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>

        {/* New vendor */}
        <div className="col-lg-6 mb-3">
          <div className="card shadow-sm border-0">
            <div className="card-body">
              <h5 className="card-title mb-3">New vendor</h5>
              <form className="row g-2" onSubmit={handleCreateSupplier}>
                <div className="col-md-6">
                  <label className="form-label mb-1">Vendor name</label>
                  <input
                    type="text"
                    name="name"
                    className="form-control form-control-sm"
                    value={newSupplier.name}
                    onChange={handleSupplierChange}
                    required
                  />
                </div>
                <div className="col-md-6">
                  <label className="form-label mb-1">Contact name</label>
                  <input
                    type="text"
                    name="contact_name"
                    className="form-control form-control-sm"
                    value={newSupplier.contact_name}
                    onChange={handleSupplierChange}
                  />
                </div>
                <div className="col-md-6">
                  <label className="form-label mb-1">Email</label>
                  <input
                    type="email"
                    name="email"
                    className="form-control form-control-sm"
                    value={newSupplier.email}
                    onChange={handleSupplierChange}
                  />
                </div>
                <div className="col-md-6">
                  <label className="form-label mb-1">Phone</label>
                  <input
                    type="text"
                    name="phone"
                    className="form-control form-control-sm"
                    value={newSupplier.phone}
                    onChange={handleSupplierChange}
                  />
                </div>
                <div className="col-md-6">
                  <label className="form-label mb-1">WhatsApp</label>
                  <input
                    type="text"
                    name="whatsapp"
                    className="form-control form-control-sm"
                    value={newSupplier.whatsapp}
                    onChange={handleSupplierChange}
                  />
                </div>
                <div className="col-12">
                  <label className="form-label mb-1">Notes</label>
                  <textarea
                    name="notes"
                    rows={2}
                    className="form-control form-control-sm"
                    value={newSupplier.notes}
                    onChange={handleSupplierChange}
                  />
                </div>
                <div className="col-12 d-flex justify-content-end mt-2">
                  <button
                    type="submit"
                    className="btn btn-sm btn-outline-primary"
                    disabled={creatingSupplier}
                  >
                    {creatingSupplier ? "Saving…" : "Save vendor"}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>

      {/* Any shared form error */}
      {formError && (
        <div className="alert alert-warning py-2 mb-3">
          {formError}
        </div>
      )}

      {/* Contacts tables */}
      <div className="card shadow-sm border-0">
        <div className="card-body p-2">
          {activeTab === "all" && (
            <>
              <div className="small text-muted mb-2">
                Showing {combinedContacts.length} contacts
              </div>
              {combinedContacts.length === 0 ? (
                <div className="alert alert-secondary py-2 mb-0">
                  No contacts yet. Add a customer or vendor using the
                  forms above.
                </div>
              ) : (
                <div className="table-responsive">
                  <table className="table table-hover table-sm mb-0 align-middle">
                    <thead className="table-light">
                      <tr>
                        <th style={{ width: 90 }}>Type</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>City / Region</th>
                      </tr>
                    </thead>
                    <tbody>
                      {combinedContacts.map((c) => (
                        <tr key={c.id}>
                          <td>
                            <span className="badge bg-secondary-subtle text-dark">
                              {c.type === "customer"
                                ? "Customer"
                                : "Vendor"}
                            </span>
                          </td>
                          <td className="small fw-semibold">
                            {c.name}
                          </td>
                          <td className="small">
                            {c.email || "—"}
                          </td>
                          <td className="small">
                            {c.phone || "—"}
                          </td>
                          <td className="small text-muted">
                            {[c.city, c.region].filter(Boolean).join(", ") ||
                              "—"}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </>
          )}

          {activeTab === "customers" && (
            <>
              <div className="small text-muted mb-2">
                Showing {filteredCustomers.length} customers
              </div>
              {filteredCustomers.length === 0 ? (
                <div className="alert alert-secondary py-2 mb-0">
                  No customers found.
                </div>
              ) : (
                <div className="table-responsive">
                  <table className="table table-hover table-sm mb-0 align-middle">
                    <thead className="table-light">
                      <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>City</th>
                        <th>Region</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredCustomers.map((c) => (
                        <tr key={c.id}>
                          <td className="small fw-semibold">
                            {(c.first_name || c.last_name
                              ? `${c.first_name} ${c.last_name}`.trim()
                              : c.email || `Customer #${c.id}`) || "—"}
                          </td>
                          <td className="small">{c.email || "—"}</td>
                          <td className="small">{c.phone || "—"}</td>
                          <td className="small">
                            {c.billing_city || "—"}
                          </td>
                          <td className="small">
                            {c.billing_region || "—"}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </>
          )}

          {activeTab === "suppliers" && (
            <>
              <div className="small text-muted mb-2">
                Showing {filteredSuppliers.length} vendors
              </div>
              {filteredSuppliers.length === 0 ? (
                <div className="alert alert-secondary py-2 mb-0">
                  No vendors found.
                </div>
              ) : (
                <div className="table-responsive">
                  <table className="table table-hover table-sm mb-0 align-middle">
                    <thead className="table-light">
                      <tr>
                        <th>Name</th>
                        <th>Contact</th>
                        <th>Email</th>
                        <th>Phone / WhatsApp</th>
                        <th>Notes</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredSuppliers.map((s) => (
                        <tr key={s.id}>
                          <td className="small fw-semibold">
                            {s.name}
                          </td>
                          <td className="small">
                            {s.contact_name || "—"}
                          </td>
                          <td className="small">{s.email || "—"}</td>
                          <td className="small">
                            {[s.phone, s.whatsapp]
                              .filter(Boolean)
                              .join(" / ") || "—"}
                          </td>
                          <td className="small text-muted">
                            {s.notes ? s.notes.slice(0, 80) : "—"}
                            {s.notes && s.notes.length > 80 ? "…" : ""}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}