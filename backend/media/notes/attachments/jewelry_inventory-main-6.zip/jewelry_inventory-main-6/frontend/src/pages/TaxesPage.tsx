import { FormEvent, useEffect, useRef, useState } from "react";
import { apiGet } from "../api/client";
import { Chart, registerables } from "chart.js";

Chart.register(...registerables);

type MonthlyRow = {
  month: string;      // "2025-01"
  revenue: string;    // decimal as string
  tax: string;        // decimal as string
};

type ChannelRow = {
  channel: string;
  revenue: string;
  tax: string;
};

type CountryRow = {
  country: string;
  revenue: string;
  tax: string;
};

type TaxSummary = {
  start_date: string;
  end_date: string;
  today: string;
  order_count: number;
  gross_revenue: string;
  tax_collected: string;
  shipping_total: string;
  discounts_total: string;
  monthly_data: MonthlyRow[];
  channel_data: ChannelRow[];
  country_data: CountryRow[];
};

export default function TaxesPage() {
  const [data, setData] = useState<TaxSummary | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const [startDate, setStartDate] = useState<string>("");
  const [endDate, setEndDate] = useState<string>("");

  const monthlyChartRef = useRef<HTMLCanvasElement | null>(null);
  const monthlyChartInstanceRef = useRef<Chart | null>(null);

  async function loadTaxes(opts?: { start?: string; end?: string }) {
    setLoading(true);
    setError(null);

    try {
      let url = "/api/taxes/summary/";
      const params: string[] = [];

      const s = opts?.start ?? startDate;
      const e = opts?.end ?? endDate;

      if (s) params.push(`start_date=${encodeURIComponent(s)}`);
      if (e) params.push(`end_date=${encodeURIComponent(e)}`);

      if (params.length) {
        url += "?" + params.join("&");
      }

      const res = await apiGet<TaxSummary>(url);
      setData(res);

      if (!startDate) setStartDate(res.start_date);
      if (!endDate) setEndDate(res.end_date);
    } catch (err: any) {
      console.error(err);
      setError(err.message || "Failed to load tax data.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    // initial load
    loadTaxes();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Monthly chart
  useEffect(() => {
    if (!data || !monthlyChartRef.current) {
      return;
    }

    if (monthlyChartInstanceRef.current) {
      monthlyChartInstanceRef.current.destroy();
    }

    const ctx = monthlyChartRef.current.getContext("2d");
    if (!ctx) return;

    const labels = data.monthly_data.map((m) => m.month);
    const revenueValues = data.monthly_data.map((m) =>
      parseFloat(m.revenue || "0")
    );
    const taxValues = data.monthly_data.map((m) =>
      parseFloat(m.tax || "0")
    );

    monthlyChartInstanceRef.current = new Chart(ctx, {
      type: "bar",
      data: {
        labels,
        datasets: [
          {
            label: "Revenue",
            data: revenueValues,
          },
          {
            label: "Tax",
            data: taxValues,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
          y: {
            beginAtZero: true,
          },
        },
      },
    });

    return () => {
      if (monthlyChartInstanceRef.current) {
        monthlyChartInstanceRef.current.destroy();
      }
    };
  }, [data]);

  function handleFilterSubmit(e: FormEvent) {
    e.preventDefault();
    loadTaxes({ start: startDate, end: endDate });
  }

  if (error) {
    return (
      <div className="container py-4">
        <div className="alert alert-danger mt-3" role="alert">
          {error}
        </div>
      </div>
    );
  }

  if (loading && !data) {
    return (
      <div className="container py-4">
        <p>Loading tax dashboard…</p>
      </div>
    );
  }

  if (!data) {
    return null;
  }

  return (
    <div className="container py-4">
      <div className="mb-4">
        <h1 className="h4 mb-1">Tax Dashboard</h1>
        <p className="text-muted">
          Summary of sales, tax collected, and revenue for your selected period.
        </p>
      </div>

      {/* Filter form */}
      <form className="row g-3 mb-4" onSubmit={handleFilterSubmit}>
        <div className="col-sm-4 col-md-3">
          <label className="form-label">From</label>
          <input
            type="date"
            className="form-control"
            value={startDate}
            onChange={(e) => setStartDate(e.target.value)}
          />
        </div>

        <div className="col-sm-4 col-md-3">
          <label className="form-label">To</label>
          <input
            type="date"
            className="form-control"
            value={endDate}
            onChange={(e) => setEndDate(e.target.value)}
          />
        </div>

        <div className="col-sm-4 col-md-3 d-flex align-items-end">
          <button type="submit" className="btn btn-dark w-100">
            Apply
          </button>
        </div>
      </form>

      {/* KPI cards */}
      <div className="row g-3 mb-4">
        <div className="col-md-4">
          <div className="card shadow-sm h-100">
            <div className="card-body">
              <div className="text-muted small text-uppercase">Orders</div>
              <div className="fs-4 fw-bold">{data.order_count}</div>
              <div className="text-muted small">Status = paid</div>
            </div>
          </div>
        </div>

        <div className="col-md-4">
          <div className="card shadow-sm h-100">
            <div className="card-body">
              <div className="text-muted small text-uppercase">
                Gross revenue
              </div>
              <div className="fs-4 fw-bold">{data.gross_revenue}</div>
              <div className="text-muted small">
                Includes tax and shipping
              </div>
            </div>
          </div>
        </div>

        <div className="col-md-4">
          <div className="card shadow-sm h-100">
            <div className="card-body">
              <div className="text-muted small text-uppercase">
                Tax collected
              </div>
              <div className="fs-4 fw-bold">{data.tax_collected}</div>
              <div className="text-muted small">Selected period</div>
            </div>
          </div>
        </div>
      </div>

      {/* Chart + revenue by channel */}
      <div className="row g-3 mb-4">
        <div className="col-lg-8">
          <div className="card shadow-sm h-100">
            <div className="card-body">
              <div className="d-flex justify-content-between align-items-center mb-3">
                <div>
                  <div className="text-muted small text-uppercase">
                    Monthly revenue &amp; tax
                  </div>
                  <div className="fw-bold">By month</div>
                </div>
              </div>
              <div style={{ height: "280px" }}>
                <canvas ref={monthlyChartRef} />
              </div>
              {data.monthly_data.length === 0 && (
                <p className="text-muted small mt-2">
                  No orders for this period.
                </p>
              )}
            </div>
          </div>
        </div>

        <div className="col-lg-4">
          <div className="card shadow-sm h-100">
            <div className="card-body">
              <div className="text-muted small text-uppercase mb-2">
                Revenue by channel
              </div>
              <div className="table-responsive">
                <table className="table table-striped table-sm mb-0">
                  <thead className="table-light">
                    <tr>
                      <th>Channel</th>
                      <th>Revenue</th>
                      <th>Tax</th>
                    </tr>
                  </thead>
                  <tbody>
                    {data.channel_data.length > 0 ? (
                      data.channel_data.map((row, idx) => (
                        <tr key={idx}>
                          <td>{row.channel}</td>
                          <td>{row.revenue}</td>
                          <td>{row.tax}</td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td colSpan={3} className="text-center text-muted">
                          No orders for this period.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Revenue by country */}
      <div className="card shadow-sm">
        <div className="card-body">
          <div className="text-muted small text-uppercase mb-2">
            Revenue by country
          </div>
          <div className="table-responsive">
            <table className="table table-striped table-sm mb-0">
              <thead className="table-light">
                <tr>
                  <th>Country</th>
                  <th>Revenue</th>
                  <th>Tax</th>
                </tr>
              </thead>
              <tbody>
                {data.country_data.length > 0 ? (
                  data.country_data.map((row, idx) => (
                    <tr key={idx}>
                      <td>{row.country}</td>
                      <td>{row.revenue}</td>
                      <td>{row.tax}</td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={3} className="text-center text-muted">
                      No orders for this period.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}