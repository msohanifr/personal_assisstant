// frontend/src/pages/RepairsPage.tsx
import { FormEvent, useEffect, useState } from "react";
import { apiGet, apiPost } from "../api/client";

type RepairTicket = {
  id: number;
  ticket_number: string;
  status: string;
  priority: string;
  source: string;
  intake_date: string;
  promised_date?: string | null;
  completed_date?: string | null;
  delivered_date?: string | null;
  warranty: boolean;
  estimated_price: string;
  actual_price: string;
  description: string;
  internal_notes: string;
  vendor_name: string;
  customer: number | null;
  customer_name: string;
  location: number | null;
  location_name: string;
  sku?: string;
  product_name?: string;
  is_overdue: boolean;
};

type RepairStats = {
  total: number;
  open: number;
  completed: number;
  overdue: number;
  due_today: number;
};

const STATUS_LABELS: Record<string, string> = {
  intake: "Intake",
  in_progress: "In progress",
  waiting_parts: "Waiting parts",
  ready: "Ready",
  completed: "Completed",
  delivered: "Delivered",
  cancelled: "Cancelled",
};

const PRIORITY_LABELS: Record<string, string> = {
  low: "Low",
  normal: "Normal",
  rush: "Rush",
};

const SOURCE_LABELS: Record<string, string> = {
  store: "Store",
  mail_in: "Mail-in",
  wholesale: "Wholesale",
  online: "Online",
  other: "Other",
};

type NewRepairForm = {
  variant_sku: string;
  description: string;
  intake_date: string;
  promised_date: string;
  estimated_price: string;
  source: string;
  priority: string;
  warranty: boolean;
};

const EMPTY_FORM: NewRepairForm = {
  variant_sku: "",
  description: "",
  intake_date: "",
  promised_date: "",
  estimated_price: "",
  source: "store",
  priority: "normal",
  warranty: false,
};

export default function RepairsPage() {
  const [repairs, setRepairs] = useState<RepairTicket[]>([]);
  const [stats, setStats] = useState<RepairStats | null>(null);

  const [loading, setLoading] = useState(false);
  const [loadingStats, setLoadingStats] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Filters
  const [statusFilter, setStatusFilter] = useState<string>("open");
  const [search, setSearch] = useState("");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");

  // New ticket form
  const [form, setForm] = useState<NewRepairForm>(EMPTY_FORM);
  const [creating, setCreating] = useState(false);

  useEffect(() => {
    void loadRepairs();
    void loadStats();
  }, [statusFilter, startDate, endDate, search]);

  async function loadRepairs() {
    setLoading(true);
    setError(null);
    try {
      const query: string[] = [];
      if (statusFilter) query.push(`status=${encodeURIComponent(statusFilter)}`);
      if (startDate) query.push(`start=${encodeURIComponent(startDate)}`);
      if (endDate) query.push(`end=${encodeURIComponent(endDate)}`);
      if (search.trim()) query.push(`q=${encodeURIComponent(search.trim())}`);

      const qs = query.length ? `?${query.join("&")}` : "";
      const data = await apiGet<RepairTicket[]>(`/api/repairs/tickets/${qs}`);
      setRepairs(data);
    } catch (err: any) {
      console.error(err);
      setError(err.message || "Failed to load repair tickets.");
    } finally {
      setLoading(false);
    }
  }

  async function loadStats() {
    setLoadingStats(true);
    try {
      const data = await apiGet<RepairStats>("/api/repairs/tickets/stats/");
      setStats(data);
    } catch (err: any) {
      console.error(err);
    } finally {
      setLoadingStats(false);
    }
  }

  async function handleCreate(e: FormEvent) {
    e.preventDefault();
    setError(null);

    if (!form.description.trim()) {
      setError("Please enter a description for the repair.");
      return;
    }

    setCreating(true);
    try {
      const payload: any = {
        description: form.description,
        source: form.source,
        priority: form.priority,
        warranty: form.warranty,
      };

      if (form.variant_sku.trim()) {
        payload.variant_sku = form.variant_sku.trim();
      }
      if (form.intake_date) {
        payload.intake_date = form.intake_date;
      }
      if (form.promised_date) {
        payload.promised_date = form.promised_date;
      }
      if (form.estimated_price) {
        payload.estimated_price = form.estimated_price;
      }

      await apiPost<RepairTicket>("/api/repairs/tickets/", payload);
      setForm(EMPTY_FORM);
      await Promise.all([loadRepairs(), loadStats()]);
    } catch (err: any) {
      console.error(err);
      setError(err.message || "Failed to create repair ticket.");
    } finally {
      setCreating(false);
    }
  }

  // Derived KPIs from list as backup if stats is null
  const openCount = repairs.filter(
    (r) =>
      !["completed", "delivered", "cancelled"].includes(r.status)
  ).length;
  const overdueCount = repairs.filter((r) => r.is_overdue).length;

  return (
    <div className="container-fluid py-3">
      {/* Header */}
      <div className="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-3">
        <div className="mb-2 mb-md-0">
          <h1 className="h4 mb-1">
            <i className="fa-solid fa-screwdriver-wrench me-2" />
            Repairs &amp; Workshop
          </h1>
          <p className="text-muted small mb-0">
            Track jewelry repair jobs, due dates, and workshop workload.
          </p>
        </div>
      </div>

      {error && (
        <div className="alert alert-danger py-2" role="alert">
          {error}
        </div>
      )}

      {/* KPIs */}
      <div className="card shadow-sm border-0 mb-3">
        <div className="card-body py-3">
          <div className="row g-3">
            <div className="col-6 col-md-3">
              <div className="small text-muted text-uppercase mb-1">
                Open tickets
              </div>
              <div className="h5 mb-0">
                {stats?.open ?? openCount}
              </div>
            </div>
            <div className="col-6 col-md-3">
              <div className="small text-muted text-uppercase mb-1">
                Overdue
              </div>
              <div className="h5 mb-0 text-danger">
                {stats?.overdue ?? overdueCount}
              </div>
            </div>
            <div className="col-6 col-md-3">
              <div className="small text-muted text-uppercase mb-1">
                Due today
              </div>
              <div className="h5 mb-0">
                {stats?.due_today ?? 0}
              </div>
            </div>
            <div className="col-6 col-md-3">
              <div className="small text-muted text-uppercase mb-1">
                All tickets
              </div>
              <div className="h5 mb-0">
                {stats?.total ?? repairs.length}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Filters + New ticket form */}
      <div className="row">
        {/* Filters */}
        <div className="col-lg-7 mb-3">
          <div className="card shadow-sm border-0">
            <div className="card-body">
              <h5 className="card-title mb-3">Filter repairs</h5>
              <form
                className="row g-2 align-items-end"
                onSubmit={(e) => {
                  e.preventDefault();
                  void loadRepairs();
                  void loadStats();
                }}
              >
                <div className="col-md-3">
                  <label className="form-label mb-1">Status</label>
                  <select
                    className="form-select form-select-sm"
                    value={statusFilter}
                    onChange={(e) => setStatusFilter(e.target.value)}
                  >
                    <option value="open">Open only</option>
                    <option value="">All statuses</option>
                    {Object.entries(STATUS_LABELS).map(([value, label]) => (
                      <option key={value} value={value}>
                        {label}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="col-md-3">
                  <label className="form-label mb-1">Start (intake)</label>
                  <input
                    type="date"
                    className="form-control form-control-sm"
                    value={startDate}
                    onChange={(e) => setStartDate(e.target.value)}
                  />
                </div>

                <div className="col-md-3">
                  <label className="form-label mb-1">End (intake)</label>
                  <input
                    type="date"
                    className="form-control form-control-sm"
                    value={endDate}
                    onChange={(e) => setEndDate(e.target.value)}
                  />
                </div>

                <div className="col-md-3">
                  <label className="form-label mb-1">Search</label>
                  <input
                    type="text"
                    className="form-control form-control-sm"
                    placeholder="Ticket, customer, SKU…"
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                  />
                </div>

                <div className="col-12 mt-2">
                  <button
                    type="submit"
                    className="btn btn-sm btn-outline-primary"
                    disabled={loading || loadingStats}
                  >
                    {loading ? "Updating…" : "Apply filters"}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>

        {/* New ticket form */}
        <div className="col-lg-5 mb-3">
          <div className="card shadow-sm border-0">
            <div className="card-body">
              <h5 className="card-title mb-3">New repair ticket</h5>
              <form onSubmit={handleCreate} className="row g-2">
                <div className="col-12">
                  <label className="form-label mb-1">SKU (optional)</label>
                  <input
                    className="form-control form-control-sm"
                    placeholder="e.g. MR-0123"
                    value={form.variant_sku}
                    onChange={(e) =>
                      setForm((f) => ({ ...f, variant_sku: e.target.value }))
                    }
                  />
                </div>

                <div className="col-12">
                  <label className="form-label mb-1">Description</label>
                  <textarea
                    className="form-control form-control-sm"
                    rows={2}
                    value={form.description}
                    onChange={(e) =>
                      setForm((f) => ({ ...f, description: e.target.value }))
                    }
                  />
                </div>

                <div className="col-6">
                  <label className="form-label mb-1">Intake date</label>
                  <input
                    type="date"
                    className="form-control form-control-sm"
                    value={form.intake_date}
                    onChange={(e) =>
                      setForm((f) => ({ ...f, intake_date: e.target.value }))
                    }
                  />
                </div>

                <div className="col-6">
                  <label className="form-label mb-1">Promised date</label>
                  <input
                    type="date"
                    className="form-control form-control-sm"
                    value={form.promised_date}
                    onChange={(e) =>
                      setForm((f) => ({ ...f, promised_date: e.target.value }))
                    }
                  />
                </div>

                <div className="col-6">
                  <label className="form-label mb-1">Estimated price</label>
                  <input
                    type="number"
                    step="0.01"
                    className="form-control form-control-sm"
                    value={form.estimated_price}
                    onChange={(e) =>
                      setForm((f) => ({
                        ...f,
                        estimated_price: e.target.value,
                      }))
                    }
                  />
                </div>

                <div className="col-6">
                  <label className="form-label mb-1">Priority</label>
                  <select
                    className="form-select form-select-sm"
                    value={form.priority}
                    onChange={(e) =>
                      setForm((f) => ({ ...f, priority: e.target.value }))
                    }
                  >
                    {Object.entries(PRIORITY_LABELS).map(([value, label]) => (
                      <option key={value} value={value}>
                        {label}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="col-6">
                  <label className="form-label mb-1">Source</label>
                  <select
                    className="form-select form-select-sm"
                    value={form.source}
                    onChange={(e) =>
                      setForm((f) => ({ ...f, source: e.target.value }))
                    }
                  >
                    {Object.entries(SOURCE_LABELS).map(([value, label]) => (
                      <option key={value} value={value}>
                        {label}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="col-6 d-flex align-items-center">
                  <div className="form-check mt-3">
                    <input
                      className="form-check-input"
                      type="checkbox"
                      id="warrantyCheck"
                      checked={form.warranty}
                      onChange={(e) =>
                        setForm((f) => ({
                          ...f,
                          warranty: e.target.checked,
                        }))
                      }
                    />
                    <label
                      className="form-check-label small"
                      htmlFor="warrantyCheck"
                    >
                      Warranty / no charge
                    </label>
                  </div>
                </div>

                <div className="col-12 mt-2">
                  <button
                    type="submit"
                    className="btn btn-sm btn-primary w-100"
                    disabled={creating}
                  >
                    {creating ? "Creating…" : "Create ticket"}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>

      {/* Tickets table */}
      <div className="card shadow-sm border-0">
        <div className="card-body p-2">
          <div className="d-flex justify-content-between align-items-center mb-2">
            <div className="small text-muted">
              {loading
                ? "Loading repairs…"
                : `Showing ${repairs.length} tickets`}
            </div>
          </div>

          {repairs.length === 0 && !loading && (
            <div className="alert alert-secondary py-2 mb-0">
              No repair tickets found for this filter.
            </div>
          )}

          {repairs.length > 0 && (
            <div className="table-responsive">
              <table className="table table-hover table-sm align-middle mb-0">
                <thead className="table-light">
                  <tr>
                    <th style={{ width: 110 }}>Ticket</th>
                    <th style={{ width: 90 }}>Intake</th>
                    <th style={{ width: 90 }}>Promised</th>
                    <th>Status</th>
                    <th>Customer</th>
                    <th>Piece</th>
                    <th style={{ width: 90 }} className="text-end">
                      Est.
                    </th>
                    <th style={{ width: 90 }} className="text-end">
                      Actual
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {repairs.map((r) => {
                    const statusLabel = STATUS_LABELS[r.status] || r.status;
                    const priorityLabel =
                      PRIORITY_LABELS[r.priority] || r.priority;
                    const sourceLabel = SOURCE_LABELS[r.source] || r.source;

                    return (
                      <tr key={r.id}>
                        <td>
                          <div className="fw-semibold">
                            {r.ticket_number}
                          </div>
                          <div className="small text-muted">
                            {priorityLabel} · {sourceLabel}
                          </div>
                        </td>
                        <td className="small">
                          {r.intake_date || "—"}
                        </td>
                        <td className="small">
                          {r.promised_date || "—"}
                          {r.is_overdue && (
                            <span className="badge bg-danger-subtle text-danger ms-1">
                              Overdue
                            </span>
                          )}
                        </td>
                        <td>
                          <span className="badge bg-secondary-subtle text-dark">
                            {statusLabel}
                          </span>
                        </td>
                        <td className="small">
                          {r.customer_name || "—"}
                        </td>
                        <td className="small">
                          <div>
                            {r.product_name || "—"}
                          </div>
                          {r.sku && (
                            <div className="text-muted">
                              SKU: {r.sku}
                            </div>
                          )}
                        </td>
                        <td className="text-end small">
                          {r.estimated_price || "0.00"}
                        </td>
                        <td className="text-end small">
                          {r.actual_price || "0.00"}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}