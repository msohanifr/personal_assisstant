import { type FormEvent, useEffect, useState } from "react";
import { apiGet, apiPost } from "../api/client";
import * as XLSX from "xlsx";

type BankAccount = {
  id: number;
  name: string;
  institution_name: string;
  account_type: string;
  currency: string;
  last4?: string;
  is_active: boolean;
};

type BankTransaction = {
  id: number;
  account: number;
  account_name: string;
  transaction_date: string; // ISO date
  posted_date?: string | null;
  description: string;
  amount: string; // decimal as string
  currency: string;
  external_id?: string | null;
  matched_order?: number | null;
  matched_expense?: number | null;
  match_confidence: string;
  notes: string;
  raw_data?: any; // for extra info like running balance
};

type ImportedRow = {
  transaction_date: string;
  description: string;
  amount: number;
  currency?: string;
  external_id?: string;
  running_balance?: number | null;
  raw?: any;
};

type MatchCandidate = {
  type: "order" | "expense";
  id: number;
  score: number;
  amount: string;
  order_number?: string;
  order_date?: string;
  description?: string;
  date?: string;
};

type SuggestMatchesResponse = {
  transaction_id: number;
  transaction_description: string;
  transaction_amount: string;
  transaction_date: string;
  candidates: MatchCandidate[];
};

export default function BankTransactionsPage() {
  const [accounts, setAccounts] = useState<BankAccount[]>([]);
  const [selectedAccountId, setSelectedAccountId] = useState<number | null>(
    null
  );

  const [transactions, setTransactions] = useState<BankTransaction[]>([]);
  const [loadingAccounts, setLoadingAccounts] = useState(false);
  const [loadingTxns, setLoadingTxns] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [search, setSearch] = useState("");
  const [showOnlyUnmatched, setShowOnlyUnmatched] = useState(false);

  // Import (Excel/CSV)
  const [, setImportFile] = useState<File | null>(null);
  const [importRows, setImportRows] = useState<ImportedRow[]>([]);
  const [importParsing, setImportParsing] = useState(false);
  const [importError, setImportError] = useState<string | null>(null);
  const [importingToServer, setImportingToServer] = useState(false);

  // Suggestions / fuzzy match
  const [suggestingForId, setSuggestingForId] = useState<number | null>(null);
  const [suggestions, setSuggestions] = useState<
    SuggestMatchesResponse | null
  >(null);
  const [suggestError, setSuggestError] = useState<string | null>(null);

  useEffect(() => {
    void loadAccounts();
  }, []);

  useEffect(() => {
    if (selectedAccountId != null) {
      void loadTransactions(selectedAccountId);
    }
  }, [selectedAccountId]);

  async function loadAccounts() {
    setLoadingAccounts(true);
    setError(null);
    try {
      const data = await apiGet<BankAccount[]>("/api/banking/accounts/");
      setAccounts(data);
      // default select first active account
      const firstActive = data.find((a) => a.is_active) || data[0];
      if (firstActive) {
        setSelectedAccountId(firstActive.id);
      }
    } catch (err: any) {
      console.error(err);
      setError(err.message || "Failed to load accounts.");
    } finally {
      setLoadingAccounts(false);
    }
  }

  async function loadTransactions(accountId: number) {
    setLoadingTxns(true);
    setError(null);
    try {
      const data = await apiGet<BankTransaction[]>(
        `/api/banking/transactions/?account=${accountId}`
      );
      setTransactions(data);
    } catch (err: any) {
      console.error(err);
      setError(err.message || "Failed to load transactions.");
    } finally {
      setLoadingTxns(false);
    }
  }

  // --- Filtering ---
  const filteredTransactions = transactions.filter((t) => {
    if (showOnlyUnmatched && (t.matched_order || t.matched_expense)) {
      return false;
    }
    if (!search.trim()) return true;
    const q = search.trim().toLowerCase();
    const desc = (t.description || "").toLowerCase();
    const notes = (t.notes || "").toLowerCase();
    const ext = (t.external_id || "").toLowerCase();
    return desc.includes(q) || notes.includes(q) || ext.includes(q);
  });

  // --- Excel / CSV import with special handling for Bank of America CSV ---

  function handleFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0] || null;
    setImportFile(file);
    setImportRows([]);
    setImportError(null);

    if (!file) return;
    void parseFile(file);
  }

  async function parseFile(file: File) {
    setImportParsing(true);
    setImportError(null);
    try {
      const data = await file.arrayBuffer();
      const workbook = XLSX.read(data, { type: "array" });
      const sheetName = workbook.SheetNames[0];
      const sheet = workbook.Sheets[sheetName];

      // Use header:1 to get raw rows (arrays) so we can handle
      // the Bank of America format:
      //
      // Description,,Summary Amt.
      // Beginning balance...
      // ...
      // (blank)
      // Date,Description,Amount,Running Bal.
      // 01/01/2025,Beginning balance...,,"4380.59"
      // 01/22/2025,"MXV CONSULTING...",18317.32,"22697.91"
      //
      const rawRows = XLSX.utils.sheet_to_json(sheet, {
        header: 1,
        defval: "",
      }) as any[][];

      const rows: ImportedRow[] = [];

      if (rawRows.length > 0) {
        // Detect Bank of America-style header: look for a row with
        // ["Date","Description","Amount","Running Bal."]
        const headerIndex = rawRows.findIndex(
          (row) =>
            String(row[0]).trim() === "Date" &&
            String(row[1]).trim() === "Description"
        );

        if (headerIndex >= 0) {
          // Process rows after this header row
          for (let i = headerIndex + 1; i < rawRows.length; i++) {
            const row = rawRows[i];
            const dateRaw = row[0];
            const description = row[1];
            const amountRaw = row[2];
            const runningBalRaw = row[3];

            if (!dateRaw && !description && !amountRaw && !runningBalRaw) {
              continue; // skip empty lines
            }

            // Normalize date into YYYY-MM-DD if possible
            let isoDate = "";
            if (dateRaw instanceof Date) {
              isoDate = dateRaw.toISOString().slice(0, 10);
            } else if (typeof dateRaw === "string" && dateRaw.trim()) {
              const d = new Date(dateRaw);
              if (!isNaN(d.getTime())) {
                isoDate = d.toISOString().slice(0, 10);
              } else {
                isoDate = dateRaw.trim();
              }
            }

            // Amount can be empty for "Beginning balance" row; treat as 0
            const amountNum = Number(
              typeof amountRaw === "string"
                ? amountRaw.replace(/,/g, "")
                : amountRaw || 0
            );
            const runningBalNum =
              runningBalRaw === "" || runningBalRaw == null
                ? null
                : Number(
                    typeof runningBalRaw === "string"
                      ? runningBalRaw.replace(/,/g, "")
                      : runningBalRaw
                  );

            rows.push({
              transaction_date: isoDate,
              description: String(description || "").trim(),
              amount: amountNum || 0,
              currency: undefined, // Bank of America CSV is for one currency (account currency)
              external_id: undefined,
              running_balance: isNaN(runningBalNum as number)
                ? null
                : runningBalNum,
              raw: {
                source: "bofa",
                date: dateRaw,
                description,
                amount_raw: amountRaw,
                running_balance_raw: runningBalRaw,
              },
            });
          }
        } else {
          // Generic fallback: treat first row as headers
          const json: any[] = XLSX.utils.sheet_to_json(sheet, { defval: "" });
          json.forEach((row) => {
            const dateRaw =
              row["Transaction Date"] ||
              row["Date"] ||
              row["DATE"] ||
              row["transaction_date"] ||
              row["date"];
            const description =
              row["Description"] ||
              row["DESCRIPTON"] ||
              row["Details"] ||
              row["description"] ||
              "";
            const amountRaw =
              row["Amount"] ||
              row["AMOUNT"] ||
              row["amount"] ||
              row["Credit"] ||
              row["Debit"] ||
              0;
            const currency =
              row["Currency"] ||
              row["CURRENCY"] ||
              row["currency"] ||
              undefined;
            const externalId =
              row["External ID"] ||
              row["ID"] ||
              row["Transaction ID"] ||
              row["external_id"] ||
              undefined;

            let isoDate = "";
            if (dateRaw instanceof Date) {
              isoDate = dateRaw.toISOString().slice(0, 10);
            } else if (typeof dateRaw === "string" && dateRaw.trim()) {
              const d = new Date(dateRaw);
              if (!isNaN(d.getTime())) {
                isoDate = d.toISOString().slice(0, 10);
              } else {
                isoDate = dateRaw.trim();
              }
            }

            const amountNum = Number(
              typeof amountRaw === "string"
                ? amountRaw.replace(/,/g, "")
                : amountRaw
            );

            rows.push({
              transaction_date: isoDate,
              description: String(description),
              amount: amountNum || 0,
              currency,
              external_id: externalId ? String(externalId) : undefined,
              running_balance: null,
              raw: row,
            });
          });
        }
      }

      setImportRows(rows);
    } catch (err: any) {
      console.error(err);
      setImportError(err.message || "Failed to read file.");
    } finally {
      setImportParsing(false);
    }
  }

  async function handleImportSubmit(e: FormEvent) {
    e.preventDefault();
    if (!selectedAccountId) {
      setImportError("Select an account before importing.");
      return;
    }
    if (!importRows.length) {
      setImportError("No rows to import. Please upload a file first.");
      return;
    }

    setImportError(null);
    setImportingToServer(true);
    try {
      // Bulk import into backend
      await apiPost("/api/banking/transactions/bulk_import/", {
        account: selectedAccountId,
        rows: importRows.map((r) => ({
          transaction_date: r.transaction_date,
          description: r.description,
          amount: r.amount,
          currency: r.currency,
          external_id: r.external_id,
          raw_data: {
            ...r.raw,
            running_balance: r.running_balance,
          },
        })),
      });

      // Refresh transactions
      await loadTransactions(selectedAccountId);
      setImportRows([]);
      setImportFile(null);
    } catch (err: any) {
      console.error(err);
      setImportError(err.message || "Failed to import transactions.");
    } finally {
      setImportingToServer(false);
    }
  }

  // --- Suggestions / fuzzy matches ---

  async function handleSuggestMatches(txnId: number) {
    setSuggestingForId(txnId);
    setSuggestions(null);
    setSuggestError(null);

    try {
      const data = await apiGet<SuggestMatchesResponse>(
        `/api/banking/transactions/${txnId}/suggest_matches/`
      );
      setSuggestions(data);
    } catch (err: any) {
      console.error(err);
      setSuggestError(err.message || "Failed to get suggestions.");
    } finally {
      setSuggestingForId(null);
    }
  }

  const selectedAccount = accounts.find((a) => a.id === selectedAccountId);

  // --- KPIs & simple "graph" (no chart library needed) ---

  let totalIn = 0;
  let totalOut = 0;
  let countWithAmount = 0;

  filteredTransactions.forEach((t) => {
    const amt = Number(t.amount);
    if (isNaN(amt)) return;
    if (amt > 0) {
      totalIn += amt;
    } else if (amt < 0) {
      totalOut += amt;
    }
    countWithAmount += 1;
  });

  const netFlow = totalIn + totalOut;
  const avgTicket =
    countWithAmount > 0 ? (totalIn + Math.abs(totalOut)) / countWithAmount : 0;

  // Monthly net cash flow for a simple bar "graph"
  type MonthlyAgg = {
    month: string;
    label: string;
    inflow: number;
    outflow: number;
    net: number;
  };
  const monthlyMap: Record<string, MonthlyAgg> = {};

  filteredTransactions.forEach((t) => {
    const amt = Number(t.amount);
    if (isNaN(amt)) return;
    const d = new Date(t.transaction_date);
    if (isNaN(d.getTime())) return;

    const year = d.getFullYear();
    const monthNum = d.getMonth() + 1;
    const key = `${year}-${String(monthNum).padStart(2, "0")}`;

    if (!monthlyMap[key]) {
      const monthLabel = d.toLocaleString(undefined, {
        month: "short",
        year: "numeric",
      });
      monthlyMap[key] = {
        month: key,
        label: monthLabel,
        inflow: 0,
        outflow: 0,
        net: 0,
      };
    }

    if (amt > 0) {
      monthlyMap[key].inflow += amt;
    } else if (amt < 0) {
      monthlyMap[key].outflow += amt;
    }
    monthlyMap[key].net = monthlyMap[key].inflow + monthlyMap[key].outflow;
  });

  const monthlyData = Object.values(monthlyMap).sort((a, b) =>
    a.month.localeCompare(b.month)
  );
  const maxAbsNet =
    monthlyData.length > 0
      ? Math.max(...monthlyData.map((m) => Math.abs(m.net)), 1)
      : 1;

  return (
    <div className="container-fluid py-3">
      {/* Header */}
      <div className="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-3">
        <div className="mb-2 mb-md-0">
          <h1 className="h4 mb-1">
            <i className="fa-solid fa-building-columns me-2" />
            Bank Transactions
          </h1>
          <p className="text-muted small mb-0">
            View and import personal &amp; business account transactions, then
            match them to sales and expenses.
          </p>
        </div>
      </div>

      {error && (
        <div className="alert alert-danger py-2" role="alert">
          {error}
        </div>
      )}

      {/* Account selector + search */}
      <div className="card shadow-sm border-0 mb-3">
        <div className="card-body py-2">
          <div className="row g-2 align-items-center">
            <div className="col-md-4">
              <label className="form-label mb-1 small text-uppercase text-muted">
                Account
              </label>
              <select
                className="form-select form-select-sm"
                value={selectedAccountId ?? ""}
                onChange={(e) =>
                  setSelectedAccountId(
                    e.target.value ? Number(e.target.value) : null
                  )
                }
                disabled={loadingAccounts}
              >
                <option value="">Select account…</option>
                {accounts.map((a) => (
                  <option key={a.id} value={a.id}>
                    {a.name}{" "}
                    {a.last4 ? `••••${a.last4}` : ""}{" "}
                    {a.account_type ? `(${a.account_type})` : ""}
                  </option>
                ))}
              </select>
              {loadingAccounts && (
                <div className="small text-muted mt-1">
                  Loading accounts…
                </div>
              )}
            </div>

            <div className="col-md-4">
              <label className="form-label mb-1 small text-uppercase text-muted">
                Search
              </label>
              <input
                type="text"
                className="form-control form-control-sm"
                placeholder="Search description, notes, ID…"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </div>

            <div className="col-md-4 d-flex align-items-end justify-content-md-end">
              <div className="form-check form-switch">
                <input
                  className="form-check-input"
                  type="checkbox"
                  id="unmatchedSwitch"
                  checked={showOnlyUnmatched}
                  onChange={(e) => setShowOnlyUnmatched(e.target.checked)}
                />
                <label
                  className="form-check-label small"
                  htmlFor="unmatchedSwitch"
                >
                  Show only unmatched
                </label>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* KPIs */}
      <div className="card shadow-sm border-0 mb-3">
        <div className="card-body py-3">
          <div className="row g-3">
            <div className="col-6 col-md-3">
              <div className="small text-muted text-uppercase mb-1">
                Total inflow
              </div>
              <div className="h5 mb-0 text-success">
                ${totalIn.toLocaleString(undefined, { maximumFractionDigits: 2 })}
              </div>
            </div>
            <div className="col-6 col-md-3">
              <div className="small text-muted text-uppercase mb-1">
                Total outflow
              </div>
              <div className="h5 mb-0 text-danger">
                ${Math.abs(totalOut).toLocaleString(undefined, {
                  maximumFractionDigits: 2,
                })}
              </div>
            </div>
            <div className="col-6 col-md-3">
              <div className="small text-muted text-uppercase mb-1">
                Net cash flow
              </div>
              <div
                className={
                  "h5 mb-0 " + (netFlow >= 0 ? "text-success" : "text-danger")
                }
              >
                {netFlow >= 0 ? "+" : "-"}$
                {Math.abs(netFlow).toLocaleString(undefined, {
                  maximumFractionDigits: 2,
                })}
              </div>
            </div>
            <div className="col-6 col-md-3">
              <div className="small text-muted text-uppercase mb-1">
                # of transactions
              </div>
              <div className="h5 mb-0">{filteredTransactions.length}</div>
              {avgTicket > 0 && (
                <div className="small text-muted">
                  Avg ticket: $
                  {avgTicket.toLocaleString(undefined, {
                    maximumFractionDigits: 2,
                  })}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Simple monthly "graph" */}
      <div className="card shadow-sm border-0 mb-3">
        <div className="card-body py-3">
          <h6 className="mb-3">Monthly net cash flow</h6>
          {monthlyData.length === 0 && (
            <p className="small text-muted mb-0">
              Not enough transactions yet to show monthly trends.
            </p>
          )}
          {monthlyData.length > 0 && (
            <div>
              {monthlyData.map((m) => {
                const widthPercent = (Math.abs(m.net) / maxAbsNet) * 100;
                const positive = m.net >= 0;
                return (
                  <div
                    key={m.month}
                    className="d-flex align-items-center mb-2"
                  >
                    <div style={{ width: 90 }} className="small text-muted">
                      {m.label}
                    </div>
                    <div className="flex-grow-1 bg-light rounded-pill" style={{ height: 8 }}>
                      <div
                        style={{
                          width: `${widthPercent}%`,
                          height: "100%",
                          borderRadius: "999px",
                          backgroundColor: positive ? "#198754" : "#dc3545",
                        }}
                      />
                    </div>
                    <div className="ms-2 small">
                      {positive ? "+" : "-"}$
                      {Math.abs(m.net).toLocaleString(undefined, {
                        maximumFractionDigits: 0,
                      })}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* Import section */}
      <div className="card shadow-sm border-0 mb-3">
        <div className="card-body">
          <h5 className="card-title mb-3">Import transactions</h5>

          <ul className="nav nav-tabs mb-3" role="tablist">
            <li className="nav-item" role="presentation">
              <button
                className="nav-link active"
                id="excel-tab"
                data-bs-toggle="tab"
                data-bs-target="#excel-pane"
                type="button"
                role="tab"
              >
                Excel / CSV
              </button>
            </li>
            <li className="nav-item" role="presentation">
              <button
                className="nav-link"
                id="api-tab"
                data-bs-toggle="tab"
                data-bs-target="#api-pane"
                type="button"
                role="tab"
              >
                API (Plaid)
              </button>
            </li>
          </ul>

          <div className="tab-content">
            {/* Excel / CSV tab */}
            <div
              className="tab-pane fade show active"
              id="excel-pane"
              role="tabpanel"
              aria-labelledby="excel-tab"
            >
              <form onSubmit={handleImportSubmit}>
                <div className="row g-2 align-items-center mb-2">
                  <div className="col-md-6">
                    <label className="form-label mb-1 small text-uppercase text-muted">
                      File
                    </label>
                    <input
                      type="file"
                      className="form-control form-control-sm"
                      accept=".xlsx,.xls,.csv"
                      onChange={handleFileChange}
                    />
                    <div className="form-text">
                      Bank of America CSV is supported. Expected transaction
                      header: <code>Date, Description, Amount, Running Bal.</code>
                    </div>
                  </div>
                </div>

                {importParsing && (
                  <p className="text-muted small mb-2">
                    Reading file and parsing rows…
                  </p>
                )}

                {importError && (
                  <div className="alert alert-danger py-2">{importError}</div>
                )}

                {importRows.length > 0 && (
                  <>
                    <p className="small mb-2">
                      Parsed <strong>{importRows.length}</strong> rows for{" "}
                      <strong>
                        {selectedAccount?.name || "selected account"}
                      </strong>
                      .
                    </p>
                    <div className="table-responsive mb-2">
                      <table className="table table-sm table-striped mb-0">
                        <thead>
                          <tr>
                            <th>#</th>
                            <th>Date</th>
                            <th>Description</th>
                            <th className="text-end">Amount</th>
                            <th className="text-end">Running Bal.</th>
                          </tr>
                        </thead>
                        <tbody>
                          {importRows.slice(0, 10).map((r, idx) => (
                            <tr key={idx}>
                              <td>{idx + 1}</td>
                              <td>{r.transaction_date}</td>
                              <td
                                className="text-truncate"
                                style={{ maxWidth: 260 }}
                              >
                                {r.description}
                              </td>
                              <td className="text-end">
                                {r.amount.toFixed(2)}
                              </td>
                              <td className="text-end">
                                {r.running_balance != null
                                  ? r.running_balance.toFixed(2)
                                  : "—"}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                    {importRows.length > 10 && (
                      <div className="small text-muted mb-2">
                        Showing first 10 rows of {importRows.length}…
                      </div>
                    )}
                    <button
                      type="submit"
                      className="btn btn-sm btn-primary"
                      disabled={
                        importingToServer ||
                        importParsing ||
                        !selectedAccountId
                      }
                    >
                      {importingToServer
                        ? "Importing…"
                        : `Import ${importRows.length} rows`}
                    </button>
                  </>
                )}
              </form>
            </div>

            {/* API / Plaid tab */}
            <div
              className="tab-pane fade"
              id="api-pane"
              role="tabpanel"
              aria-labelledby="api-tab"
            >
              <p className="small text-muted">
                Here you can later connect to Plaid or another banking API so
                transactions can sync automatically.
              </p>
              <button
                type="button"
                className="btn btn-sm btn-outline-primary"
                disabled
              >
                <i className="fa-solid fa-link me-1" />
                Connect via Plaid (coming soon)
              </button>
              <div className="form-text mt-2">
                Backend idea: expose endpoints like{" "}
                <code>/api/banking/plaid/link_token/</code> to start the link
                flow, then{" "}
                <code>/api/banking/plaid/exchange_public_token/</code> to save
                access tokens and automatically create{" "}
                <code>BankTransaction</code> records.
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Transactions table */}
      <div className="card shadow-sm border-0">
        <div className="card-body p-2">
          <div className="d-flex justify-content-between align-items-center mb-2">
            <div className="small text-muted">
              {loadingTxns
                ? "Loading transactions…"
                : `Showing ${filteredTransactions.length} of ${transactions.length} transactions`}
            </div>
          </div>

          {filteredTransactions.length === 0 && !loadingTxns && (
            <div className="alert alert-secondary py-2 mb-0">
              No transactions found for this account / filter.
            </div>
          )}

          {filteredTransactions.length > 0 && (
            <div className="table-responsive">
              <table className="table table-hover table-sm align-middle mb-0">
                <thead className="table-light">
                  <tr>
                    <th style={{ width: 90 }}>Date</th>
                    <th>Description</th>
                    <th style={{ width: 100 }} className="text-end">
                      Amount
                    </th>
                    <th style={{ width: 80 }}>Direction</th>
                    <th style={{ width: 110 }} className="text-end">
                      Balance*
                    </th>
                    <th style={{ width: 110 }}>Matched to</th>
                    <th style={{ width: 110 }} className="text-center">
                      Confidence
                    </th>
                    <th style={{ width: 140 }}></th>
                  </tr>
                </thead>
                <tbody>
                  {filteredTransactions.map((t) => {
                    const amt = Number(t.amount);
                    const positive = !isNaN(amt) && amt > 0;
                    const matched = !!(t.matched_order || t.matched_expense);
                    const runningBalance =
                      t.raw_data?.running_balance ??
                      t.raw_data?.running_balance_raw ??
                      null;

                    return (
                      <tr key={t.id}>
                        <td>{t.transaction_date}</td>
                        <td>
                          <div
                            className="fw-semibold text-truncate"
                            style={{ maxWidth: 260 }}
                          >
                            {t.description}
                          </div>
                          {t.external_id && (
                            <div className="small text-muted">
                              ID: {t.external_id}
                            </div>
                          )}
                        </td>
                        <td className="text-end">
                          <span
                            className={
                              positive
                                ? "text-success fw-semibold"
                                : "text-danger fw-semibold"
                            }
                          >
                            {isNaN(amt) ? "—" : amt.toFixed(2)}
                          </span>
                        </td>
                        <td>
                          {isNaN(amt) || amt === 0 ? (
                            <span className="badge bg-secondary-subtle text-muted">
                              Neutral
                            </span>
                          ) : positive ? (
                            <span className="badge bg-success-subtle text-success">
                              Inflow
                            </span>
                          ) : (
                            <span className="badge bg-danger-subtle text-danger">
                              Outflow
                            </span>
                          )}
                        </td>
                        <td className="text-end">
                          {runningBalance != null &&
                          !isNaN(Number(runningBalance)) ? (
                            <span className="small">
                              {Number(runningBalance).toFixed(2)}
                            </span>
                          ) : (
                            <span className="text-muted small">—</span>
                          )}
                        </td>
                        <td>
                          {matched ? (
                            <span className="badge bg-success-subtle text-success">
                              {t.matched_order
                                ? "Order"
                                : t.matched_expense
                                ? "Expense"
                                : "Matched"}
                            </span>
                          ) : (
                            <span className="badge bg-secondary-subtle text-muted">
                              Unmatched
                            </span>
                          )}
                        </td>
                        <td className="text-center">
                          {Number(t.match_confidence) > 0 ? (
                            <span className="badge bg-info-subtle text-info">
                              {Number(t.match_confidence).toFixed(1)}%
                            </span>
                          ) : (
                            <span className="text-muted small">—</span>
                          )}
                        </td>
                        <td className="text-end">
                          <button
                            type="button"
                            className="btn btn-sm btn-outline-secondary me-1"
                            onClick={() => handleSuggestMatches(t.id)}
                            disabled={suggestingForId === t.id}
                          >
                            {suggestingForId === t.id ? (
                              <>
                                <span
                                  className="spinner-border spinner-border-sm me-1"
                                  role="status"
                                />
                                Suggestions…
                              </>
                            ) : (
                              <>
                                <i className="fa-solid fa-wand-magic-sparkles me-1" />
                                Suggestions
                              </>
                            )}
                          </button>
                          {/* Later: add "Link to…" buttons to save chosen match */}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
              <div className="small text-muted mt-1">
                * Balance column uses the running balance from the original bank
                statement (if available).
              </div>
            </div>
          )}

          {/* Suggestions panel */}
          {suggestions && (
            <div className="mt-3 border-top pt-2">
              <h6 className="mb-1">
                Suggestions for{" "}
                <span className="fw-semibold">
                  {suggestions.transaction_description}
                </span>{" "}
                <span className="text-muted">
                  ({suggestions.transaction_date},{" "}
                  {suggestions.transaction_amount})
                </span>
              </h6>
              {suggestError && (
                <div className="alert alert-danger py-2 my-2">
                  {suggestError}
                </div>
              )}
              {(!suggestions.candidates ||
                suggestions.candidates.length === 0) && (
                <p className="small text-muted mb-0">
                  No strong matches found. You can still manually assign this
                  transaction in the future.
                </p>
              )}
              {suggestions.candidates && suggestions.candidates.length > 0 && (
                <div className="table-responsive mt-2">
                  <table className="table table-sm mb-0">
                    <thead>
                      <tr>
                        <th>Type</th>
                        <th>Ref</th>
                        <th>Date</th>
                        <th className="text-end">Amount</th>
                        <th style={{ width: 120 }} className="text-end">
                          Score
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {suggestions.candidates.map((c) => (
                        <tr key={`${c.type}-${c.id}`}>
                          <td className="text-capitalize">{c.type}</td>
                          <td>
                            {c.type === "order"
                              ? c.order_number
                              : c.description}
                          </td>
                          <td>
                            {c.type === "order"
                              ? c.order_date
                              : c.date || "—"}
                          </td>
                          <td className="text-end">{c.amount}</td>
                          <td className="text-end">
                            <span className="badge bg-info-subtle text-info">
                              {c.score.toFixed(1)}%
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}