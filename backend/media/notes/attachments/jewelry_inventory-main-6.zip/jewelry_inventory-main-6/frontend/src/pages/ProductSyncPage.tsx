// frontend/src/pages/ProductSyncPage.tsx
import { FormEvent, useEffect, useState } from "react";
import { apiGet, apiPost } from "../api/client";

type StoreIntegration = {
  id: number;
  platform: string;
  name: string;
  base_url: string;
  is_active: boolean;
  last_synced_at: string | null;
};

type SyncDirection = "pull" | "push" | "two-way";

type Status =
  | { kind: "success"; message: string }
  | { kind: "error"; message: string }
  | null;

export default function ProductSyncPage() {
  const [stores, setStores] = useState<StoreIntegration[]>([]);
  const [loadingStores, setLoadingStores] = useState(false);
  const [storesError, setStoresError] = useState<string | null>(null);

  const [selectedStoreId, setSelectedStoreId] = useState<number | null>(null);
  const [direction, setDirection] = useState<SyncDirection>("pull");

  const [syncing, setSyncing] = useState(false);
  const [syncStatus, setSyncStatus] = useState<Status>(null);

  const [settingActiveId, setSettingActiveId] = useState<number | null>(null);
  const [activeStatus, setActiveStatus] = useState<Status>(null);

  useEffect(() => {
    void loadStores();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function loadStores() {
    setLoadingStores(true);
    setStoresError(null);
    try {
      const data = await apiGet<StoreIntegration[]>("/api/integrations/stores/");
      setStores(data);

      // Auto-select the active store if there is one,
      // otherwise fall back to the first store.
      if (!selectedStoreId && data.length > 0) {
        const active = data.find((s) => s.is_active);
        setSelectedStoreId((active ?? data[0]).id);
      }
    } catch (err: any) {
      console.error(err);
      setStoresError(err?.message || "Failed to load store integrations.");
    } finally {
      setLoadingStores(false);
    }
  }

  const activeStoreId =
    stores.find((s) => s.is_active)?.id ?? null;

  async function handleSetActive(storeId: number) {
    setActiveStatus(null);
    setSettingActiveId(storeId);

    // Capture the store name before we reload
    const store = stores.find((s) => s.id === storeId);

    try {
      // Backend action we’ll add: POST /api/integrations/stores/:id/set-active/
      await apiPost<StoreIntegration>(
        `/api/integrations/stores/${storeId}/set-active/`,
        {}
      );

      await loadStores();

      setActiveStatus({
        kind: "success",
        message: `Active integration set to "${store?.name ?? "store"}".`,
      });
    } catch (err: any) {
      console.error(err);
      setActiveStatus({
        kind: "error",
        message: err?.message || "Failed to set active integration.",
      });
    } finally {
      setSettingActiveId(null);
    }
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setSyncStatus(null);

    if (!selectedStoreId) {
      setSyncStatus({
        kind: "error",
        message: "Select a store integration first.",
      });
      return;
    }

    setSyncing(true);
    try {
      // Backend action we’ll add: POST /api/integrations/stores/:id/sync-products/
      const res = await apiPost<{
        detail: string;
        products_created: number;
        products_updated: number;
      }>(`/api/integrations/stores/${selectedStoreId}/sync-products/`, {
        direction,
      });

      setSyncStatus({
        kind: "success",
        message: `${res.detail} Created: ${res.products_created}, updated: ${res.products_updated}.`,
      });
    } catch (err: any) {
      console.error(err);
      setSyncStatus({
        kind: "error",
        message: err?.message || "Product sync failed.",
      });
    } finally {
      setSyncing(false);
    }
  }

  return (
    <div className="container py-4">
      <div className="row justify-content-center">
        <div className="col-lg-10 col-xl-8">
          <h1 className="h3 mb-3">Product sync from online store</h1>
          <p className="text-muted mb-4">
            Choose which store integration is active and pull products from
            your WooCommerce shop into your local inventory.
          </p>

          {/* STEP 1 – Active integration */}
          <div className="card mb-3">
            <div className="card-body">
              <h2 className="h6 mb-3">Step 1 – Choose active integration</h2>

              {loadingStores && (
                <div className="text-muted small mb-2">Loading stores…</div>
              )}

              {storesError && (
                <div className="alert alert-danger py-2 mb-3">
                  {storesError}
                </div>
              )}

              {!loadingStores && !storesError && stores.length === 0 && (
                <div className="alert alert-warning py-2 mb-0">
                  No store integrations found. Add one in the Django admin
                  under <code>Store integrations</code>.
                </div>
              )}

              {stores.length > 0 && (
                <div className="list-group">
                  {stores.map((store) => (
                    <button
                      key={store.id}
                      type="button"
                      className={
                        "list-group-item list-group-item-action d-flex justify-content-between align-items-center" +
                        (selectedStoreId === store.id ? " active" : "")
                      }
                      onClick={() => setSelectedStoreId(store.id)}
                    >
                      <div>
                        <div className="fw-semibold">
                          {store.name}{" "}
                          <span className="badge bg-light text-muted ms-2">
                            {store.platform}
                          </span>
                        </div>
                        <div className="small text-muted">
                          {store.base_url}
                        </div>
                        {store.last_synced_at && (
                          <div className="small text-muted">
                            Last synced:{" "}
                            {new Date(
                              store.last_synced_at
                            ).toLocaleString()}
                          </div>
                        )}
                      </div>

                      <div className="text-end">
                        {store.is_active && (
                          <span className="badge bg-success mb-1">
                            Active
                          </span>
                        )}
                        {!store.is_active && (
                          <button
                            type="button"
                            className="btn btn-outline-secondary btn-sm"
                            onClick={(event) => {
                              event.stopPropagation();
                              void handleSetActive(store.id);
                            }}
                            disabled={settingActiveId === store.id}
                          >
                            {settingActiveId === store.id
                              ? "Setting…"
                              : "Set active"}
                          </button>
                        )}
                      </div>
                    </button>
                  ))}
                </div>
              )}

              {activeStatus && (
                <div
                  className={
                    "alert mt-3 py-2 small " +
                    (activeStatus.kind === "success"
                      ? "alert-success"
                      : "alert-danger")
                  }
                >
                  {activeStatus.message}
                </div>
              )}
            </div>
          </div>

          {/* STEP 2 – Sync config + run */}
          <form onSubmit={handleSubmit}>
            <div className="card mb-3">
              <div className="card-body">
                <h2 className="h6 mb-3">Step 2 – Configure sync</h2>

                <div className="mb-3">
                  <label className="form-label">Sync direction</label>
                  <select
                    className="form-select"
                    value={direction}
                    onChange={(e) =>
                      setDirection(e.target.value as SyncDirection)
                    }
                  >
                    <option value="pull">
                      Pull from online store → local
                    </option>
                    <option value="push" disabled>
                      Push local → online (coming later)
                    </option>
                    <option value="two-way" disabled>
                      Two-way sync (coming later)
                    </option>
                  </select>
                  <div className="form-text">
                    Currently only <strong>pull</strong> from WooCommerce is
                    implemented in the backend.
                  </div>
                </div>
              </div>
            </div>

            <div className="d-flex align-items-center">
              <button
                type="submit"
                className="btn btn-dark"
                disabled={
                  syncing ||
                  loadingStores ||
                  !selectedStoreId ||
                  stores.length === 0
                }
              >
                {syncing ? "Syncing products…" : "Sync products"}
              </button>
              {selectedStoreId && (
                <span className="ms-3 text-muted small">
                  Selected store ID: {selectedStoreId}
                  {activeStoreId && activeStoreId === selectedStoreId
                    ? " (active)"
                    : ""}
                </span>
              )}
            </div>
          </form>

          {syncStatus && (
            <div
              className={
                "alert mt-3 py-2 small " +
                (syncStatus.kind === "success"
                  ? "alert-success"
                  : "alert-danger")
              }
            >
              {syncStatus.message}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}