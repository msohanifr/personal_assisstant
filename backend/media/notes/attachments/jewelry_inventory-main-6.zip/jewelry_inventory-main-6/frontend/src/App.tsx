import {
  Routes,
  Route,
  NavLink,
  useNavigate,
  useLocation,
  Navigate,
} from "react-router-dom";
import { useEffect, useState } from "react";

import DashboardPage from "./pages/DashboardPage";
import ScanPage from "./pages/ScanPage";
import LoginPage from "./pages/LoginPage";
import RequireAuth from "./components/RequireAuth";
import { apiPost, apiGet } from "./api/client";
import ExpensesPage from "./pages/ExpensesPage";
import TaxesPage from "./pages/TaxesPage";
import ProfilePage from "./pages/ProfilePage";
import LabelsPage from "./pages/LabelsPage";
import ProductListPage from "./pages/ProductListPage";
import ProductDetailPage from "./pages/ProductDetailPage";
import ProductSyncPage from "./pages/ProductSyncPage";
import LocationDashboardPage from "./pages/LocationDashboardPage";
import SalesPage from "./pages/SalesPage";
import BankTransactionsPage from "./pages/BankTransactionsPage";
import RepairsPage from "./pages/RepairsPage";
import ContactsPage from "./pages/ContactsPage";

type MeResponse = {
  username: string;
  is_staff: boolean;
  is_superuser: boolean;
  // optional custom flag you can add on the backend later
  is_accounting?: boolean;
};

export default function App() {
  return (
    <>
      {/* /login has no navbar/sidebar */}
      <Routes>
        <Route path="/login" element={<LoginPage />} />

        {/* Protected application layout */}
        <Route
          path="/*"
          element={
            <RequireAuth>
              <AppLayout />
            </RequireAuth>
          }
        />
      </Routes>
    </>
  );
}

/** Main layout (navbar + sidebar + content) */
function AppLayout() {
  const navigate = useNavigate();
  const location = useLocation();

  // current user info (for permissions like "accounting")
  const [me, setMe] = useState<MeResponse | null>(null);
  const [meLoading, setMeLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;

    async function loadMe() {
      try {
        const res = await apiGet<MeResponse>("/api/auth/me/");
        if (!cancelled) {
          setMe(res);
        }
      } catch (err) {
        console.error("Failed to load current user", err);
      } finally {
        if (!cancelled) {
          setMeLoading(false);
        }
      }
    }

    loadMe();
    return () => {
      cancelled = true;
    };
  }, []);

  // who is allowed to see accounting?
  const isAccounting =
    (me as any)?.is_accounting ?? (me?.is_staff || me?.is_superuser) ?? false;

  async function handleLogout() {
    try {
      await apiPost("/api/auth/logout/");
    } catch (err) {
      console.error("Logout error:", err);
    }
    navigate("/login", { replace: true });
  }

  // Open sections based on current route
  const isProductRoute = location.pathname.startsWith("/products");
  const isSalesRoute = location.pathname.startsWith("/sales");
  const isStockRoute = location.pathname.startsWith("/stock");

  const [productOpen, setProductOpen] = useState<boolean>(isProductRoute);
  const [salesOpen, setSalesOpen] = useState<boolean>(isSalesRoute);
  const [stockOpen, setStockOpen] = useState<boolean>(isStockRoute);

  useEffect(() => {
    if (location.pathname.startsWith("/products")) {
      setProductOpen(true);
    }
    if (location.pathname.startsWith("/sales")) {
      setSalesOpen(true);
    }
    if (location.pathname.startsWith("/stock")) {
      setStockOpen(true);
    }
  }, [location.pathname]);

  return (
    <>
      {/* Top navbar */}
      <nav className="navbar navbar-light bg-white border-bottom sticky-top">
        <div className="container-fluid">
          <button
            className="btn btn-outline-secondary d-lg-none"
            type="button"
            data-bs-toggle="offcanvas"
            data-bs-target="#offcanvasSidebar"
          >
            <i className="fa-solid fa-bars" />
          </button>

          <span className="navbar-brand ms-2 me-auto">
            Inventory Workspace
          </span>

          <NavLink
            to="/profile"
            className={({ isActive }) =>
              "nav-link d-flex align-items-center text-secondary" +
              (isActive ? " fw-bold" : "")
            }
          >
            <i className="fa-solid fa-user me-1" />
            <span>Profile</span>
          </NavLink>
        </div>
      </nav>

      {/* Sidebar */}
      <div
        className="offcanvas offcanvas-start bg-dark text-light"
        tabIndex={-1}
        id="offcanvasSidebar"
      >
        <div className="offcanvas-header">
          <h5 className="sidebar-logo text-light">MARYSA</h5>
          <button
            type="button"
            className="btn-close btn-close-white"
            data-bs-dismiss="offcanvas"
          ></button>
        </div>

        <div className="offcanvas-body d-flex flex-column">
          {/* MAIN */}
          <small className="text-muted text-uppercase">Main</small>
          <ul className="nav flex-column mb-3">
            <li className="nav-item">
              <NavLink
                to="/"
                end
                className={({ isActive }) =>
                  "nav-link text-light" + (isActive ? " fw-bold" : "")
                }
              >
                <i className="fa-solid fa-house me-2" />
                Dashboard
              </NavLink>
            </li>

            <li className="nav-item">
              <NavLink
                to="/contacts"
                className={({ isActive }) =>
                  "nav-link text-light" + (isActive ? " fw-bold" : "")
                }
              >
                <i className="fa-solid fa-id-card me-2" />
                Contacts
              </NavLink>
            </li>
          </ul>

          {/* PRODUCTS */}
          <small className="text-muted text-uppercase">Products</small>
          <ul className="nav flex-column mb-3">
            <li className="nav-item mt-1">
              {/* Parent row */}
              <button
                type="button"
                className="nav-link d-flex align-items-center justify-content-between text-light w-100 border-0 bg-transparent px-2"
                onClick={() => setProductOpen((open) => !open)}
              >
                <span>
                  <i className="fa-solid fa-tag me-2" />
                  Products
                </span>
                <i
                  className={
                    "fa-solid fa-chevron-down small" +
                    (productOpen ? " rotate-180" : "")
                  }
                />
              </button>

              {/* Children */}
              <ul
                className={
                  "nav flex-column ms-3 mt-1" + (productOpen ? "" : " d-none")
                }
              >
                <li className="nav-item">
                  <NavLink
                    to="/products"
                    end
                    className={({ isActive }) =>
                      "nav-link py-1 text-light small" +
                      (isActive ? " fw-bold" : "")
                    }
                  >
                    Product list
                  </NavLink>
                </li>

                <li className="nav-item">
                  <NavLink
                    to="/products/sync"
                    className={({ isActive }) =>
                      "nav-link py-1 text-light small" +
                      (isActive ? " fw-bold" : "")
                    }
                  >
                    Product sync
                  </NavLink>
                </li>
              </ul>
            </li>
          </ul>

          {/* ACCOUNTING (only for accounting users) */}
          {isAccounting && !meLoading && (
            <>
              <small className="text-muted text-uppercase">Accounting</small>
              <ul className="nav flex-column mb-3">
                <li className="nav-item">
                  <NavLink
                    to="/banking/transactions"
                    className={({ isActive }) =>
                      "nav-link d-flex align-items-center text-light px-2" +
                      (isActive ? " active fw-semibold" : "")
                    }
                  >
                    <i className="fa-solid fa-building-columns me-2" />
                    <span>Bank transactions</span>
                  </NavLink>
                </li>
              </ul>
            </>
          )}

          {/* SALES */}
          <small className="text-muted text-uppercase">Sales</small>
          <ul className="nav flex-column mb-3">
            <li className="nav-item">
              <button
                type="button"
                className="nav-link d-flex align-items-center justify-content-between text-light w-100 border-0 bg-transparent px-2"
                onClick={() => setSalesOpen((open) => !open)}
              >
                <span>
                  <i className="fa-solid fa-cart-shopping me-2" />
                  Sales
                </span>
                <i
                  className={
                    "fa-solid fa-chevron-down small" +
                    (salesOpen ? " rotate-180" : "")
                  }
                />
              </button>

              <ul
                className={
                  "nav flex-column ms-3 mt-1" + (salesOpen ? "" : " d-none")
                }
              >
                <li className="nav-item">
                  <NavLink
                    to="/sales"
                    end
                    className={({ isActive }) =>
                      "nav-link py-1 text-light small" +
                      (isActive ? " fw-bold" : "")
                    }
                  >
                    Sales
                  </NavLink>
                </li>

                <li className="nav-item">
                  <NavLink
                    to="/sales/repairs"
                    className={({ isActive }) =>
                      "nav-link py-1 text-light small" +
                      (isActive ? " fw-bold" : "")
                    }
                  >
                    Repairs
                  </NavLink>
                </li>

                <li className="nav-item">
                  <NavLink
                    to="/sales/creations"
                    className={({ isActive }) =>
                      "nav-link py-1 text-light small" +
                      (isActive ? " fw-bold" : "")
                    }
                  >
                    Creations
                  </NavLink>
                </li>

                <li className="nav-item">
                  <NavLink
                    to="/sales/memos"
                    className={({ isActive }) =>
                      "nav-link py-1 text-light small" +
                      (isActive ? " fw-bold" : "")
                    }
                  >
                    Memos
                  </NavLink>
                </li>

                <li className="nav-item">
                  <NavLink
                    to="/sales/quotes"
                    className={({ isActive }) =>
                      "nav-link py-1 text-light small" +
                      (isActive ? " fw-bold" : "")
                    }
                  >
                    Quotes
                  </NavLink>
                </li>

                <li className="nav-item d-flex align-items-center">
                  <NavLink
                    to="/sales/workshop-planning"
                    className={({ isActive }) =>
                      "nav-link py-1 text-light small flex-grow-1" +
                      (isActive ? " fw-bold" : "")
                    }
                  >
                    Workshop planning
                  </NavLink>
                  <span className="badge bg-primary ms-1 small">New</span>
                </li>
              </ul>
            </li>
          </ul>

          {/* STOCK */}
          <small className="text-muted text-uppercase">Stock</small>
          <ul className="nav flex-column mb-3">
            <li className="nav-item">
              <button
                type="button"
                className="nav-link d-flex align-items-center justify-content-between text-light w-100 border-0 bg-transparent px-2"
                onClick={() => setStockOpen((open) => !open)}
              >
                <span>
                  <i className="fa-solid fa-boxes-stacked me-2" />
                  Stock
                </span>
                <i
                  className={
                    "fa-solid fa-chevron-down small" +
                    (stockOpen ? " rotate-180" : "")
                  }
                />
              </button>

              <ul
                className={
                  "nav flex-column ms-3 mt-1" + (stockOpen ? "" : " d-none")
                }
              >
                <li className="nav-item">
                  <NavLink
                    to="/locations"
                    className={({ isActive }) =>
                      "nav-link text-light" + (isActive ? " fw-bold" : "")
                    }
                  >
                    <i className="fa-solid fa-location-dot" /> Locations
                  </NavLink>
                </li>

                <li className="nav-item">
                  <NavLink
                    to="/stock/supplier-orders"
                    className={({ isActive }) =>
                      "nav-link py-1 text-light small" +
                      (isActive ? " fw-bold" : "")
                    }
                  >
                    Supplier orders
                  </NavLink>
                </li>

                <li className="nav-item">
                  <NavLink
                    to="/stock/materials"
                    className={({ isActive }) =>
                      "nav-link py-1 text-light small" +
                      (isActive ? " fw-bold" : "")
                    }
                  >
                    Materials
                  </NavLink>
                </li>

                <li className="nav-item">
                  <NavLink
                    to="/stock/inventory-counts"
                    className={({ isActive }) =>
                      "nav-link py-1 text-light small" +
                      (isActive ? " fw-bold" : "")
                    }
                  >
                    Inventory counts
                  </NavLink>
                </li>

                <li className="nav-item">
                  <NavLink
                    to="/stock/incoming-memos"
                    className={({ isActive }) =>
                      "nav-link py-1 text-light small" +
                      (isActive ? " fw-bold" : "")
                    }
                  >
                    Incoming memos
                  </NavLink>
                </li>

                <li className="nav-item">
                  <NavLink
                    to="/stock/purchases"
                    className={({ isActive }) =>
                      "nav-link py-1 text-light small" +
                      (isActive ? " fw-bold" : "")
                    }
                  >
                    Purchases
                  </NavLink>
                </li>

                <li className="nav-item">
                  <NavLink
                    to="/stock/categories"
                    className={({ isActive }) =>
                      "nav-link py-1 text-light small" +
                      (isActive ? " fw-bold" : "")
                    }
                  >
                    Categories
                  </NavLink>
                </li>

                <li className="nav-item">
                  <NavLink
                    to="/stock/brands"
                    className={({ isActive }) =>
                      "nav-link py-1 text-light small" +
                      (isActive ? " fw-bold" : "")
                    }
                  >
                    Brands
                  </NavLink>
                </li>
              </ul>
            </li>
          </ul>

          {/* TOOLS / OTHER */}
          <small className="text-muted text-uppercase">Tools</small>
          <ul className="nav flex-column mb-3">
            <li className="nav-item">
              <NavLink
                to="/scan"
                className={({ isActive }) =>
                  "nav-link text-light" + (isActive ? " fw-bold" : "")
                }
              >
                <i className="fa-solid fa-barcode me-2" />
                Scan / Lookup
              </NavLink>
            </li>

            <li className="nav-item">
              <NavLink
                to="/labels"
                className={({ isActive }) =>
                  "nav-link text-light" + (isActive ? " fw-bold" : "")
                }
              >
                <i className="fa-solid fa-tags me-2" />
                Print labels
              </NavLink>
            </li>

            <li className="nav-item">
              <NavLink
                to="/taxes"
                className={({ isActive }) =>
                  "nav-link text-light" + (isActive ? " fw-bold" : "")
                }
              >
                <i className="fa-solid fa-scale-balanced me-2" />
                Taxes
              </NavLink>
            </li>

            <li className="nav-item">
              <a href="/admin/" className="nav-link text-light">
                <i className="fa-solid fa-gear me-2" />
                Admin
              </a>
            </li>
          </ul>

          {/* Sidebar footer */}
          <div className="mt-auto pt-3 border-top border-secondary">
            <div className="text-light mb-2">Signed in</div>
            <button
              type="button"
              onClick={handleLogout}
              className="btn btn-outline-light btn-sm w-100"
            >
              <i className="fa-solid fa-right-from-bracket me-1" />
              Log out
            </button>
          </div>
        </div>
      </div>

      {/* Main content */}
      <div className="content-wrapper">
        <Routes>
          {/* existing pages */}
          <Route path="/" element={<DashboardPage />} />
          <Route path="/scan" element={<ScanPage />} />
          <Route path="/expenses" element={<ExpensesPage />} />
          <Route path="/taxes" element={<TaxesPage />} />
          <Route path="/profile" element={<ProfilePage />} />
          <Route path="/labels" element={<LabelsPage />} />
          <Route path="/products" element={<ProductListPage />} />
          <Route path="/products/:id" element={<ProductDetailPage />} />
          <Route path="/products/sync" element={<ProductSyncPage />} />

          {/* new placeholder routes – replace with real pages later */}
          <Route path="/contacts" element={<ContactsPage />} />

          <Route path="/sales" element={<SalesPage />} />
          <Route path="/sales/repairs" element={<RepairsPage />} />
          <Route
            path="/sales/creations"
            element={<div className="p-3">Creations coming soon…</div>}
          />
          <Route
            path="/sales/memos"
            element={<div className="p-3">Memos coming soon…</div>}
          />
          <Route
            path="/sales/quotes"
            element={<div className="p-3">Quotes coming soon…</div>}
          />
          <Route
            path="/sales/workshop-planning"
            element={
              <div className="p-3">Workshop planning coming soon…</div>
            }
          />

          <Route
            path="/banking/transactions"
            element={
              meLoading ? (
                <div className="p-3">Loading profile…</div>
              ) : isAccounting ? (
                <BankTransactionsPage />
              ) : (
                <Navigate to="/" replace />
              )
            }
          />

          <Route
            path="/stock/locations"
            element={<div className="p-3">Locations coming soon…</div>}
          />
          <Route
            path="/stock/supplier-orders"
            element={
              <div className="p-3">Supplier orders coming soon…</div>
            }
          />
          <Route
            path="/stock/materials"
            element={<div className="p-3">Materials coming soon…</div>}
          />
          <Route
            path="/stock/inventory-counts"
            element={
              <div className="p-3">Inventory counts coming soon…</div>
            }
          />
          <Route
            path="/stock/incoming-memos"
            element={
              <div className="p-3">Incoming memos coming soon…</div>
            }
          />
          <Route
            path="/stock/purchases"
            element={<div className="p-3">Purchases coming soon…</div>}
          />
          <Route
            path="/stock/categories"
            element={<div className="p-3">Categories coming soon…</div>}
          />
          <Route
            path="/stock/brands"
            element={<div className="p-3">Brands coming soon…</div>}
          />
          <Route path="/locations" element={<LocationDashboardPage />} />
        </Routes>
      </div>
    </>
  );
}