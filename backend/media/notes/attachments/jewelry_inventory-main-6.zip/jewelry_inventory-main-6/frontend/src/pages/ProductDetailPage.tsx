import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { apiGet } from "../api/client";

type ProductVariantDetail = {
  id: number;
  sku: string;
  size?: string | null;
  color?: string | null;
  stock_quantity?: number | null;
  barcode?: string | null;
  [key: string]: any;
};

type ProductDetail = {
  id: number;
  name: string;
  slug?: string;
  sku_base?: string;
  gold_purity?: string | null;
  description?: string | null;
  active?: boolean;
  primary_image_url?: string | null; // from ProductSerializer.get_main_image_url
  woo_data?: any | null; // raw JSON from WooCommerce
  variants?: ProductVariantDetail[];
  [key: string]: any;
};

function getProductImageUrl(p: ProductDetail): string | null {
  return (
    (p.main_image_url as string | undefined) ||
    (p.primary_image_url as string | undefined) || // from Woo
    (p.image_url as string | undefined) ||
    (p.image as string | undefined) ||
    null
  );
}

// Helper to read meta_data values like rank_math_title, rank_math_description, etc.
function getWooMetaValue(
  woo: any | null | undefined,
  key: string
): string | undefined {
  if (!woo || !Array.isArray(woo.meta_data)) return undefined;
  const item = woo.meta_data.find((m: any) => m && m.key === key);
  if (!item) return undefined;
  const value = item.value;
  if (value === null || value === undefined) return undefined;
  return typeof value === "string" ? value : JSON.stringify(value);
}

export default function ProductDetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();

  const [product, setProduct] = useState<ProductDetail | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Derived WooCommerce data for pretty cards
  const woo = product?.woo_data as any | null | undefined;
  const wooImages: any[] = Array.isArray(woo?.images) ? woo.images : [];
  const wooCategories: any[] = Array.isArray(woo?.categories)
    ? woo.categories
    : [];
  const seoTitle = getWooMetaValue(woo, "rank_math_title");
  const seoDescription = getWooMetaValue(woo, "rank_math_description");

  useEffect(() => {
    if (!id) return;
    void loadProduct(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  async function loadProduct(productId: string) {
    setLoading(true);
    setError(null);
    try {
      const data = await apiGet<ProductDetail>(
        `/api/catalog/products/${productId}/`
      );
      setProduct(data);
    } catch (err: any) {
      console.error(err);
      setError(err.message || "Failed to load product.");
    } finally {
      setLoading(false);
    }
  }

  if (!id) {
    return (
      <div className="container-fluid py-3">
        <div className="alert alert-danger">No product id in URL.</div>
      </div>
    );
  }

  return (
    <div className="container-fluid py-3">
      {/* Header */}
      <div className="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-3">
        <div className="mb-2 mb-md-0">
          <button
            type="button"
            className="btn btn-sm btn-link px-0 mb-1"
            onClick={() => navigate("/products")}
          >
            <i className="fa-solid fa-arrow-left me-1" />
            Back to product list
          </button>
          <h1 className="h4 mb-1">
            <i className="fa-solid fa-box-open me-2" />
            {product ? product.name : "Product detail"}
          </h1>
          <p className="text-muted small mb-0">
            View all product details and associated variants.
          </p>
        </div>
      </div>

      {error && (
        <div className="alert alert-danger py-2" role="alert">
          {error}
        </div>
      )}

      {loading && (
        <p className="text-muted small mb-0">Loading product…</p>
      )}

      {!loading && !product && !error && (
        <div className="alert alert-secondary py-2">Product not found.</div>
      )}

      {product && (
        <>
          {/* Top layout: image + product / Woo cards */}
          <div className="row g-3">
            {/* LEFT: product image + basic info */}
            <div className="col-lg-4">
              <div className="card shadow-sm border-0 mb-3">
                <div className="card-body">
                  <div className="d-flex flex-column align-items-center">
                    <div className="product-thumb mb-3">
                      {getProductImageUrl(product) ? (
                        <img
                          src={getProductImageUrl(product) as string}
                          alt={product.name}
                          className="product-thumb-img"
                        />
                      ) : (
                        <div className="product-thumb-placeholder">
                          {product.name
                            ? product.name.charAt(0).toUpperCase()
                            : "?"}
                        </div>
                      )}
                    </div>

                    <div className="text-center">
                      <h2 className="h5 mb-1">{product.name}</h2>
                      {product.sku_base && (
                        <div className="small text-muted mb-1">
                          Base SKU: {product.sku_base}
                        </div>
                      )}
                      {product.gold_purity && (
                        <div className="small mb-1">
                          Gold / purity:{" "}
                          <strong>{product.gold_purity}</strong>
                        </div>
                      )}
                      <div className="mt-2">
                        {typeof product.active === "boolean" ? (
                          product.active ? (
                            <span className="badge bg-success-subtle text-success">
                              Active
                            </span>
                          ) : (
                            <span className="badge bg-secondary-subtle text-muted">
                              Inactive
                            </span>
                          )
                        ) : null}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* RIGHT: Woo overview + settings */}
            <div className="col-lg-8">
              <div className="card shadow-sm border-0 mb-3">
                <div className="card-body">
                  <h2 className="h6 fw-semibold mb-3">
                    Product overview &amp; Woo data
                  </h2>

                  {/* Core product fields (aside from what’s already on the left) */}
                  <dl className="row small mb-0">
                    {product.slug && (
                      <>
                        <dt className="col-4 text-muted">Slug</dt>
                        <dd className="col-8 mb-1">{product.slug}</dd>
                      </>
                    )}
                    {product.id && (
                      <>
                        <dt className="col-4 text-muted">Local ID</dt>
                        <dd className="col-8 mb-1">{product.id}</dd>
                      </>
                    )}
                  </dl>

                  {woo && (
                    <>
                      <hr />
                      <div className="row g-3">
                        {/* Woo basics */}
                        <div className="col-md-6">
                          <div className="border rounded-3 p-3 h-100 bg-light-subtle">
                            <h6 className="fw-semibold mb-2 mb-md-3">
                              WooCommerce basics
                            </h6>
                            <dl className="row small mb-0">
                              {woo.id && (
                                <>
                                  <dt className="col-5 text-muted">Woo ID</dt>
                                  <dd className="col-7 mb-1">{woo.id}</dd>
                                </>
                              )}
                              {woo.slug && (
                                <>
                                  <dt className="col-5 text-muted">Slug</dt>
                                  <dd className="col-7 mb-1">{woo.slug}</dd>
                                </>
                              )}
                              {woo.status && (
                                <>
                                  <dt className="col-5 text-muted">Status</dt>
                                  <dd className="col-7 mb-1 text-capitalize">
                                    {woo.status}
                                  </dd>
                                </>
                              )}
                              {woo.type && (
                                <>
                                  <dt className="col-5 text-muted">Type</dt>
                                  <dd className="col-7 mb-1 text-capitalize">
                                    {woo.type}
                                  </dd>
                                </>
                              )}
                              {woo.stock_status && (
                                <>
                                  <dt className="col-5 text-muted">
                                    Stock status
                                  </dt>
                                  <dd className="col-7 mb-1 text-capitalize">
                                    {woo.stock_status}
                                  </dd>
                                </>
                              )}
                              {woo.catalog_visibility && (
                                <>
                                  <dt className="col-5 text-muted">
                                    Visibility
                                  </dt>
                                  <dd className="col-7 mb-1 text-capitalize">
                                    {woo.catalog_visibility}
                                  </dd>
                                </>
                              )}
                              {wooCategories.length > 0 && (
                                <>
                                  <dt className="col-5 text-muted">
                                    Categories
                                  </dt>
                                  <dd className="col-7 mb-0">
                                    {wooCategories
                                      .map((cat: any) => cat.name)
                                      .join(", ")}
                                  </dd>
                                </>
                              )}
                            </dl>
                          </div>
                        </div>

                        {/* SEO & copy */}
                        <div className="col-md-6">
                          <div className="border rounded-3 p-3 h-100 bg-light-subtle">
                            <h6 className="card-title fw-semibold mb-2 mb-md-3">
                              SEO &amp; marketing copy
                            </h6>

                            {seoTitle && (
                              <div className="mb-2">
                                <div className="text-muted small mb-1">
                                  SEO title
                                </div>
                                <div className="small">{seoTitle}</div>
                              </div>
                            )}

                            {seoDescription && (
                              <div className="mb-2">
                                <div className="text-muted small mb-1">
                                  SEO description
                                </div>
                                <div className="small text-muted">
                                  {seoDescription}
                                </div>
                              </div>
                            )}

                            {woo.short_description && (
                              <div className="small">
                                <div className="text-muted small mb-1">
                                  Short description
                                </div>
                                <div
                                  className="small"
                                  // Content comes from your own Woo site; if you ever allow 3rd-party
                                  // content, consider sanitizing this HTML.
                                  dangerouslySetInnerHTML={{
                                    __html: woo.short_description,
                                  }}
                                />
                              </div>
                            )}
                          </div>
                        </div>
                      </div>

                      {/* Images from Woo */}
                      {wooImages.length > 0 && (
                        <>
                          <hr />
                          <h6 className="fw-semibold mb-2">
                            Images from WooCommerce
                          </h6>
                          <div className="d-flex flex-wrap gap-2">
                            {wooImages.map((img: any, idx: number) => (
                              <div
                                key={img.id ?? idx}
                                className="border rounded-3 overflow-hidden"
                                style={{ width: 80, height: 80 }}
                              >
                                <img
                                  src={img.thumbnail || img.src}
                                  alt={img.alt || img.name || product.name}
                                  className="img-fluid w-100 h-100"
                                  style={{ objectFit: "cover" }}
                                />
                              </div>
                            ))}
                          </div>
                        </>
                      )}
                    </>
                  )}
                </div>
              </div>

              {/* Placeholder for future editable settings */}
              <div className="card shadow-sm border-0">
                <div className="card-body">
                  <h6 className="card-title fw-semibold mb-2">
                    Product settings (read-only for now)
                  </h6>
                  <p className="small text-muted mb-0">
                    This panel is ready for editing fields like collection,
                    default supplier, tagging, etc. Once your API for updating
                    products is ready, we can wire it up with a simple form and
                    PATCH/PUT calls.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Variants section moved to bottom, full-width */}
          <div className="card shadow-sm border-0 mt-3">
            <div className="card-body">
              <h5 className="card-title fw-semibold mb-2">Variants</h5>
              <p className="text-muted small mb-3">
                Individual SKUs under this product, with size, color, and stock.
              </p>

              {(!product.variants || product.variants.length === 0) && (
                <p className="small text-muted mb-0">
                  No variants linked to this product yet.
                </p>
              )}

              {product.variants && product.variants.length > 0 && (
                <div className="table-responsive">
                  <table className="table table-sm table-striped align-middle mb-0">
                    <thead className="table-light">
                      <tr>
                        <th>SKU</th>
                        <th>Size / color</th>
                        <th style={{ width: 100 }}>Stock</th>
                        <th style={{ width: 140 }}>Barcode</th>
                      </tr>
                    </thead>
                    <tbody>
                      {product.variants.map((v) => (
                        <tr key={v.id}>
                          <td>
                            <code>{v.sku}</code>
                          </td>
                          <td>
                            <span className="small">
                              {v.size || "—"}
                              {v.color && ` · ${v.color}`}
                            </span>
                          </td>
                          <td>
                            <span className="small">
                              {typeof v.stock_quantity === "number"
                                ? v.stock_quantity
                                : "—"}
                            </span>
                          </td>
                          <td>
                            <span className="small text-muted">
                              {v.barcode || "—"}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        </>
      )}
    </div>
  );
}