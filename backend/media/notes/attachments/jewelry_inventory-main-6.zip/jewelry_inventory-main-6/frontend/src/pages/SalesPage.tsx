// frontend/src/pages/SalesPage.tsx
import { type FormEvent, useEffect, useState } from "react";
import { apiGet, apiPost } from "../api/client";

type SalesRecord = {
  id: number;
  sale_date: string;
  channel: string;
  location?: number | null;
  customer?: number | null;
  variant_id: number;
  sku: string;
  product_name: string;
  quantity: number;
  unit_price: string;
  discount_amount: string;
  total: string;
  notes: string;
};

type NewSaleForm = {
  variant_sku: string;
  sale_date: string;
  channel: string;
  quantity: number;
  unit_price: string;
  discount_amount: string;
  notes: string;
};

const EMPTY_FORM: NewSaleForm = {
  variant_sku: "",
  sale_date: "",
  channel: "store",
  quantity: 1,
  unit_price: "",
  discount_amount: "0.00",
  notes: "",
};

export default function SalesPage() {
  const [sales, setSales] = useState<SalesRecord[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [startDate, setStartDate] = useState<string>("");
  const [endDate, setEndDate] = useState<string>("");

  const [form, setForm] = useState<NewSaleForm>(EMPTY_FORM);
  const [formError, setFormError] = useState<string | null>(null);
  const [formSubmitting, setFormSubmitting] = useState(false);

  useEffect(() => {
    void loadSales();
  }, []);

  async function loadSales(params?: { start?: string; end?: string }) {
    setLoading(true);
    setError(null);
    try {
      const query: string[] = [];
      if (params?.start) {
        query.push(`start_date=${encodeURIComponent(params.start)}`);
      }
      if (params?.end) {
        query.push(`end_date=${encodeURIComponent(params.end)}`);
      }
      const qs = query.length ? `?${query.join("&")}` : "";

      const data = await apiGet<SalesRecord[]>(`/api/sales/records/${qs}`);
      setSales(data);
    } catch (err: any) {
      console.error(err);
      setError(err.message || "Failed to load sales records.");
    } finally {
      setLoading(false);
    }
  }

  function handleFilterSubmit(e: FormEvent) {
    e.preventDefault();
    void loadSales({ start: startDate, end: endDate });
  }

  function handleFormChange(
    e: React.ChangeEvent<
      HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement
    >
  ) {
    const { name, value } = e.target;
    setForm((prev) => ({
      ...prev,
      [name]: name === "quantity" ? Number(value) : value,
    }));
  }

  async function handleFormSubmit(e: FormEvent) {
    e.preventDefault();
    setFormError(null);
    setFormSubmitting(true);

    try {
      const payload = {
        ...form,
        // if sale_date left empty, let backend default to now
        sale_date: form.sale_date || new Date().toISOString(),
        quantity: form.quantity || 1,
      };

      await apiPost<SalesRecord>("/api/sales/records/", payload);

      // Reset form, reload recent sales
      setForm(EMPTY_FORM);
      await loadSales();
    } catch (err: any) {
      console.error(err);
      setFormError(err.message || "Failed to create sale.");
    } finally {
      setFormSubmitting(false);
    }
  }

  // --- Simple derived KPIs (like the Repairs page uses stats) ---

  let totalRevenue = 0;
  let totalUnits = 0;

  sales.forEach((s) => {
    const total = Number(s.total);
    const qty = Number(s.quantity);
    if (!isNaN(total)) totalRevenue += total;
    if (!isNaN(qty)) totalUnits += qty;
  });

  const salesCount = sales.length;
  const avgTicket =
    salesCount > 0 ? totalRevenue / salesCount : 0;

  return (
    <div className="container-fluid py-3">
      {/* Header */}
      <div className="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-3">
        <div className="mb-2 mb-md-0">
          <h1 className="h4 mb-1">
            <i className="fa-solid fa-receipt me-2" />
            Sales
          </h1>
          <p className="text-muted small mb-0">
            Record jewelry sales by SKU to keep your revenue and stock in sync.
          </p>
        </div>
      </div>

      {/* KPIs */}
      <div className="card shadow-sm border-0 mb-3">
        <div className="card-body py-3">
          <div className="row g-3">
            <div className="col-6 col-md-3">
              <div className="small text-muted text-uppercase mb-1">
                Total revenue
              </div>
              <div className="h5 mb-0">
                ${totalRevenue.toLocaleString(undefined, {
                  maximumFractionDigits: 2,
                })}
              </div>
            </div>
            <div className="col-6 col-md-3">
              <div className="small text-muted text-uppercase mb-1">
                Number of sales
              </div>
              <div className="h5 mb-0">
                {salesCount}
              </div>
            </div>
            <div className="col-6 col-md-3">
              <div className="small text-muted text-uppercase mb-1">
                Units sold
              </div>
              <div className="h5 mb-0">
                {totalUnits}
              </div>
            </div>
            <div className="col-6 col-md-3">
              <div className="small text-muted text-uppercase mb-1">
                Avg ticket
              </div>
              <div className="h5 mb-0">
                ${avgTicket.toLocaleString(undefined, {
                  maximumFractionDigits: 2,
                })}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Filters + Add form */}
      <div className="row">
        {/* Filters */}
        <div className="col-lg-7 mb-3">
          <div className="card shadow-sm border-0">
            <div className="card-body">
              <h5 className="card-title mb-3">Filter sales</h5>
              <form className="row g-2" onSubmit={handleFilterSubmit}>
                <div className="col-md-4">
                  <label className="form-label mb-1">Start date</label>
                  <input
                    type="date"
                    className="form-control form-control-sm"
                    value={startDate}
                    onChange={(e) => setStartDate(e.target.value)}
                  />
                </div>
                <div className="col-md-4">
                  <label className="form-label mb-1">End date</label>
                  <input
                    type="date"
                    className="form-control form-control-sm"
                    value={endDate}
                    onChange={(e) => setEndDate(e.target.value)}
                  />
                </div>
                <div className="col-md-4 d-flex align-items-end">
                  <button
                    type="submit"
                    className="btn btn-sm btn-outline-primary w-100"
                    disabled={loading}
                  >
                    Apply filters
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>

        {/* Add sale form */}
        <div className="col-lg-5 mb-3">
          <div className="card shadow-sm border-0">
            <div className="card-body">
              <h5 className="card-title mb-3">Add sale</h5>
              {formError && (
                <div className="alert alert-danger py-2">{formError}</div>
              )}

              <form className="row g-2" onSubmit={handleFormSubmit}>
                <div className="col-md-4">
                  <label className="form-label mb-1">SKU</label>
                  <input
                    type="text"
                    className="form-control form-control-sm"
                    name="variant_sku"
                    value={form.variant_sku}
                    onChange={handleFormChange}
                    placeholder="e.g. RING-0001-14YG"
                    required
                  />
                </div>

                <div className="col-md-3">
                  <label className="form-label mb-1">Quantity</label>
                  <input
                    type="number"
                    min={1}
                    className="form-control form-control-sm"
                    name="quantity"
                    value={form.quantity}
                    onChange={handleFormChange}
                  />
                </div>

                <div className="col-md-5">
                  <label className="form-label mb-1">Unit price</label>
                  <input
                    type="number"
                    step="0.01"
                    className="form-control form-control-sm"
                    name="unit_price"
                    value={form.unit_price}
                    onChange={handleFormChange}
                    placeholder="e.g. 450"
                    required
                  />
                </div>

                <div className="col-md-4">
                  <label className="form-label mb-1">Discount (total)</label>
                  <input
                    type="number"
                    step="0.01"
                    className="form-control form-control-sm"
                    name="discount_amount"
                    value={form.discount_amount}
                    onChange={handleFormChange}
                  />
                </div>

                <div className="col-md-4">
                  <label className="form-label mb-1">Channel</label>
                  <select
                    className="form-select form-select-sm"
                    name="channel"
                    value={form.channel}
                    onChange={handleFormChange}
                  >
                    <option value="store">Store / In-person</option>
                    <option value="online">Online (manual)</option>
                    <option value="instagram">Instagram / Social</option>
                    <option value="phone">Phone / WhatsApp</option>
                    <option value="other">Other</option>
                  </select>
                </div>

                <div className="col-md-4">
                  <label className="form-label mb-1">Sale date/time</label>
                  <input
                    type="datetime-local"
                    className="form-control form-control-sm"
                    name="sale_date"
                    value={form.sale_date}
                    onChange={handleFormChange}
                  />
                  <div className="form-text">
                    Leave empty to use current time.
                  </div>
                </div>

                <div className="col-12">
                  <label className="form-label mb-1">Notes</label>
                  <textarea
                    className="form-control form-control-sm"
                    name="notes"
                    rows={2}
                    value={form.notes}
                    onChange={handleFormChange}
                    placeholder="e.g. Client Mary, resized later, sold as set with bracelet…"
                  />
                </div>

                <div className="col-12 d-flex justify-content-end">
                  <button
                    type="submit"
                    className="btn btn-sm btn-primary"
                    disabled={formSubmitting}
                  >
                    {formSubmitting ? "Saving…" : "Save sale"}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>

      {/* Sales table */}
      <div className="card shadow-sm border-0">
        <div className="card-body p-2">
          <div className="d-flex justify-content-between align-items-center mb-2">
            <div className="small text-muted">
              {loading
                ? "Loading sales…"
                : `Showing ${sales.length} sales`}
            </div>
          </div>

          {error && <div className="alert alert-danger py-2">{error}</div>}

          {!loading && sales.length === 0 && !error && (
            <div className="alert alert-secondary py-2 mb-0">
              No sales recorded yet.
            </div>
          )}

          {sales.length > 0 && (
            <div className="table-responsive">
              <table className="table table-hover table-sm align-middle mb-0">
                <thead className="table-light">
                  <tr>
                    <th>Date</th>
                    <th>SKU</th>
                    <th>Product</th>
                    <th className="text-end">Qty</th>
                    <th className="text-end">Unit price</th>
                    <th className="text-end">Discount</th>
                    <th className="text-end">Total</th>
                    <th>Channel</th>
                    <th>Notes</th>
                  </tr>
                </thead>
                <tbody>
                  {sales.map((s) => (
                    <tr key={s.id}>
                      <td className="small">
                        {new Date(s.sale_date).toLocaleString()}
                      </td>
                      <td>
                        <code>{s.sku}</code>
                      </td>
                      <td className="small">{s.product_name}</td>
                      <td className="text-end">{s.quantity}</td>
                      <td className="text-end">{s.unit_price}</td>
                      <td className="text-end">{s.discount_amount}</td>
                      <td className="text-end fw-semibold">{s.total}</td>
                      <td className="small text-capitalize">
                        {s.channel}
                      </td>
                      <td className="small text-muted">
                        {s.notes?.slice(0, 80)}
                        {s.notes && s.notes.length > 80 ? "…" : ""}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}