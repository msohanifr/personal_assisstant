import { FormEvent, useEffect, useRef, useState } from "react";
import { apiGet } from "../api/client";

type ScanVariant = {
  id: number;
  sku: string;
  barcode: string;
  name: string;
  collection: string | null;
  metal: string | null;
  size: string | null;
  stock_quantity: number;
  is_discontinued: boolean;
  current_price: string | null;
};

type ScanLookupResponse = {
  code: string;
  variant: ScanVariant | null;
};

type Props = {
  autoFocus?: boolean;
};

export default function ScanLookupCard({ autoFocus = false }: Props) {
  const [code, setCode] = useState("");
  const [result, setResult] = useState<ScanLookupResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const inputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    if (autoFocus && inputRef.current) {
      inputRef.current.focus();
      inputRef.current.select();
    }
  }, [autoFocus]);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();

    const trimmed = code.trim();
    if (!trimmed) {
      setError("Please enter a SKU or barcode.");
      setResult(null);
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const data = await apiGet<ScanLookupResponse>(
        `/api/scan/lookup/?code=${encodeURIComponent(trimmed)}`
      );
      setResult(data);

      if (!data.variant) {
        setError(`No variant found for “${trimmed}”.`);
      }
    } catch (err: any) {
      console.error(err);
      setError(err.message || "Lookup failed.");
      setResult(null);
    } finally {
      setLoading(false);
      if (inputRef.current) {
        inputRef.current.focus();
        inputRef.current.select();
      }
    }
  }

  const variant = result?.variant ?? null;

  return (
    <div className="card shadow-sm">
      <div className="card-body">
        <div className="d-flex justify-content-between align-items-center mb-2">
          <div>
            <div className="text-muted small text-uppercase">
              Quick scan lookup
            </div>
            <div className="fw-bold">Search by barcode or SKU</div>
          </div>
          <span className="badge bg-light text-muted">
            <i className="fa-solid fa-barcode me-1" /> Scanner-friendly
          </span>
        </div>

        <form className="row g-2 mb-3" onSubmit={handleSubmit}>
          <div className="col-8">
            <input
              ref={inputRef}
              type="text"
              className="form-control"
              placeholder="Scan or type code…"
              value={code}
              onChange={(e) => setCode(e.target.value)}
            />
          </div>
          <div className="col-4 d-grid">
            <button
              type="submit"
              className="btn btn-dark"
              disabled={loading || !code.trim()}
            >
              {loading ? "Looking up…" : "Lookup"}
            </button>
          </div>
        </form>

        {error && (
          <div className="alert alert-warning py-2 mb-3">
            <small>{error}</small>
          </div>
        )}

        {variant && (
          <div>
            <div className="d-flex justify-content-between align-items-center mb-1">
              <h2 className="h6 mb-0">{variant.name}</h2>
              {variant.is_discontinued && (
                <span className="badge bg-danger-subtle text-danger border border-danger-subtle">
                  Discontinued
                </span>
              )}
            </div>

            <p className="mb-1 small text-muted">
              SKU: <code>{variant.sku}</code> &nbsp; | &nbsp;
              Barcode: <code>{variant.barcode}</code>
            </p>

            <p className="mb-1 small">
              Collection:{" "}
              <strong>{variant.collection || "—"}</strong>
            </p>

            <p className="mb-1 small">
              Metal: <strong>{variant.metal || "—"}</strong>
              &nbsp; | &nbsp;
              Size: <strong>{variant.size || "—"}</strong>
            </p>

            <p className="mb-1 small">
              Stock:{" "}
              <strong
                className={
                  variant.stock_quantity <= 0
                    ? "text-danger"
                    : variant.stock_quantity <= 2
                    ? "text-warning"
                    : "text-success"
                }
              >
                {variant.stock_quantity}
              </strong>
            </p>

            {variant.current_price && (
              <p className="mb-2 small">
                Current price: <strong>{variant.current_price}</strong>
              </p>
            )}

            <a
              href={`/admin/catalog/productvariant/${variant.id}/change/`}
              className="btn btn-outline-secondary btn-sm"
              target="_blank"
              rel="noreferrer"
            >
              Open in admin
            </a>
          </div>
        )}

        {!variant && !error && result && (
          <p className="text-muted small mb-0">
            No variant found for “{result.code}”.
          </p>
        )}

        {!variant && !error && !result && (
          <p className="text-muted small mb-0">
            Tip: use your barcode scanner and just press enter.
          </p>
        )}
      </div>
    </div>
  );
}